import re

nomersuri =str(1)
kolvoayatov = str(7)
kolvobukv = str(139)
gemasuri1 = str(10143)

virajenie = nomersuri + kolvoayatov + kolvobukv +gemasuri1
print ('Выражение для 5 факта:' , virajenie)

virafloat = float (virajenie)
fact5 = virafloat / 19

print ('Факт 5:' , fact5)
