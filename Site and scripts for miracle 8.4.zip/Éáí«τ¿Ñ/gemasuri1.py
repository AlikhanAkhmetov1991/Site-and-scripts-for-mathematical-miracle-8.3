import re

gemaayata1 = float (786)
gemaayata2 = float (581)
gemaayata3 = float (618)
gemaayata4 = float (241)
gemaayata5 = float (836)
gemaayata6 = float (1072)
gemaayata7 = float (6009)

gemasuri1 = gemaayata1 + gemaayata2 +gemaayata3 +gemaayata4 +gemaayata5 +gemaayata6 +gemaayata7
print (gemasuri1)
