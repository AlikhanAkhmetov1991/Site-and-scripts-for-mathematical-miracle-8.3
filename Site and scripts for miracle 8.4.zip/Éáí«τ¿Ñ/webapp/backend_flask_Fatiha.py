from flask import Flask, render_template, request, redirect, escape
from miracles import virajenie_1 , fact_1 , kolvo_slov , kolvo_slov_glavi , virajenie_2, fact_2 , summa_poryadkovih_nomerov_stihov
from miracles import kolvo_bukv , kolvo_bukv_glavi , spisok_bukv_stiha, spisok_cifr_stiha, cifrovoe_znachenie_stiha, cifrovoe_znachenie_glavi
from miracles import virajenie_3 , fact_3, virajenie_4, fact_4, virajenie_5, fact_5, virajenie_6, fact_6, virajenie_7, fact_7
from miracles import virajenie_8, virajenie_9, virajenie_10, virajenie_11, virajenie_12, virajenie_13, virajenie_14, virajenie_15
from miracles import fact_8, fact_9, fact_10, fact_11, fact_12, fact_13, fact_14, fact_15
from miracles import summ_dlya_2_stiha, summ_dlya_3_stiha, summ_dlya_4_stiha, summ_dlya_5_stiha, summ_dlya_6_stiha, summ_dlya_7_stiha
from miracles import progressia_bukv_dlya_2_stiha, progressia_bukv_dlya_3_stiha, progressia_bukv_dlya_4_stiha, progressia_bukv_dlya_5_stiha 
from miracles import progressia_bukv_dlya_6_stiha, progressia_bukv_dlya_7_stiha, progressia_dlya_cifrovogo_znachenia_2,  progressia_dlya_cifrovogo_znachenia_3
from miracles import progressia_dlya_cifrovogo_znachenia_4, progressia_dlya_cifrovogo_znachenia_5, progressia_dlya_cifrovogo_znachenia_6
from miracles import progressia_dlya_cifrovogo_znachenia_7, bukvo_chislo_stiha, proverka_kratnosti_19, shetchiki_resultatov, shetchiki_resultatov_net
from miracles import kolichestvo_proverok_kratnosti, proverka_kratnosti_19_arabic
from decimal import *
import locale
import re
from for_example_russian import  spisok_cifr_stiha_rus, cifrovoe_znachenie_stiha_rus, cifrovoe_znachenie_glavi_rus, virajenie_3_rus, fact_3_rus, virajenie_5_rus
from for_example_russian import virajenie_5_rus, fact_5_rus, virajenie_9_rus, fact_9_rus, virajenie_10_rus, fact_10_rus, fact_11_rus, virajenie_11_rus, fact_12_rus
from for_example_russian import virajenie_12_rus, progressia_dlya_cifrovogo_znachenia_7_rus, progressia_dlya_cifrovogo_znachenia_6_rus
from for_example_russian import progressia_dlya_cifrovogo_znachenia_5_rus, progressia_dlya_cifrovogo_znachenia_4_rus, progressia_dlya_cifrovogo_znachenia_3_rus
from for_example_russian import progressia_dlya_cifrovogo_znachenia_2_rus, fact_13_rus, virajenie_13_rus, fact_14_rus, virajenie_14_rus, fact_15_rus, bukvo_chislo_stiha_rus
from for_example_russian import virajenie_15_rus
import for_English_slova_bukvi_znachenia_kratnosti as en1
import for_English_progressii as en2
import for_English_facti_virajenia as en3
import for_Kazakh_slova_bukvi_znachenia_kratnosti as kz1
locale.setlocale(locale.LC_NUMERIC, "ru_RU.UTF-8")
"""устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
getcontext().prec = 400

app = Flask (__name__)

@app.route ('/')
@app.route ('/entry')
def entry_page () -> 'html' :
    return render_template ('entry.html' ,
                            the_title = 'Попытка увидеть пока не стало поздно')

@app.route ('/english')
def entry_page_english () -> 'html' :
    return render_template ('entry_english.html' ,
                            the_title = 'The Mathematical miracle of the Quran')
@app.route ('/arabic')
def entry_page_arabic () -> 'html' :
    return render_template ('entry_arabic.html' ,
                            the_title = 'بسم الله الرحمن الرحيم')
@app.route ('/kazakh')
def entry_page_kazakh () -> 'html' :
    return render_template ('entry_kazakh.html' ,
                            the_title = 'Тым кеш болмай тұрып көруге тырысады')

@app.route ('/googled7833cc9ffb86fa9.html')
def google_autentification () -> 'html' :
    return render_template ('googled7833cc9ffb86fa9.html')

    
@app.route ('/results' , methods = ['POST'])
def results () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = kolvo_slov (stih1)
    kolvo_slov_2_user = kolvo_slov (stih2)
    kolvo_slov_3_user = kolvo_slov (stih3)
    kolvo_slov_4_user = kolvo_slov (stih4)
    kolvo_slov_5_user = kolvo_slov (stih5)
    kolvo_slov_6_user = kolvo_slov (stih6)
    kolvo_slov_7_user = kolvo_slov (stih7)

    kolvo_slov_glavi_user = kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = virajenie_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = fact_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                        int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = kolvo_bukv (stih1)
    kolvo_bukv_2_user = kolvo_bukv (stih2)
    kolvo_bukv_3_user = kolvo_bukv (stih3)
    kolvo_bukv_4_user = kolvo_bukv (stih4)
    kolvo_bukv_5_user = kolvo_bukv (stih5)
    kolvo_bukv_6_user = kolvo_bukv (stih6)
    kolvo_bukv_7_user = kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = spisok_cifr_stiha (stih1)
    spisok_bukv_cifr_2_user = spisok_cifr_stiha (stih2)
    spisok_bukv_cifr_3_user = spisok_cifr_stiha (stih3)
    spisok_bukv_cifr_4_user = spisok_cifr_stiha (stih4)
    spisok_bukv_cifr_5_user = spisok_cifr_stiha (stih5)
    spisok_bukv_cifr_6_user = spisok_cifr_stiha (stih6)
    spisok_bukv_cifr_7_user = spisok_cifr_stiha (stih7)

    сifr_znach_1_user = cifrovoe_znachenie_stiha (stih1)
    сifr_znach_2_user = cifrovoe_znachenie_stiha (stih2)
    сifr_znach_3_user = cifrovoe_znachenie_stiha (stih3)
    сifr_znach_4_user = cifrovoe_znachenie_stiha (stih4)
    сifr_znach_5_user = cifrovoe_znachenie_stiha (stih5)
    сifr_znach_6_user = cifrovoe_znachenie_stiha (stih6)
    сifr_znach_7_user = cifrovoe_znachenie_stiha (stih7)

    cifr_znach_glavi_user = cifrovoe_znachenie_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = virajenie_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                        int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                        stih4, stih5, stih6, stih7)

    the_results_3_user = fact_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                 int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                 stih4, stih5, stih6, stih7)




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))

    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))

    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))



    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                                  stih1, stih2, stih3, stih4,
                                                  stih5, stih6,stih7)

    fact_4_backend = fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                        stih1, stih2, stih3, stih4,
                                        stih5, stih6,stih7)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = virajenie_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_5_backend = fact_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = virajenie_6 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_6_backend = fact_6 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_backend))

    virajenie_7_backend = virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_7_backend = fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_backend))

    virajenie_8_backend = virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_8_backend = fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_backend))



    virajenie_9_backend = virajenie_9 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_9_backend = fact_9 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_backend))


    virajenie_10_backend = virajenie_10 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_10_backend = fact_10 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_backend))

    virajenie_11_backend = virajenie_11 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_11_backend = fact_11 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = virajenie_12 (stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = fact_12 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_backend))




    virajenie_13_backend = virajenie_13 (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_13_backend = fact_13 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_backend))


    virajenie_14_backend = virajenie_14 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)

    fact_14_backend = fact_14 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_backend))

    virajenie_15_backend = virajenie_15 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)
    
    fact_15_backend = fact_15 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_backend))


    summ_dlya_7_stiha_user = summ_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)

    summ_dlya_6_stiha_user = summ_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    summ_dlya_5_stiha_user = summ_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    summ_dlya_4_stiha_user = summ_dlya_4_stiha (stih1, stih2, stih3, stih4)
    summ_dlya_3_stiha_user = summ_dlya_3_stiha (stih1, stih2, stih3)
    summ_dlya_2_stiha_user = summ_dlya_2_stiha (stih1, stih2)


    progressia_bukv_dlya_7_stiha_user = progressia_bukv_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_bukv_dlya_6_stiha_user = progressia_bukv_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_bukv_dlya_5_stiha_user = progressia_bukv_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_bukv_dlya_4_stiha_user = progressia_bukv_dlya_4_stiha (stih1, stih2, stih3, stih4)
    progressia_bukv_dlya_3_stiha_user = progressia_bukv_dlya_3_stiha (stih1, stih2, stih3)

    progressia_bukv_dlya_2_stiha_user = progressia_bukv_dlya_2_stiha (stih1, stih2)
    


    
    progressia_dlya_cifrovogo_znachenia_7_user = progressia_dlya_cifrovogo_znachenia_7 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_dlya_cifrovogo_znachenia_6_user = progressia_dlya_cifrovogo_znachenia_6 (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_dlya_cifrovogo_znachenia_5_user = progressia_dlya_cifrovogo_znachenia_5 (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_dlya_cifrovogo_znachenia_4_user = progressia_dlya_cifrovogo_znachenia_4 (stih1, stih2, stih3, stih4)
    progressia_dlya_cifrovogo_znachenia_3_user = progressia_dlya_cifrovogo_znachenia_3 (stih1, stih2, stih3)
    progressia_dlya_cifrovogo_znachenia_2_user = progressia_dlya_cifrovogo_znachenia_2 (stih1, stih2)



    bukvo_chislo_1_stiha = bukvo_chislo_stiha (stih1)
    bukvo_chislo_2_stiha = bukvo_chislo_stiha (stih2)
    bukvo_chislo_3_stiha = bukvo_chislo_stiha (stih3)
    bukvo_chislo_4_stiha = bukvo_chislo_stiha (stih4)
    bukvo_chislo_5_stiha = bukvo_chislo_stiha (stih5)
    bukvo_chislo_6_stiha = bukvo_chislo_stiha (stih6)
    bukvo_chislo_7_stiha = bukvo_chislo_stiha (stih7)

    the_check_fact_1_backend = proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))


    shetchiki_resultatov_user = shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results.html' ,
                            the_title = 'Ваши результаты',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend,
                            the_check_fact_2 = the_check_fact_2_backend,
                            the_check_fact_1 = the_check_fact_1_backend,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)

@app.route ('/results_arabic' , methods = ['POST'])
def results_arabic () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = kolvo_slov (stih1)
    kolvo_slov_2_user = kolvo_slov (stih2)
    kolvo_slov_3_user = kolvo_slov (stih3)
    kolvo_slov_4_user = kolvo_slov (stih4)
    kolvo_slov_5_user = kolvo_slov (stih5)
    kolvo_slov_6_user = kolvo_slov (stih6)
    kolvo_slov_7_user = kolvo_slov (stih7)

    kolvo_slov_glavi_user = kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = virajenie_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = fact_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                        int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = kolvo_bukv (stih1)
    kolvo_bukv_2_user = kolvo_bukv (stih2)
    kolvo_bukv_3_user = kolvo_bukv (stih3)
    kolvo_bukv_4_user = kolvo_bukv (stih4)
    kolvo_bukv_5_user = kolvo_bukv (stih5)
    kolvo_bukv_6_user = kolvo_bukv (stih6)
    kolvo_bukv_7_user = kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = spisok_cifr_stiha (stih1)
    spisok_bukv_cifr_2_user = spisok_cifr_stiha (stih2)
    spisok_bukv_cifr_3_user = spisok_cifr_stiha (stih3)
    spisok_bukv_cifr_4_user = spisok_cifr_stiha (stih4)
    spisok_bukv_cifr_5_user = spisok_cifr_stiha (stih5)
    spisok_bukv_cifr_6_user = spisok_cifr_stiha (stih6)
    spisok_bukv_cifr_7_user = spisok_cifr_stiha (stih7)

    сifr_znach_1_user = cifrovoe_znachenie_stiha (stih1)
    сifr_znach_2_user = cifrovoe_znachenie_stiha (stih2)
    сifr_znach_3_user = cifrovoe_znachenie_stiha (stih3)
    сifr_znach_4_user = cifrovoe_znachenie_stiha (stih4)
    сifr_znach_5_user = cifrovoe_znachenie_stiha (stih5)
    сifr_znach_6_user = cifrovoe_znachenie_stiha (stih6)
    сifr_znach_7_user = cifrovoe_znachenie_stiha (stih7)

    cifr_znach_glavi_user = cifrovoe_znachenie_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = virajenie_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                        int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                        stih4, stih5, stih6, stih7)

    the_results_3_user = fact_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                 int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                 stih4, stih5, stih6, stih7)




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))
    the_check_fact_4_fatiha_backend_arabic = proverka_kratnosti_19_arabic (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))
    check_fact_5_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))
    check_fact_6_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_6_fatiha_backend))

    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))
    check_fact_7_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_7_fatiha_backend))

    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))
    check_fact_8_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_8_fatiha_backend))



    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))
    check_fact_9_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))
    check_fact_10_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))
    check_fact_11_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))
    check_fact_12_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))
    check_fact_13_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))
    check_fact_14_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))
    check_fact_15_fatiha_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                                  stih1, stih2, stih3, stih4,
                                                  stih5, stih6,stih7)

    fact_4_backend = fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                        stih1, stih2, stih3, stih4,
                                        stih5, stih6,stih7)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))
    the_check_fact_4_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = virajenie_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_5_backend = fact_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_backend))
    check_fact_5_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = virajenie_6 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_6_backend = fact_6 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_backend))
    check_fact_6_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_6_backend))

    virajenie_7_backend = virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_7_backend = fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_backend))
    check_fact_7_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_7_backend))

    virajenie_8_backend = virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_8_backend = fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_backend))
    check_fact_8_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_8_backend))



    virajenie_9_backend = virajenie_9 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_9_backend = fact_9 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_backend))
    check_fact_9_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_9_backend))


    virajenie_10_backend = virajenie_10 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_10_backend = fact_10 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_backend))
    check_fact_10_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_10_backend))

    virajenie_11_backend = virajenie_11 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_11_backend = fact_11 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_backend))
    check_fact_11_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = virajenie_12 (stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = fact_12 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_backend))
    check_fact_12_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_12_backend))




    virajenie_13_backend = virajenie_13 (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_13_backend = fact_13 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_backend))
    check_fact_13_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_13_backend))


    virajenie_14_backend = virajenie_14 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)

    fact_14_backend = fact_14 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_backend))
    check_fact_14_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_14_backend))

    virajenie_15_backend = virajenie_15 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)
    
    fact_15_backend = fact_15 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_backend))
    check_fact_15_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_15_backend))


    summ_dlya_7_stiha_user = summ_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)

    summ_dlya_6_stiha_user = summ_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    summ_dlya_5_stiha_user = summ_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    summ_dlya_4_stiha_user = summ_dlya_4_stiha (stih1, stih2, stih3, stih4)
    summ_dlya_3_stiha_user = summ_dlya_3_stiha (stih1, stih2, stih3)
    summ_dlya_2_stiha_user = summ_dlya_2_stiha (stih1, stih2)


    progressia_bukv_dlya_7_stiha_user = progressia_bukv_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_bukv_dlya_6_stiha_user = progressia_bukv_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_bukv_dlya_5_stiha_user = progressia_bukv_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_bukv_dlya_4_stiha_user = progressia_bukv_dlya_4_stiha (stih1, stih2, stih3, stih4)
    progressia_bukv_dlya_3_stiha_user = progressia_bukv_dlya_3_stiha (stih1, stih2, stih3)

    progressia_bukv_dlya_2_stiha_user = progressia_bukv_dlya_2_stiha (stih1, stih2)
    


    
    progressia_dlya_cifrovogo_znachenia_7_user = progressia_dlya_cifrovogo_znachenia_7 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_dlya_cifrovogo_znachenia_6_user = progressia_dlya_cifrovogo_znachenia_6 (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_dlya_cifrovogo_znachenia_5_user = progressia_dlya_cifrovogo_znachenia_5 (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_dlya_cifrovogo_znachenia_4_user = progressia_dlya_cifrovogo_znachenia_4 (stih1, stih2, stih3, stih4)
    progressia_dlya_cifrovogo_znachenia_3_user = progressia_dlya_cifrovogo_znachenia_3 (stih1, stih2, stih3)
    progressia_dlya_cifrovogo_znachenia_2_user = progressia_dlya_cifrovogo_znachenia_2 (stih1, stih2)



    bukvo_chislo_1_stiha = bukvo_chislo_stiha (stih1)
    bukvo_chislo_2_stiha = bukvo_chislo_stiha (stih2)
    bukvo_chislo_3_stiha = bukvo_chislo_stiha (stih3)
    bukvo_chislo_4_stiha = bukvo_chislo_stiha (stih4)
    bukvo_chislo_5_stiha = bukvo_chislo_stiha (stih5)
    bukvo_chislo_6_stiha = bukvo_chislo_stiha (stih6)
    bukvo_chislo_7_stiha = bukvo_chislo_stiha (stih7)

    the_check_fact_1_backend = proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))


    the_check_fact_1_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_1_user))
    the_check_fact_2_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (virajenie_2_user))
    the_check_fact_3_backend_arabic = proverka_kratnosti_19_arabic ( Decimal (the_virajenie_3_user))


    shetchiki_resultatov_user = shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results_arabic.html' ,
                            the_title = 'نتائج بحثك',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend_arabic,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend_arabic,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend_arabic,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend_arabic,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend_arabic,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend_arabic,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend_arabic,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend_arabic,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend_arabic,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend_arabic,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend_arabic,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend_arabic,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend_arabic,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend_arabic,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend_arabic,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend_arabic,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend_arabic,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend_arabic,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend_arabic,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend_arabic,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend_arabic,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend_arabic,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend_arabic,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend_arabic,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend_arabic,
                            the_check_fact_2 = the_check_fact_2_backend_arabic,
                            the_check_fact_1 = the_check_fact_1_backend_arabic,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)


@app.route ('/results_rus' , methods = ['POST'])
def results_rus () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = kolvo_slov (stih1)
    kolvo_slov_2_user = kolvo_slov (stih2)
    kolvo_slov_3_user = kolvo_slov (stih3)
    kolvo_slov_4_user = kolvo_slov (stih4)
    kolvo_slov_5_user = kolvo_slov (stih5)
    kolvo_slov_6_user = kolvo_slov (stih6)
    kolvo_slov_7_user = kolvo_slov (stih7)

    kolvo_slov_glavi_user = kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = virajenie_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = fact_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                        int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = kolvo_bukv (stih1)
    kolvo_bukv_2_user = kolvo_bukv (stih2)
    kolvo_bukv_3_user = kolvo_bukv (stih3)
    kolvo_bukv_4_user = kolvo_bukv (stih4)
    kolvo_bukv_5_user = kolvo_bukv (stih5)
    kolvo_bukv_6_user = kolvo_bukv (stih6)
    kolvo_bukv_7_user = kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = spisok_cifr_stiha_rus (stih1)
    spisok_bukv_cifr_2_user = spisok_cifr_stiha_rus (stih2)
    spisok_bukv_cifr_3_user = spisok_cifr_stiha_rus (stih3)
    spisok_bukv_cifr_4_user = spisok_cifr_stiha_rus (stih4)
    spisok_bukv_cifr_5_user = spisok_cifr_stiha_rus (stih5)
    spisok_bukv_cifr_6_user = spisok_cifr_stiha_rus (stih6)
    spisok_bukv_cifr_7_user = spisok_cifr_stiha_rus (stih7)

    сifr_znach_1_user = cifrovoe_znachenie_stiha_rus (stih1)
    сifr_znach_2_user = cifrovoe_znachenie_stiha_rus (stih2)
    сifr_znach_3_user = cifrovoe_znachenie_stiha_rus (stih3)
    сifr_znach_4_user = cifrovoe_znachenie_stiha_rus (stih4)
    сifr_znach_5_user = cifrovoe_znachenie_stiha_rus (stih5)
    сifr_znach_6_user = cifrovoe_znachenie_stiha_rus (stih6)
    сifr_znach_7_user = cifrovoe_znachenie_stiha_rus (stih7)

    cifr_znach_glavi_user = cifrovoe_znachenie_glavi_rus (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = virajenie_3_rus (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                            int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                            stih4, stih5, stih6, stih7)

    the_results_3_user = fact_3_rus (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                     int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                     stih4, stih5, stih6, stih7)




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))

    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))

    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))



    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                                  stih1, stih2, stih3, stih4,
                                                  stih5, stih6,stih7)

    fact_4_backend = fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                        stih1, stih2, stih3, stih4,
                                        stih5, stih6,stih7)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = virajenie_5_rus (nomer_glavi, kolvo_stihov_glavi_user,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_5_backend = fact_5_rus (nomer_glavi, kolvo_stihov_glavi_user,
                                stih1, stih2, stih3, stih4,
                                stih5, stih6,stih7)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = proverka_kratnosti_19 ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = virajenie_6 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_6_backend = fact_6 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = proverka_kratnosti_19 ( Decimal (virajenie_6_backend))

    virajenie_7_backend = virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_7_backend = fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = proverka_kratnosti_19 ( Decimal (virajenie_7_backend))

    virajenie_8_backend = virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_8_backend = fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = proverka_kratnosti_19 ( Decimal (virajenie_8_backend))



    virajenie_9_backend = virajenie_9_rus (nomer_glavi,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_9_backend = fact_9_rus (nomer_glavi,
                                stih1, stih2, stih3, stih4,
                                stih5, stih6,stih7)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = proverka_kratnosti_19 ( Decimal (virajenie_9_backend))


    virajenie_10_backend = virajenie_10_rus (nomer_glavi,
                                            stih1, stih2, stih3, stih4,
                                            stih5, stih6,stih7)

    fact_10_backend = fact_10_rus (nomer_glavi,
                                  stih1, stih2, stih3, stih4,
                                  stih5, stih6,stih7)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = proverka_kratnosti_19 ( Decimal (virajenie_10_backend))

    virajenie_11_backend = virajenie_11_rus (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_11_backend = fact_11_rus (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = proverka_kratnosti_19 ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = virajenie_12_rus (stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = fact_12_rus (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = proverka_kratnosti_19 ( Decimal (virajenie_12_backend))




    virajenie_13_backend = virajenie_13_rus (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_13_backend = fact_13_rus (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = proverka_kratnosti_19 ( Decimal (virajenie_13_backend))


    virajenie_14_backend = virajenie_14_rus (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)

    fact_14_backend = fact_14_rus (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = proverka_kratnosti_19 ( Decimal (virajenie_14_backend))

    virajenie_15_backend = virajenie_15_rus (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)
    
    fact_15_backend = fact_15_rus (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = proverka_kratnosti_19 ( Decimal (virajenie_15_backend))


    summ_dlya_7_stiha_user = summ_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)

    summ_dlya_6_stiha_user = summ_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    summ_dlya_5_stiha_user = summ_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    summ_dlya_4_stiha_user = summ_dlya_4_stiha (stih1, stih2, stih3, stih4)
    summ_dlya_3_stiha_user = summ_dlya_3_stiha (stih1, stih2, stih3)
    summ_dlya_2_stiha_user = summ_dlya_2_stiha (stih1, stih2)


    progressia_bukv_dlya_7_stiha_user = progressia_bukv_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_bukv_dlya_6_stiha_user = progressia_bukv_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_bukv_dlya_5_stiha_user = progressia_bukv_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_bukv_dlya_4_stiha_user = progressia_bukv_dlya_4_stiha (stih1, stih2, stih3, stih4)
    progressia_bukv_dlya_3_stiha_user = progressia_bukv_dlya_3_stiha (stih1, stih2, stih3)

    progressia_bukv_dlya_2_stiha_user = progressia_bukv_dlya_2_stiha (stih1, stih2)
    


    
    progressia_dlya_cifrovogo_znachenia_7_user = progressia_dlya_cifrovogo_znachenia_7_rus (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_dlya_cifrovogo_znachenia_6_user = progressia_dlya_cifrovogo_znachenia_6_rus (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_dlya_cifrovogo_znachenia_5_user = progressia_dlya_cifrovogo_znachenia_5_rus (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_dlya_cifrovogo_znachenia_4_user = progressia_dlya_cifrovogo_znachenia_4_rus (stih1, stih2, stih3, stih4)
    progressia_dlya_cifrovogo_znachenia_3_user = progressia_dlya_cifrovogo_znachenia_3_rus (stih1, stih2, stih3)
    progressia_dlya_cifrovogo_znachenia_2_user = progressia_dlya_cifrovogo_znachenia_2_rus (stih1, stih2)



    bukvo_chislo_1_stiha = bukvo_chislo_stiha_rus (stih1)
    bukvo_chislo_2_stiha = bukvo_chislo_stiha_rus (stih2)
    bukvo_chislo_3_stiha = bukvo_chislo_stiha_rus (stih3)
    bukvo_chislo_4_stiha = bukvo_chislo_stiha_rus (stih4)
    bukvo_chislo_5_stiha = bukvo_chislo_stiha_rus (stih5)
    bukvo_chislo_6_stiha = bukvo_chislo_stiha_rus (stih6)
    bukvo_chislo_7_stiha = bukvo_chislo_stiha_rus (stih7)

    the_check_fact_1_backend = proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))


    shetchiki_resultatov_user = shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results.html' ,
                            the_title = 'Ваши результаты',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend,
                            the_check_fact_2 = the_check_fact_2_backend,
                            the_check_fact_1 = the_check_fact_1_backend,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)


@app.route ('/results_english' , methods = ['POST'])
def results_english () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = en3.virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = "{0:.9f}".format(Decimal (en3.fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)))
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = en1.kolvo_slov (stih1)
    kolvo_slov_2_user = en1.kolvo_slov (stih2)
    kolvo_slov_3_user = en1.kolvo_slov (stih3)
    kolvo_slov_4_user = en1.kolvo_slov (stih4)
    kolvo_slov_5_user = en1.kolvo_slov (stih5)
    kolvo_slov_6_user = en1.kolvo_slov (stih6)
    kolvo_slov_7_user = en1.kolvo_slov (stih7)

    kolvo_slov_glavi_user = en1.kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = en3.virajenie_2 (kolvo_slov_glavi_user,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = "{0:.9f}".format(Decimal (en3.fact_2 (kolvo_slov_glavi_user,nomer_glavi, kolvo_stihov_glavi_user)))

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = en1.summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                            int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = en1.kolvo_bukv (stih1)
    kolvo_bukv_2_user = en1.kolvo_bukv (stih2)
    kolvo_bukv_3_user = en1.kolvo_bukv (stih3)
    kolvo_bukv_4_user = en1.kolvo_bukv (stih4)
    kolvo_bukv_5_user = en1.kolvo_bukv (stih5)
    kolvo_bukv_6_user = en1.kolvo_bukv (stih6)
    kolvo_bukv_7_user = en1.kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = en1.kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = en1.spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = en1.spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = en1.spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = en1.spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = en1.spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = en1.spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = en1.spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = en1.spisok_cifr_stiha (stih1)
    spisok_bukv_cifr_2_user = en1.spisok_cifr_stiha (stih2)
    spisok_bukv_cifr_3_user = en1.spisok_cifr_stiha (stih3)
    spisok_bukv_cifr_4_user = en1.spisok_cifr_stiha (stih4)
    spisok_bukv_cifr_5_user = en1.spisok_cifr_stiha (stih5)
    spisok_bukv_cifr_6_user = en1.spisok_cifr_stiha (stih6)
    spisok_bukv_cifr_7_user = en1.spisok_cifr_stiha (stih7)

    сifr_znach_1_user = en1.cifrovoe_znachenie_stiha (stih1)
    сifr_znach_2_user = en1.cifrovoe_znachenie_stiha (stih2)
    сifr_znach_3_user = en1.cifrovoe_znachenie_stiha (stih3)
    сifr_znach_4_user = en1.cifrovoe_znachenie_stiha (stih4)
    сifr_znach_5_user = en1.cifrovoe_znachenie_stiha (stih5)
    сifr_znach_6_user = en1.cifrovoe_znachenie_stiha (stih6)
    сifr_znach_7_user = en1.cifrovoe_znachenie_stiha (stih7)

    cifr_znach_glavi_user = en1.cifrovoe_znachenie_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = en3.virajenie_3 (sum_poryadkovih_nomerov_backend, kolvo_slov_glavi_user, kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    the_results_3_user = "{0:.9f}".format(Decimal (en3.fact_3 (sum_poryadkovih_nomerov_backend, kolvo_slov_glavi_user, kolvo_bukv_glavi_user, cifr_znach_glavi_user)))




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = en1.proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))

    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))

    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))



    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = en3.virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                               kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user, kolvo_slov_4_user,
                                               kolvo_slov_5_user, kolvo_slov_6_user,kolvo_slov_7_user)

    fact_4_backend = en3.fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                 kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user, kolvo_slov_4_user,
                                 kolvo_slov_5_user, kolvo_slov_6_user,kolvo_slov_7_user)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = en1.proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = en3.virajenie_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                              kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    fact_5_backend = en3.fact_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                   kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = en3.virajenie_6 (nomer_glavi,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                             kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)

    fact_6_backend = en3.fact_6 (nomer_glavi,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                             kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_6_backend))

    virajenie_7_backend = en3.virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                              kolvo_bukv_5_user, kolvo_bukv_6_user, kolvo_bukv_7_user, kolvo_bukv_glavi_user)

    fact_7_backend = en3.fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                              kolvo_bukv_5_user, kolvo_bukv_6_user, kolvo_bukv_7_user, kolvo_bukv_glavi_user)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_7_backend))


    summ_dlya_7_stiha_user = en2.progressia_bukv_7 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)

    summ_dlya_6_stiha_user = en2.progressia_bukv_6 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user)
    summ_dlya_5_stiha_user = en2.progressia_bukv_5 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user)
    summ_dlya_4_stiha_user =  en2.progressia_bukv_4 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user)
    summ_dlya_3_stiha_user = en2.progressia_bukv_3 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user)
    summ_dlya_2_stiha_user = en2.progressia_bukv_2 (kolvo_bukv_1_user, kolvo_bukv_2_user)


    progressia_bukv_dlya_7_stiha_user = en2.progressia_bukv_7 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)
    progressia_bukv_dlya_6_stiha_user = en2.progressia_bukv_6 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user)
    progressia_bukv_dlya_5_stiha_user = en2.progressia_bukv_5 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user)
    progressia_bukv_dlya_4_stiha_user = en2.progressia_bukv_4 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user)
    progressia_bukv_dlya_3_stiha_user = en2.progressia_bukv_3 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user)

    progressia_bukv_dlya_2_stiha_user = en2.progressia_bukv_2 (kolvo_bukv_1_user, kolvo_bukv_2_user)


    

    virajenie_8_backend = en3.virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              kolvo_bukv_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                       progressia_bukv_dlya_4_stiha_user,
                                              progressia_bukv_dlya_5_stiha_user, progressia_bukv_dlya_6_stiha_user,progressia_bukv_dlya_7_stiha_user)

    fact_8_backend = en3.fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                       progressia_bukv_dlya_4_stiha_user,
                                              progressia_bukv_dlya_5_stiha_user, progressia_bukv_dlya_6_stiha_user,progressia_bukv_dlya_7_stiha_user)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_8_backend))



    virajenie_9_backend = en3.virajenie_9 (nomer_glavi,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)

    fact_9_backend = en3.fact_9 (nomer_glavi,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_9_backend))


    virajenie_10_backend = en3.virajenie_10 (nomer_glavi,
                                                kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)

    fact_10_backend = en3.fact_10 (nomer_glavi,
                                      kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_10_backend))


    progressia_dlya_cifrovogo_znachenia_7_user = en2.progressia_dlya_cifrovogo_znachenia_7 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user, сifr_znach_6_user,сifr_znach_7_user)
    progressia_dlya_cifrovogo_znachenia_6_user = en2.progressia_dlya_cifrovogo_znachenia_6 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user, сifr_znach_6_user)
    progressia_dlya_cifrovogo_znachenia_5_user = en2.progressia_dlya_cifrovogo_znachenia_5 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user)
    progressia_dlya_cifrovogo_znachenia_4_user = en2.progressia_dlya_cifrovogo_znachenia_4 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user)
    progressia_dlya_cifrovogo_znachenia_3_user = en2.progressia_dlya_cifrovogo_znachenia_3 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user)
    progressia_dlya_cifrovogo_znachenia_2_user = en2.progressia_dlya_cifrovogo_znachenia_2 (сifr_znach_1_user, сifr_znach_2_user)

    

    virajenie_11_backend = en3.virajenie_11 (nomer_glavi,
                                                kolvo_bukv_1_user, сifr_znach_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                                progressia_bukv_dlya_4_stiha_user, progressia_bukv_dlya_5_stiha_user,progressia_bukv_dlya_6_stiha_user,
                                         progressia_bukv_dlya_7_stiha_user, progressia_dlya_cifrovogo_znachenia_2_user,progressia_dlya_cifrovogo_znachenia_3_user,
                                         progressia_dlya_cifrovogo_znachenia_4_user,progressia_dlya_cifrovogo_znachenia_5_user,
                                         progressia_dlya_cifrovogo_znachenia_6_user,
                                         progressia_dlya_cifrovogo_znachenia_7_user)

    fact_11_backend = en3.fact_11 (nomer_glavi,
                                      kolvo_bukv_1_user, сifr_znach_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                                progressia_bukv_dlya_4_stiha_user, progressia_bukv_dlya_5_stiha_user,progressia_bukv_dlya_6_stiha_user,
                                         progressia_bukv_dlya_7_stiha_user, progressia_dlya_cifrovogo_znachenia_2_user,progressia_dlya_cifrovogo_znachenia_3_user,
                                         progressia_dlya_cifrovogo_znachenia_4_user,progressia_dlya_cifrovogo_znachenia_5_user,
                                         progressia_dlya_cifrovogo_znachenia_6_user,
                                         progressia_dlya_cifrovogo_znachenia_7_user)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = en3.virajenie_12 (kolvo_bukv_glavi_user, kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = en3.fact_12 (kolvo_bukv_glavi_user, kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_12_backend))




    virajenie_13_backend = en3.virajenie_13 (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user,
                                             сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)

    fact_13_backend = en3.fact_13 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user,
                                   сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_13_backend))


    virajenie_14_backend = en3.virajenie_14 (nomer_glavi, kolvo_stihov_glavi_user,
                                      cifr_znach_glavi_user, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                                kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)

    fact_14_backend = en3.fact_14 (nomer_glavi, kolvo_stihov_glavi_user,
                                      cifr_znach_glavi_user, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                                kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_14_backend))

    bukvo_chislo_1_stiha = en1.bukvo_chislo_stiha (stih1)
    bukvo_chislo_2_stiha = en1.bukvo_chislo_stiha (stih2)
    bukvo_chislo_3_stiha = en1.bukvo_chislo_stiha (stih3)
    bukvo_chislo_4_stiha = en1.bukvo_chislo_stiha (stih4)
    bukvo_chislo_5_stiha = en1.bukvo_chislo_stiha (stih5)
    bukvo_chislo_6_stiha = en1.bukvo_chislo_stiha (stih6)
    bukvo_chislo_7_stiha = en1.bukvo_chislo_stiha (stih7)

    virajenie_15_backend = en3.virajenie_15 (nomer_glavi,kolvo_stihov_glavi_user, number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                     kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, bukvo_chislo_1_stiha,
                                   bukvo_chislo_2_stiha,
                                   bukvo_chislo_3_stiha,
                                   bukvo_chislo_4_stiha,
                                   bukvo_chislo_5_stiha,
                                   bukvo_chislo_6_stiha,
                                   bukvo_chislo_7_stiha)
    
    fact_15_backend = en3.fact_15 (nomer_glavi,kolvo_stihov_glavi_user, number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                     kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, bukvo_chislo_1_stiha,
                                   bukvo_chislo_2_stiha,
                                   bukvo_chislo_3_stiha,
                                   bukvo_chislo_4_stiha,
                                   bukvo_chislo_5_stiha,
                                   bukvo_chislo_6_stiha,
                                   bukvo_chislo_7_stiha)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_15_backend))



    


    






    the_check_fact_1_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = en1.proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))


    shetchiki_resultatov_user = en1.shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  en1.shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  en1.kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results_english.html' ,
                            the_title = 'The Mathematical Miracle of the Quran',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend,
                            the_check_fact_2 = the_check_fact_2_backend,
                            the_check_fact_1 = the_check_fact_1_backend,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)

@app.route ('/results_english_for_arabic' , methods = ['POST'])
def results_english_for_arabic () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = kolvo_slov (stih1)
    kolvo_slov_2_user = kolvo_slov (stih2)
    kolvo_slov_3_user = kolvo_slov (stih3)
    kolvo_slov_4_user = kolvo_slov (stih4)
    kolvo_slov_5_user = kolvo_slov (stih5)
    kolvo_slov_6_user = kolvo_slov (stih6)
    kolvo_slov_7_user = kolvo_slov (stih7)

    kolvo_slov_glavi_user = kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = virajenie_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = fact_2 (stih1, stih2, stih3, stih4, stih5, stih6, stih7,nomer_glavi, kolvo_stihov_glavi_user)

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                        int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = kolvo_bukv (stih1)
    kolvo_bukv_2_user = kolvo_bukv (stih2)
    kolvo_bukv_3_user = kolvo_bukv (stih3)
    kolvo_bukv_4_user = kolvo_bukv (stih4)
    kolvo_bukv_5_user = kolvo_bukv (stih5)
    kolvo_bukv_6_user = kolvo_bukv (stih6)
    kolvo_bukv_7_user = kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = spisok_cifr_stiha (stih1)
    spisok_bukv_cifr_2_user = spisok_cifr_stiha (stih2)
    spisok_bukv_cifr_3_user = spisok_cifr_stiha (stih3)
    spisok_bukv_cifr_4_user = spisok_cifr_stiha (stih4)
    spisok_bukv_cifr_5_user = spisok_cifr_stiha (stih5)
    spisok_bukv_cifr_6_user = spisok_cifr_stiha (stih6)
    spisok_bukv_cifr_7_user = spisok_cifr_stiha (stih7)

    сifr_znach_1_user = cifrovoe_znachenie_stiha (stih1)
    сifr_znach_2_user = cifrovoe_znachenie_stiha (stih2)
    сifr_znach_3_user = cifrovoe_znachenie_stiha (stih3)
    сifr_znach_4_user = cifrovoe_znachenie_stiha (stih4)
    сifr_znach_5_user = cifrovoe_znachenie_stiha (stih5)
    сifr_znach_6_user = cifrovoe_znachenie_stiha (stih6)
    сifr_znach_7_user = cifrovoe_znachenie_stiha (stih7)

    cifr_znach_glavi_user = cifrovoe_znachenie_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = virajenie_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                        int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                        stih4, stih5, stih6, stih7)

    the_results_3_user = fact_3 (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                 int (number_stih_5), int (number_stih_6), int (number_stih_7), stih1, stih2, stih3,
                                 stih4, stih5, stih6, stih7)




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = en1.proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))


    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))


    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))




    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                                  stih1, stih2, stih3, stih4,
                                                  stih5, stih6,stih7)

    fact_4_backend = fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                        stih1, stih2, stih3, stih4,
                                        stih5, stih6,stih7)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = en1.proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = virajenie_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_5_backend = fact_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = virajenie_6 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_6_backend = fact_6 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_6_backend))

    virajenie_7_backend = virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_7_backend = fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_7_backend))

    virajenie_8_backend = virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_8_backend = fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_8_backend))



    virajenie_9_backend = virajenie_9 (nomer_glavi,
                                              stih1, stih2, stih3, stih4,
                                              stih5, stih6,stih7)

    fact_9_backend = fact_9 (nomer_glavi,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_9_backend))


    virajenie_10_backend = virajenie_10 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_10_backend = fact_10 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_10_backend))

    virajenie_11_backend = virajenie_11 (nomer_glavi,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)

    fact_11_backend = fact_11 (nomer_glavi,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = virajenie_12 (stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = fact_12 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_12_backend))





    virajenie_13_backend = virajenie_13 (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          stih1, stih2, stih3, stih4,
                                          stih5, stih6,stih7)

    fact_13_backend = fact_13 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    stih1, stih2, stih3, stih4,
                                    stih5, stih6,stih7)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_13_backend))


    virajenie_14_backend = virajenie_14 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)

    fact_14_backend = fact_14 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_14_backend))


    virajenie_15_backend = virajenie_15 (number_stih_1, number_stih_2,
                                                number_stih_3, number_stih_4,
                                                number_stih_5, number_stih_6, number_stih_7,
                                                stih1, stih2, stih3, stih4,
                                                stih5, stih6,stih7, nomer_glavi,
                                                kolvo_stihov_glavi_user)
    
    fact_15_backend = fact_15 (number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                      stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7, nomer_glavi,
                                      kolvo_stihov_glavi_user)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_15_backend))


    summ_dlya_7_stiha_user = summ_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)

    summ_dlya_6_stiha_user = summ_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    summ_dlya_5_stiha_user = summ_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    summ_dlya_4_stiha_user = summ_dlya_4_stiha (stih1, stih2, stih3, stih4)
    summ_dlya_3_stiha_user = summ_dlya_3_stiha (stih1, stih2, stih3)
    summ_dlya_2_stiha_user = summ_dlya_2_stiha (stih1, stih2)


    progressia_bukv_dlya_7_stiha_user = progressia_bukv_dlya_7_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_bukv_dlya_6_stiha_user = progressia_bukv_dlya_6_stiha (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_bukv_dlya_5_stiha_user = progressia_bukv_dlya_5_stiha (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_bukv_dlya_4_stiha_user = progressia_bukv_dlya_4_stiha (stih1, stih2, stih3, stih4)
    progressia_bukv_dlya_3_stiha_user = progressia_bukv_dlya_3_stiha (stih1, stih2, stih3)

    progressia_bukv_dlya_2_stiha_user = progressia_bukv_dlya_2_stiha (stih1, stih2)
    


    
    progressia_dlya_cifrovogo_znachenia_7_user = progressia_dlya_cifrovogo_znachenia_7 (stih1, stih2, stih3, stih4,
                                      stih5, stih6,stih7)
    progressia_dlya_cifrovogo_znachenia_6_user = progressia_dlya_cifrovogo_znachenia_6 (stih1, stih2, stih3, stih4,
                                      stih5, stih6)
    progressia_dlya_cifrovogo_znachenia_5_user = progressia_dlya_cifrovogo_znachenia_5 (stih1, stih2, stih3, stih4,
                                      stih5)
    progressia_dlya_cifrovogo_znachenia_4_user = progressia_dlya_cifrovogo_znachenia_4 (stih1, stih2, stih3, stih4)
    progressia_dlya_cifrovogo_znachenia_3_user = progressia_dlya_cifrovogo_znachenia_3 (stih1, stih2, stih3)
    progressia_dlya_cifrovogo_znachenia_2_user = progressia_dlya_cifrovogo_znachenia_2 (stih1, stih2)



    bukvo_chislo_1_stiha = bukvo_chislo_stiha (stih1)
    bukvo_chislo_2_stiha = bukvo_chislo_stiha (stih2)
    bukvo_chislo_3_stiha = bukvo_chislo_stiha (stih3)
    bukvo_chislo_4_stiha = bukvo_chislo_stiha (stih4)
    bukvo_chislo_5_stiha = bukvo_chislo_stiha (stih5)
    bukvo_chislo_6_stiha = bukvo_chislo_stiha (stih6)
    bukvo_chislo_7_stiha = bukvo_chislo_stiha (stih7)

    the_check_fact_1_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = en1.proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = en1.proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))




    shetchiki_resultatov_user = en1.shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  en1.shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  en1.kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results_english_for_arabic.html' ,
                            the_title = 'The Mathematical Miracle of the Quran',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend,
                            the_check_fact_2 = the_check_fact_2_backend,
                            the_check_fact_1 = the_check_fact_1_backend,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)



@app.route ('/results_kazakh' , methods = ['POST'])
def results_kazakh () -> 'html' :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    stih_1_fatiha = 'بسم الله الرحمن الرحيم'
    stih_2_fatiha = 'الحمد لله رب العلمين'
    stih_3_fatiha = 'الرحمن الرحيم'
    stih_4_fatiha = 'ملك يوم الدين'
    stih_5_fatiha = 'إياك نعبد وإياك نستعين'
    stih_6_fatiha = 'اهدنا الصرط المستقيم'
    stih_7_fatiha = 'صرط الذين أنعمت عليهم غير المغضوب عليهم ولا الضالين'
    nomer_glavi_fatiha = 1
    number_stih_1_fatiha = 1
    number_stih_2_fatiha = 2
    number_stih_3_fatiha = 3
    number_stih_4_fatiha = 4
    number_stih_5_fatiha = 5
    number_stih_6_fatiha = 6
    number_stih_7_fatiha = 7
    kolvo_stihov_glavi_fatiha_backend = 7
    kolvo_stihov_glavi_user = 7
    nomer_glavi = request.form ['nomer_glavi']
    
    stih1 = str (request.form ['stih_1'])
    stih2 = str (request.form ['stih_2'])
    stih3 = str (request.form ['stih_3'])
    stih4 = str (request.form ['stih_4'])
    stih5 = str (request.form ['stih_5'])
    stih6 = str (request.form ['stih_6'])
    stih7 = str (request.form ['stih_7'])
    number_stih_1 = request.form ['number_stih_1']
    number_stih_2 = request.form ['number_stih_2']
    number_stih_3 = request.form ['number_stih_3']
    number_stih_4 = request.form ['number_stih_4']
    number_stih_5 = request.form ['number_stih_5']
    number_stih_6 = request.form ['number_stih_6']
    number_stih_7 = request.form ['number_stih_7']
    virajenie_1_fatiha = virajenie_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    fact_1_fatiha = fact_1 (nomer_glavi_fatiha , number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                            number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)
    
    virajenie_1_user = en3.virajenie_1 ( nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                                     number_stih_6 , number_stih_7)
    
    fact_1_user = "{0:.9f}".format(Decimal (en3.fact_1 (nomer_glavi, number_stih_1 , number_stih_2, number_stih_3 , number_stih_4 , number_stih_5 ,
                          number_stih_6 , number_stih_7)))
    kolvo_slov_1_fatiha_backend = kolvo_slov (stih_1_fatiha)
    kolvo_slov_2_fatiha_backend = kolvo_slov (stih_2_fatiha)
    kolvo_slov_3_fatiha_backend = kolvo_slov (stih_3_fatiha)
    kolvo_slov_4_fatiha_backend = kolvo_slov (stih_4_fatiha)
    kolvo_slov_5_fatiha_backend = kolvo_slov (stih_5_fatiha)
    kolvo_slov_6_fatiha_backend = kolvo_slov (stih_6_fatiha)
    kolvo_slov_7_fatiha_backend = kolvo_slov (stih_7_fatiha)

    virajenie_2_fatiha_backend = virajenie_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                              stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    
    fact_2_fatiha_backend = fact_2 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha,
                                    stih_7_fatiha, nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend)
    kolvo_slov_glavi_fatiha_backend = kolvo_slov_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    kolvo_slov_1_user = en1.kolvo_slov (stih1)
    kolvo_slov_2_user = en1.kolvo_slov (stih2)
    kolvo_slov_3_user = en1.kolvo_slov (stih3)
    kolvo_slov_4_user = en1.kolvo_slov (stih4)
    kolvo_slov_5_user = en1.kolvo_slov (stih5)
    kolvo_slov_6_user = en1.kolvo_slov (stih6)
    kolvo_slov_7_user = en1.kolvo_slov (stih7)

    kolvo_slov_glavi_user = en1.kolvo_slov_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    virajenie_2_user = en3.virajenie_2 (kolvo_slov_glavi_user,nomer_glavi, kolvo_stihov_glavi_user)
    fact_2_user = "{0:.9f}".format(Decimal (en3.fact_2 (kolvo_slov_glavi_user,nomer_glavi, kolvo_stihov_glavi_user)))

    sum_poryadkovih_nomerov_fatiha_backend = summa_poryadkovih_nomerov_stihov (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                                               number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha)

    kolvo_bukv_1_fatiha_backend = kolvo_bukv (stih_1_fatiha)
    kolvo_bukv_2_fatiha_backend = kolvo_bukv (stih_2_fatiha)
    kolvo_bukv_3_fatiha_backend = kolvo_bukv (stih_3_fatiha)
    kolvo_bukv_4_fatiha_backend = kolvo_bukv (stih_4_fatiha)
    kolvo_bukv_5_fatiha_backend = kolvo_bukv (stih_5_fatiha)
    kolvo_bukv_6_fatiha_backend = kolvo_bukv (stih_6_fatiha)
    kolvo_bukv_7_fatiha_backend = kolvo_bukv (stih_7_fatiha)
    kolvo_bukv_glavi_fatiha_backend = kolvo_bukv_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    spisok_bukv_1_fatiha_backend = spisok_bukv_stiha (stih_1_fatiha)
    spisok_bukv_2_fatiha_backend = spisok_bukv_stiha (stih_2_fatiha)
    spisok_bukv_3_fatiha_backend = spisok_bukv_stiha (stih_3_fatiha)
    spisok_bukv_4_fatiha_backend = spisok_bukv_stiha (stih_4_fatiha)
    spisok_bukv_5_fatiha_backend = spisok_bukv_stiha (stih_5_fatiha)
    spisok_bukv_6_fatiha_backend = spisok_bukv_stiha (stih_6_fatiha)
    spisok_bukv_7_fatiha_backend = spisok_bukv_stiha (stih_7_fatiha)

    spisok_bukv_cifr_1_fatiha_backend = spisok_cifr_stiha (stih_1_fatiha)
    spisok_bukv_cifr_2_fatiha_backend = spisok_cifr_stiha (stih_2_fatiha)
    spisok_bukv_cifr_3_fatiha_backend = spisok_cifr_stiha (stih_3_fatiha)
    spisok_bukv_cifr_4_fatiha_backend = spisok_cifr_stiha (stih_4_fatiha)
    spisok_bukv_cifr_5_fatiha_backend = spisok_cifr_stiha (stih_5_fatiha)
    spisok_bukv_cifr_6_fatiha_backend = spisok_cifr_stiha (stih_6_fatiha)
    spisok_bukv_cifr_7_fatiha_backend = spisok_cifr_stiha (stih_7_fatiha)

    сifr_znach_1_fatiha_backend = cifrovoe_znachenie_stiha (stih_1_fatiha)
    сifr_znach_2_fatiha_backend = cifrovoe_znachenie_stiha (stih_2_fatiha)
    сifr_znach_3_fatiha_backend = cifrovoe_znachenie_stiha (stih_3_fatiha)
    сifr_znach_4_fatiha_backend = cifrovoe_znachenie_stiha (stih_4_fatiha)
    сifr_znach_5_fatiha_backend = cifrovoe_znachenie_stiha (stih_5_fatiha)
    сifr_znach_6_fatiha_backend = cifrovoe_znachenie_stiha (stih_6_fatiha)
    сifr_znach_7_fatiha_backend = cifrovoe_znachenie_stiha (stih_7_fatiha)

    cifr_znach_glavi_fatiha_backend = cifrovoe_znachenie_glavi (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                                stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)


    the_virajenie_3_fatiha_backend = virajenie_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                                  number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                                  stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    the_results_3_fatiha_backend = fact_3 (number_stih_1_fatiha, number_stih_2_fatiha, number_stih_3_fatiha, number_stih_4_fatiha,
                                           number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha, stih_1_fatiha,
                                           stih_2_fatiha, stih_3_fatiha, stih_4_fatiha, stih_5_fatiha, stih_6_fatiha, stih_7_fatiha)

    
    sum_poryadkovih_nomerov_backend = en1.summa_poryadkovih_nomerov_stihov (int (number_stih_1), int (number_stih_2), int (number_stih_3), int (number_stih_4),
                                                                            int (number_stih_5), int (number_stih_6), int (number_stih_7))

    kolvo_bukv_1_user = en1.kolvo_bukv (stih1)
    kolvo_bukv_2_user = en1.kolvo_bukv (stih2)
    kolvo_bukv_3_user = en1.kolvo_bukv (stih3)
    kolvo_bukv_4_user = en1.kolvo_bukv (stih4)
    kolvo_bukv_5_user = en1.kolvo_bukv (stih5)
    kolvo_bukv_6_user = en1.kolvo_bukv (stih6)
    kolvo_bukv_7_user = en1.kolvo_bukv (stih7)

    kolvo_bukv_glavi_user = en1.kolvo_bukv_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    spisok_bukv_1_user = en1.spisok_bukv_stiha (stih1)
    spisok_bukv_2_user = en1.spisok_bukv_stiha (stih2)
    spisok_bukv_3_user = en1.spisok_bukv_stiha (stih3)
    spisok_bukv_4_user = en1.spisok_bukv_stiha (stih4)
    spisok_bukv_5_user = en1.spisok_bukv_stiha (stih5)
    spisok_bukv_6_user = en1.spisok_bukv_stiha (stih6)
    spisok_bukv_7_user = en1.spisok_bukv_stiha (stih7)

    spisok_bukv_cifr_1_user = kz1.spisok_cifr_stiha (stih1)
    spisok_bukv_cifr_2_user = kz1.spisok_cifr_stiha (stih2)
    spisok_bukv_cifr_3_user = kz1.spisok_cifr_stiha (stih3)
    spisok_bukv_cifr_4_user = kz1.spisok_cifr_stiha (stih4)
    spisok_bukv_cifr_5_user = kz1.spisok_cifr_stiha (stih5)
    spisok_bukv_cifr_6_user = kz1.spisok_cifr_stiha (stih6)
    spisok_bukv_cifr_7_user = kz1.spisok_cifr_stiha (stih7)

    сifr_znach_1_user = kz1.cifrovoe_znachenie_stiha (stih1)
    сifr_znach_2_user = kz1.cifrovoe_znachenie_stiha (stih2)
    сifr_znach_3_user = kz1.cifrovoe_znachenie_stiha (stih3)
    сifr_znach_4_user = kz1.cifrovoe_znachenie_stiha (stih4)
    сifr_znach_5_user = kz1.cifrovoe_znachenie_stiha (stih5)
    сifr_znach_6_user = kz1.cifrovoe_znachenie_stiha (stih6)
    сifr_znach_7_user = kz1.cifrovoe_znachenie_stiha (stih7)

    cifr_znach_glavi_user = kz1.cifrovoe_znachenie_glavi (stih1, stih2, stih3, stih4, stih5, stih6, stih7)

    the_virajenie_3_user = en3.virajenie_3 (sum_poryadkovih_nomerov_backend, kolvo_slov_glavi_user, kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    the_results_3_user = "{0:.9f}".format(Decimal (en3.fact_3 (sum_poryadkovih_nomerov_backend, kolvo_slov_glavi_user, kolvo_bukv_glavi_user, cifr_znach_glavi_user)))




    
    the_virajenie_4_fatiha_backend = virajenie_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                                  stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                  stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    the_fact_4_fatiha_backend = fact_4 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                        stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                        stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    the_check_fact_4_fatiha_backend = kz1.proverka_kratnosti_19 (Decimal (the_virajenie_4_fatiha_backend))



    virajenie_5_fatiha_backend = virajenie_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_5_fatiha_backend = fact_5 (nomer_glavi_fatiha, kolvo_stihov_glavi_fatiha_backend,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_5_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_5_fatiha_backend))

    
    virajenie_6_fatiha_backend = virajenie_6 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_6_fatiha_backend = fact_6 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    
    check_fact_6_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_6_fatiha_backend))

    virajenie_7_fatiha_backend = virajenie_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_7_fatiha_backend = fact_7 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_7_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_7_fatiha_backend))
    
    check_fact_7_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_7_fatiha_backend))

    virajenie_8_fatiha_backend = virajenie_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                              number_stih_3_fatiha, number_stih_4_fatiha,
                                              number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_8_fatiha_backend = fact_8 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_8_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_8_fatiha_backend))
    
    check_fact_8_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_8_fatiha_backend))



    virajenie_9_fatiha_backend = virajenie_9 (nomer_glavi_fatiha,
                                              stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                              stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_9_fatiha_backend = fact_9 (nomer_glavi_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_9_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_9_fatiha_backend))
    
    check_fact_9_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_9_fatiha_backend))


    virajenie_10_fatiha_backend = virajenie_10 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_10_fatiha_backend = fact_10 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_10_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_10_fatiha_backend))

    check_fact_10_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_10_fatiha_backend))

    virajenie_11_fatiha_backend = virajenie_11 (nomer_glavi_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_11_fatiha_backend = fact_11 (nomer_glavi_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_11_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_11_fatiha_backend))

    check_fact_11_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_11_fatiha_backend))


    virajenie_12_fatiha_backend = virajenie_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_12_fatiha_backend = fact_12 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_12_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_12_fatiha_backend))

    check_fact_12_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_12_fatiha_backend))




    virajenie_13_fatiha_backend = virajenie_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                          number_stih_3_fatiha, number_stih_4_fatiha,
                                          number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                          stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                          stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    fact_13_fatiha_backend = fact_13 (nomer_glavi_fatiha, number_stih_1_fatiha, number_stih_2_fatiha,
                                    number_stih_3_fatiha, number_stih_4_fatiha,
                                    number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                    stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                    stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    fact_13_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_13_fatiha_backend))
    
    check_fact_13_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_13_fatiha_backend))


    virajenie_14_fatiha_backend = virajenie_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_14_fatiha_backend = fact_14 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_14_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_14_fatiha_backend))
    
    check_fact_14_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_14_fatiha_backend))

    virajenie_15_fatiha_backend = virajenie_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                                number_stih_3_fatiha, number_stih_4_fatiha,
                                                number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                                stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                                stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                                kolvo_stihov_glavi_fatiha_backend)

    fact_15_fatiha_backend = fact_15 (number_stih_1_fatiha, number_stih_2_fatiha,
                                      number_stih_3_fatiha, number_stih_4_fatiha,
                                      number_stih_5_fatiha, number_stih_6_fatiha, number_stih_7_fatiha,
                                      stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha, nomer_glavi_fatiha,
                                      kolvo_stihov_glavi_fatiha_backend)
    fact_15_fatiha_backend_decimal = "{0:.1f}".format(Decimal (fact_15_fatiha_backend))
    
    check_fact_15_fatiha_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_15_fatiha_backend))


    summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)

    summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)


    progressia_bukv_dlya_7_stiha_fatiha = progressia_bukv_dlya_7_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_bukv_dlya_6_stiha_fatiha = progressia_bukv_dlya_6_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_bukv_dlya_5_stiha_fatiha = progressia_bukv_dlya_5_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_bukv_dlya_4_stiha_fatiha = progressia_bukv_dlya_4_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_bukv_dlya_3_stiha_fatiha = progressia_bukv_dlya_3_stiha (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)

    progressia_bukv_dlya_2_stiha_fatiha = progressia_bukv_dlya_2_stiha (stih_1_fatiha, stih_2_fatiha)
    


    
    progressia_dlya_cifrovogo_znachenia_7_fatiha = progressia_dlya_cifrovogo_znachenia_7 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha,stih_7_fatiha)
    progressia_dlya_cifrovogo_znachenia_6_fatiha = progressia_dlya_cifrovogo_znachenia_6 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha, stih_6_fatiha)
    progressia_dlya_cifrovogo_znachenia_5_fatiha = progressia_dlya_cifrovogo_znachenia_5 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha,
                                      stih_5_fatiha)
    progressia_dlya_cifrovogo_znachenia_4_fatiha = progressia_dlya_cifrovogo_znachenia_4 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha, stih_4_fatiha)
    progressia_dlya_cifrovogo_znachenia_3_fatiha = progressia_dlya_cifrovogo_znachenia_3 (stih_1_fatiha, stih_2_fatiha, stih_3_fatiha)
    progressia_dlya_cifrovogo_znachenia_2_fatiha = progressia_dlya_cifrovogo_znachenia_2 (stih_1_fatiha, stih_2_fatiha)



    bukvo_chislo_1_stiha_fatiha = bukvo_chislo_stiha (stih_1_fatiha)
    bukvo_chislo_2_stiha_fatiha = bukvo_chislo_stiha (stih_2_fatiha)
    bukvo_chislo_3_stiha_fatiha = bukvo_chislo_stiha (stih_3_fatiha)
    bukvo_chislo_4_stiha_fatiha = bukvo_chislo_stiha (stih_4_fatiha)
    bukvo_chislo_5_stiha_fatiha = bukvo_chislo_stiha (stih_5_fatiha)
    bukvo_chislo_6_stiha_fatiha = bukvo_chislo_stiha (stih_6_fatiha)
    bukvo_chislo_7_stiha_fatiha = bukvo_chislo_stiha (stih_7_fatiha)







    the_virajenie_4_backend = en3.virajenie_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                               kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user, kolvo_slov_4_user,
                                               kolvo_slov_5_user, kolvo_slov_6_user,kolvo_slov_7_user)

    fact_4_backend = en3.fact_4 (nomer_glavi, kolvo_stihov_glavi_user,
                                 kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user, kolvo_slov_4_user,
                                 kolvo_slov_5_user, kolvo_slov_6_user,kolvo_slov_7_user)
    fact_4_backend_decimal = "{0:.9f}".format(Decimal (fact_4_backend))
    
    the_check_fact_4_backend = kz1.proverka_kratnosti_19 ( Decimal (the_virajenie_4_backend))



    virajenie_5_backend = en3.virajenie_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                              kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    fact_5_backend = en3.fact_5 (nomer_glavi, kolvo_stihov_glavi_user,
                                   kolvo_bukv_glavi_user, cifr_znach_glavi_user)

    fact_5_backend_decimal = "{0:.9f}".format(Decimal (fact_5_backend))
    
    check_fact_5_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_5_backend))

    
    virajenie_6_backend = en3.virajenie_6 (nomer_glavi,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                             kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)

    fact_6_backend = en3.fact_6 (nomer_glavi,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                             kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)
    fact_6_backend_decimal = "{0:.9f}".format(Decimal (fact_6_backend))
    
    check_fact_6_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_6_backend))

    virajenie_7_backend = en3.virajenie_7 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                              kolvo_bukv_5_user, kolvo_bukv_6_user, kolvo_bukv_7_user, kolvo_bukv_glavi_user)

    fact_7_backend = en3.fact_7 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                              kolvo_bukv_5_user, kolvo_bukv_6_user, kolvo_bukv_7_user, kolvo_bukv_glavi_user)
    fact_7_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_7_backend)))
    #"{0:.9f}".format(Decimal (fact_7_backend))
    
    check_fact_7_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_7_backend))


    summ_dlya_7_stiha_user = en2.progressia_bukv_7 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)

    summ_dlya_6_stiha_user = en2.progressia_bukv_6 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user)
    summ_dlya_5_stiha_user = en2.progressia_bukv_5 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user)
    summ_dlya_4_stiha_user =  en2.progressia_bukv_4 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user)
    summ_dlya_3_stiha_user = en2.progressia_bukv_3 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user)
    summ_dlya_2_stiha_user = en2.progressia_bukv_2 (kolvo_bukv_1_user, kolvo_bukv_2_user)


    progressia_bukv_dlya_7_stiha_user = en2.progressia_bukv_7 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user)
    progressia_bukv_dlya_6_stiha_user = en2.progressia_bukv_6 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user, kolvo_bukv_6_user)
    progressia_bukv_dlya_5_stiha_user = en2.progressia_bukv_5 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                      kolvo_bukv_5_user)
    progressia_bukv_dlya_4_stiha_user = en2.progressia_bukv_4 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user)
    progressia_bukv_dlya_3_stiha_user = en2.progressia_bukv_3 (kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user)

    progressia_bukv_dlya_2_stiha_user = en2.progressia_bukv_2 (kolvo_bukv_1_user, kolvo_bukv_2_user)


    

    virajenie_8_backend = en3.virajenie_8 (nomer_glavi, number_stih_1, number_stih_2,
                                              number_stih_3, number_stih_4,
                                              number_stih_5, number_stih_6, number_stih_7,
                                              kolvo_bukv_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                       progressia_bukv_dlya_4_stiha_user,
                                              progressia_bukv_dlya_5_stiha_user, progressia_bukv_dlya_6_stiha_user,progressia_bukv_dlya_7_stiha_user)

    fact_8_backend = en3.fact_8 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                       progressia_bukv_dlya_4_stiha_user,
                                              progressia_bukv_dlya_5_stiha_user, progressia_bukv_dlya_6_stiha_user,progressia_bukv_dlya_7_stiha_user)

    fact_8_backend_decimal = Decimal('{:.9f}'.format(Decimal (fact_8_backend)))
    
    check_fact_8_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_8_backend))



    virajenie_9_backend = en3.virajenie_9 (nomer_glavi,
                                              kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)

    fact_9_backend = en3.fact_9 (nomer_glavi,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)
    fact_9_backend_decimal = "{0:.9f}".format(Decimal (fact_9_backend))
    
    check_fact_9_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_9_backend))


    virajenie_10_backend = en3.virajenie_10 (nomer_glavi,
                                                kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)

    fact_10_backend = en3.fact_10 (nomer_glavi,
                                      kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user,
                                                kolvo_bukv_5_user, kolvo_bukv_6_user,kolvo_bukv_7_user, сifr_znach_1_user,
                                         сifr_znach_2_user, сifr_znach_3_user, сifr_znach_4_user, сifr_znach_5_user,
                                         сifr_znach_6_user, сifr_znach_7_user)
    fact_10_backend_decimal = "{0:.9f}".format(Decimal (fact_10_backend))

    check_fact_10_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_10_backend))


    progressia_dlya_cifrovogo_znachenia_7_user = en2.progressia_dlya_cifrovogo_znachenia_7 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user, сifr_znach_6_user,сifr_znach_7_user)
    progressia_dlya_cifrovogo_znachenia_6_user = en2.progressia_dlya_cifrovogo_znachenia_6 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user, сifr_znach_6_user)
    progressia_dlya_cifrovogo_znachenia_5_user = en2.progressia_dlya_cifrovogo_znachenia_5 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user,
                                      сifr_znach_5_user)
    progressia_dlya_cifrovogo_znachenia_4_user = en2.progressia_dlya_cifrovogo_znachenia_4 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                                                                            сifr_znach_4_user)
    progressia_dlya_cifrovogo_znachenia_3_user = en2.progressia_dlya_cifrovogo_znachenia_3 (сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user)
    progressia_dlya_cifrovogo_znachenia_2_user = en2.progressia_dlya_cifrovogo_znachenia_2 (сifr_znach_1_user, сifr_znach_2_user)

    

    virajenie_11_backend = en3.virajenie_11 (nomer_glavi,
                                                kolvo_bukv_1_user, сifr_znach_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                                progressia_bukv_dlya_4_stiha_user, progressia_bukv_dlya_5_stiha_user,progressia_bukv_dlya_6_stiha_user,
                                         progressia_bukv_dlya_7_stiha_user, progressia_dlya_cifrovogo_znachenia_2_user,progressia_dlya_cifrovogo_znachenia_3_user,
                                         progressia_dlya_cifrovogo_znachenia_4_user,progressia_dlya_cifrovogo_znachenia_5_user,
                                         progressia_dlya_cifrovogo_znachenia_6_user,
                                         progressia_dlya_cifrovogo_znachenia_7_user)

    fact_11_backend = en3.fact_11 (nomer_glavi,
                                      kolvo_bukv_1_user, сifr_znach_1_user, progressia_bukv_dlya_2_stiha_user, progressia_bukv_dlya_3_stiha_user,
                                                progressia_bukv_dlya_4_stiha_user, progressia_bukv_dlya_5_stiha_user,progressia_bukv_dlya_6_stiha_user,
                                         progressia_bukv_dlya_7_stiha_user, progressia_dlya_cifrovogo_znachenia_2_user,progressia_dlya_cifrovogo_znachenia_3_user,
                                         progressia_dlya_cifrovogo_znachenia_4_user,progressia_dlya_cifrovogo_znachenia_5_user,
                                         progressia_dlya_cifrovogo_znachenia_6_user,
                                         progressia_dlya_cifrovogo_znachenia_7_user)
    getcontext().prec = 999
    fact_11_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_11_backend)))

    check_fact_11_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_11_backend))

    getcontext().prec = 999
    virajenie_12_backend = en3.virajenie_12 (kolvo_bukv_glavi_user, kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    fact_12_backend = en3.fact_12 (kolvo_bukv_glavi_user, kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    getcontext().prec = 999
    fact_12_backend_decimal = Decimal('{0:.9f}'.format(Decimal (fact_12_backend)))
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_12_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_12_backend))




    virajenie_13_backend = en3.virajenie_13 (nomer_glavi, number_stih_1, number_stih_2,
                                          number_stih_3, number_stih_4,
                                          number_stih_5, number_stih_6, number_stih_7,
                                          kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user,
                                             сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)

    fact_13_backend = en3.fact_13 (nomer_glavi, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                    kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user,
                                   сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    fact_13_backend_decimal = "{0:.9f}".format(Decimal (fact_13_backend))
    
    check_fact_13_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_13_backend))


    virajenie_14_backend = en3.virajenie_14 (nomer_glavi, kolvo_stihov_glavi_user,
                                      cifr_znach_glavi_user, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                                kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)

    fact_14_backend = en3.fact_14 (nomer_glavi, kolvo_stihov_glavi_user,
                                      cifr_znach_glavi_user, number_stih_1, number_stih_2,
                                    number_stih_3, number_stih_4,
                                    number_stih_5, number_stih_6, number_stih_7,
                                                kolvo_slov_1_user, kolvo_slov_2_user, kolvo_slov_3_user,
                                                kolvo_slov_4_user, kolvo_slov_5_user,kolvo_slov_6_user, kolvo_slov_7_user,
                                             kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, сifr_znach_1_user, сifr_znach_2_user, сifr_znach_3_user,
                                            сifr_znach_4_user, сifr_znach_5_user, сifr_znach_6_user, сifr_znach_7_user)
    fact_14_backend_decimal = "{0:.9f}".format(Decimal (fact_14_backend))
    
    check_fact_14_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_14_backend))

    bukvo_chislo_1_stiha = kz1.bukvo_chislo_stiha (stih1)
    bukvo_chislo_2_stiha = kz1.bukvo_chislo_stiha (stih2)
    bukvo_chislo_3_stiha = kz1.bukvo_chislo_stiha (stih3)
    bukvo_chislo_4_stiha = kz1.bukvo_chislo_stiha (stih4)
    bukvo_chislo_5_stiha = kz1.bukvo_chislo_stiha (stih5)
    bukvo_chislo_6_stiha = kz1.bukvo_chislo_stiha (stih6)
    bukvo_chislo_7_stiha = kz1.bukvo_chislo_stiha (stih7)

    virajenie_15_backend = en3.virajenie_15 (nomer_glavi,kolvo_stihov_glavi_user, number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                     kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, bukvo_chislo_1_stiha,
                                   bukvo_chislo_2_stiha,
                                   bukvo_chislo_3_stiha,
                                   bukvo_chislo_4_stiha,
                                   bukvo_chislo_5_stiha,
                                   bukvo_chislo_6_stiha,
                                   bukvo_chislo_7_stiha)
    
    fact_15_backend = en3.fact_15 (nomer_glavi,kolvo_stihov_glavi_user, number_stih_1, number_stih_2,
                                      number_stih_3, number_stih_4,
                                      number_stih_5, number_stih_6, number_stih_7,
                                     kolvo_bukv_1_user, kolvo_bukv_2_user, kolvo_bukv_3_user, kolvo_bukv_4_user, kolvo_bukv_5_user,
                                                    kolvo_bukv_6_user, kolvo_bukv_7_user, bukvo_chislo_1_stiha,
                                   bukvo_chislo_2_stiha,
                                   bukvo_chislo_3_stiha,
                                   bukvo_chislo_4_stiha,
                                   bukvo_chislo_5_stiha,
                                   bukvo_chislo_6_stiha,
                                   bukvo_chislo_7_stiha)
    fact_15_backend_decimal = "{0:.9f}".format(Decimal (fact_15_backend))

    
      
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    check_fact_15_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_15_backend))



    


    






    the_check_fact_1_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_1_user))
    the_check_fact_2_backend = kz1.proverka_kratnosti_19 ( Decimal (virajenie_2_user))
    the_check_fact_3_backend = kz1.proverka_kratnosti_19 ( Decimal (the_virajenie_3_user))


    shetchiki_resultatov_user = kz1.shetchiki_resultatov (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    shetchiki_resultatov_net_user =  kz1.shetchiki_resultatov_net (the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend,  check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)
    kolichestvo_proverok_kratnosti_user =  kz1.kolichestvo_proverok_kratnosti(the_check_fact_1_backend, the_check_fact_2_backend, the_check_fact_3_backend,
                                                      the_check_fact_4_backend, check_fact_5_backend, check_fact_6_backend,
                                                      check_fact_7_backend, check_fact_8_backend, check_fact_9_backend,
                                                      check_fact_10_backend, check_fact_9_backend, check_fact_12_backend,
                                                      check_fact_13_backend, check_fact_14_backend, check_fact_15_backend)


    
    
    return render_template ('results_kazakh.html' ,
                            the_title = 'The Mathematical Miracle of the Quran',
                            the_nomer_glavi_fatiha = nomer_glavi_fatiha,
                            the_stih_1_fatiha = stih_1_fatiha,
                            the_stih_2_fatiha = stih_2_fatiha,
                            the_stih_3_fatiha = stih_3_fatiha,
                            the_stih_4_fatiha = stih_4_fatiha,
                            the_stih_5_fatiha = stih_5_fatiha,
                            the_stih_6_fatiha = stih_6_fatiha,
                            the_stih_7_fatiha = stih_7_fatiha,
                            the_number_stih_1_fatiha = number_stih_1_fatiha,
                            the_number_stih_2_fatiha = number_stih_2_fatiha,
                            the_number_stih_3_fatiha = number_stih_3_fatiha,
                            the_number_stih_4_fatiha = number_stih_4_fatiha,
                            the_number_stih_5_fatiha = number_stih_5_fatiha,
                            the_number_stih_6_fatiha = number_stih_6_fatiha,
                            the_number_stih_7_fatiha = number_stih_7_fatiha,
                            the_virajenie_1_fatiha = virajenie_1_fatiha,
                            the_results_1_fatiha = fact_1_fatiha,
                            the_virajenie_1 = virajenie_1_user,
                            the_results_1 = fact_1_user,
                            kolvo_slov_1_fatiha = kolvo_slov_1_fatiha_backend,
                            kolvo_slov_2_fatiha = kolvo_slov_2_fatiha_backend,
                            kolvo_slov_3_fatiha = kolvo_slov_3_fatiha_backend,
                            kolvo_slov_4_fatiha = kolvo_slov_4_fatiha_backend,
                            kolvo_slov_5_fatiha = kolvo_slov_5_fatiha_backend,
                            kolvo_slov_6_fatiha = kolvo_slov_6_fatiha_backend,
                            kolvo_slov_7_fatiha = kolvo_slov_7_fatiha_backend,

                            kolvo_slov_glavi_fatiha = kolvo_slov_glavi_fatiha_backend,
                            kolvo_stihov_glavi_fatiha = kolvo_stihov_glavi_fatiha_backend,

                            the_virajenie_2_fatiha = virajenie_2_fatiha_backend,
                            the_results_2_fatiha = fact_2_fatiha_backend,

                            kolvo_slov_1 = kolvo_slov_1_user,
                            kolvo_slov_2 = kolvo_slov_2_user,
                            kolvo_slov_3 = kolvo_slov_3_user,
                            kolvo_slov_4 = kolvo_slov_4_user,
                            kolvo_slov_5 = kolvo_slov_5_user,
                            kolvo_slov_6 = kolvo_slov_6_user,
                            kolvo_slov_7 = kolvo_slov_7_user,
                            the_kolvo_slov_glavi = kolvo_slov_glavi_user,
                            the_kolvo_stihov_glavi = kolvo_stihov_glavi_user,

                            the_virajenie_2 = virajenie_2_user,
                            the_results_2 = fact_2_user,

                            sum_poryadkovih_nomerov_fatiha = sum_poryadkovih_nomerov_fatiha_backend,

                            kolvo_bukv_1_fatiha = kolvo_bukv_1_fatiha_backend,
                            kolvo_bukv_2_fatiha = kolvo_bukv_2_fatiha_backend,
                            kolvo_bukv_3_fatiha = kolvo_bukv_3_fatiha_backend,
                            kolvo_bukv_4_fatiha = kolvo_bukv_4_fatiha_backend,
                            kolvo_bukv_5_fatiha = kolvo_bukv_5_fatiha_backend,
                            kolvo_bukv_6_fatiha = kolvo_bukv_6_fatiha_backend,
                            kolvo_bukv_7_fatiha = kolvo_bukv_7_fatiha_backend,
                            kolvo_bukv_glavi_fatiha = kolvo_bukv_glavi_fatiha_backend,


                            spisok_bukv_1_fatiha = spisok_bukv_1_fatiha_backend,
                            spisok_bukv_2_fatiha = spisok_bukv_2_fatiha_backend,
                            spisok_bukv_3_fatiha = spisok_bukv_3_fatiha_backend,
                            spisok_bukv_4_fatiha = spisok_bukv_4_fatiha_backend,
                            spisok_bukv_5_fatiha = spisok_bukv_5_fatiha_backend,
                            spisok_bukv_6_fatiha = spisok_bukv_6_fatiha_backend,
                            spisok_bukv_7_fatiha = spisok_bukv_7_fatiha_backend,

                            spisok_bukv_cifr_1_fatiha = spisok_bukv_cifr_1_fatiha_backend,
                            spisok_bukv_cifr_2_fatiha = spisok_bukv_cifr_2_fatiha_backend,
                            spisok_bukv_cifr_3_fatiha = spisok_bukv_cifr_3_fatiha_backend,
                            spisok_bukv_cifr_4_fatiha = spisok_bukv_cifr_4_fatiha_backend,
                            spisok_bukv_cifr_5_fatiha = spisok_bukv_cifr_5_fatiha_backend,
                            spisok_bukv_cifr_6_fatiha = spisok_bukv_cifr_6_fatiha_backend,
                            spisok_bukv_cifr_7_fatiha = spisok_bukv_cifr_7_fatiha_backend,

                            сifr_znach_1_fatiha = сifr_znach_1_fatiha_backend,
                            сifr_znach_2_fatiha = сifr_znach_2_fatiha_backend,
                            сifr_znach_3_fatiha = сifr_znach_3_fatiha_backend,
                            сifr_znach_4_fatiha = сifr_znach_4_fatiha_backend,
                            сifr_znach_5_fatiha = сifr_znach_5_fatiha_backend,
                            сifr_znach_6_fatiha = сifr_znach_6_fatiha_backend,
                            сifr_znach_7_fatiha = сifr_znach_7_fatiha_backend,

                            cifr_znach_glavi_fatiha = cifr_znach_glavi_fatiha_backend,
                            
                            the_virajenie_3_fatiha = the_virajenie_3_fatiha_backend,
                            the_results_3_fatiha = the_results_3_fatiha_backend,

                            sum_poryadkovih_nomerov = sum_poryadkovih_nomerov_backend,

                            kolvo_bukv_1 = kolvo_bukv_1_user,
                            kolvo_bukv_2 = kolvo_bukv_2_user,
                            kolvo_bukv_3 = kolvo_bukv_3_user,
                            kolvo_bukv_4 = kolvo_bukv_4_user,
                            kolvo_bukv_5 = kolvo_bukv_5_user,
                            kolvo_bukv_6 = kolvo_bukv_6_user,
                            kolvo_bukv_7 = kolvo_bukv_7_user,

                            kolvo_bukv_glavi = kolvo_bukv_glavi_user,

                            spisok_bukv_1 = spisok_bukv_1_user,
                            spisok_bukv_2 = spisok_bukv_2_user,
                            spisok_bukv_3 = spisok_bukv_3_user,
                            spisok_bukv_4 = spisok_bukv_4_user,
                            spisok_bukv_5 = spisok_bukv_5_user,
                            spisok_bukv_6 = spisok_bukv_6_user,
                            spisok_bukv_7 = spisok_bukv_7_user,

                            spisok_bukv_cifr_1 = spisok_bukv_cifr_1_user,
                            spisok_bukv_cifr_2 = spisok_bukv_cifr_2_user,
                            spisok_bukv_cifr_3 = spisok_bukv_cifr_3_user,
                            spisok_bukv_cifr_4 = spisok_bukv_cifr_4_user,
                            spisok_bukv_cifr_5 = spisok_bukv_cifr_5_user,
                            spisok_bukv_cifr_6 = spisok_bukv_cifr_6_user,
                            spisok_bukv_cifr_7 = spisok_bukv_cifr_7_user,

                            сifr_znach_1 = сifr_znach_1_user,
                            сifr_znach_2 = сifr_znach_2_user,
                            сifr_znach_3 = сifr_znach_3_user,
                            сifr_znach_4 = сifr_znach_4_user,
                            сifr_znach_5 = сifr_znach_5_user,
                            сifr_znach_6 = сifr_znach_6_user,
                            сifr_znach_7 = сifr_znach_7_user,

                            cifr_znach_glavi = cifr_znach_glavi_user,

                            the_virajenie_3 = the_virajenie_3_user,
                            the_results_3 = the_results_3_user,





                            
                            
                            the_virajenie_4_fatiha = the_virajenie_4_fatiha_backend,
                            the_fact_4_fatiha = the_fact_4_fatiha_backend,
                            the_check_fact_4_fatiha = the_check_fact_4_fatiha_backend,

                            the_virajenie_5_fatiha = virajenie_5_fatiha_backend,
                            the_fact_5_fatiha = fact_5_fatiha_backend,
                            the_check_fact_5_fatiha = check_fact_5_fatiha_backend,


                            the_virajenie_6_fatiha = virajenie_6_fatiha_backend,
                            the_fact_6_fatiha = fact_6_fatiha_backend,
                            the_check_fact_6_fatiha = check_fact_6_fatiha_backend,

                            the_virajenie_7_fatiha = virajenie_7_fatiha_backend,
                            the_fact_7_fatiha = fact_7_fatiha_backend_decimal,
                            the_check_fact_7_fatiha = check_fact_7_fatiha_backend,

                            the_virajenie_8_fatiha = virajenie_8_fatiha_backend,
                            the_fact_8_fatiha = fact_8_fatiha_backend_decimal,
                            the_check_fact_8_fatiha = check_fact_8_fatiha_backend,

                            the_virajenie_9_fatiha = virajenie_9_fatiha_backend,
                            the_fact_9_fatiha = fact_9_fatiha_backend_decimal,
                            the_check_fact_9_fatiha = check_fact_9_fatiha_backend,

                            the_virajenie_10_fatiha = virajenie_10_fatiha_backend,
                            the_fact_10_fatiha = fact_10_fatiha_backend_decimal,
                            the_check_fact_10_fatiha = check_fact_10_fatiha_backend,

                            the_virajenie_11_fatiha = virajenie_11_fatiha_backend,
                            the_fact_11_fatiha = fact_11_fatiha_backend_decimal,
                            the_check_fact_11_fatiha = check_fact_11_fatiha_backend,

                            the_virajenie_12_fatiha = virajenie_12_fatiha_backend,
                            the_fact_12_fatiha = fact_12_fatiha_backend_decimal,
                            the_check_fact_12_fatiha = check_fact_12_fatiha_backend,

                            the_virajenie_13_fatiha = virajenie_13_fatiha_backend,
                            the_fact_13_fatiha = fact_13_fatiha_backend_decimal,
                            the_check_fact_13_fatiha = check_fact_13_fatiha_backend,

                            the_virajenie_14_fatiha = virajenie_14_fatiha_backend,
                            the_fact_14_fatiha = fact_14_fatiha_backend_decimal,
                            the_check_fact_14_fatiha = check_fact_14_fatiha_backend,


                            the_virajenie_15_fatiha = virajenie_15_fatiha_backend,
                            the_fact_15_fatiha = fact_15_fatiha_backend_decimal,
                            the_check_fact_15_fatiha = check_fact_15_fatiha_backend,

                            the_summ_dlya_7_stiha_fatiha = summ_dlya_7_stiha_fatiha,
                            the_summ_dlya_6_stiha_fatiha = summ_dlya_6_stiha_fatiha,
                            the_summ_dlya_5_stiha_fatiha = summ_dlya_5_stiha_fatiha,
                            the_summ_dlya_4_stiha_fatiha = summ_dlya_4_stiha_fatiha,
                            the_summ_dlya_3_stiha_fatiha = summ_dlya_3_stiha_fatiha,
                            the_summ_dlya_2_stiha_fatiha = summ_dlya_2_stiha_fatiha,


                            the_progressia_dlya_2_bukv_fatiha = progressia_bukv_dlya_2_stiha_fatiha,
                            the_progressia_dlya_3_bukv_fatiha = progressia_bukv_dlya_3_stiha_fatiha,
                            the_progressia_dlya_4_bukv_fatiha = progressia_bukv_dlya_4_stiha_fatiha,
                            the_progressia_dlya_5_bukv_fatiha = progressia_bukv_dlya_5_stiha_fatiha,
                            the_progressia_dlya_6_bukv_fatiha = progressia_bukv_dlya_6_stiha_fatiha,
                            the_progressia_dlya_7_bukv_fatiha = progressia_bukv_dlya_7_stiha_fatiha,


                            the_progressia_dlya_7_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_7_fatiha,
                            the_progressia_dlya_6_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_6_fatiha,
                            the_progressia_dlya_5_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_5_fatiha,
                            the_progressia_dlya_4_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_4_fatiha,
                            the_progressia_dlya_3_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_3_fatiha,
                            the_progressia_dlya_2_cifrovogo_znachenia_fatiha = progressia_dlya_cifrovogo_znachenia_2_fatiha,


                            the_bukvo_chislo_stiha_1_fatiha = bukvo_chislo_1_stiha_fatiha,
                            the_bukvo_chislo_stiha_2_fatiha = bukvo_chislo_2_stiha_fatiha,
                            the_bukvo_chislo_stiha_3_fatiha = bukvo_chislo_3_stiha_fatiha,
                            the_bukvo_chislo_stiha_4_fatiha = bukvo_chislo_4_stiha_fatiha,
                            the_bukvo_chislo_stiha_5_fatiha = bukvo_chislo_5_stiha_fatiha,
                            the_bukvo_chislo_stiha_6_fatiha = bukvo_chislo_6_stiha_fatiha,
                            the_bukvo_chislo_stiha_7_fatiha = bukvo_chislo_7_stiha_fatiha,






                            the_virajenie_4 = the_virajenie_4_backend,
                            the_fact_4 = fact_4_backend_decimal,
                            the_check_fact_4 = the_check_fact_4_backend,

                            the_virajenie_5 = virajenie_5_backend,
                            the_fact_5 = fact_5_backend_decimal,
                            the_check_fact_5 = check_fact_5_backend,


                            the_virajenie_6 = virajenie_6_backend,
                            the_fact_6 = fact_6_backend_decimal,
                            the_check_fact_6 = check_fact_6_backend,

                            the_virajenie_7 = virajenie_7_backend,
                            the_fact_7 = fact_7_backend_decimal,
                            the_check_fact_7 = check_fact_7_backend,

                            the_virajenie_8 = virajenie_8_backend,
                            the_fact_8 = fact_8_backend_decimal,
                            the_check_fact_8 = check_fact_8_backend,

                            the_virajenie_9 = virajenie_9_backend,
                            the_fact_9 = fact_9_backend_decimal,
                            the_check_fact_9 = check_fact_9_backend,

                            the_virajenie_10 = virajenie_10_backend,
                            the_fact_10 = fact_10_backend_decimal,
                            the_check_fact_10 = check_fact_10_backend,

                            the_virajenie_11 = virajenie_11_backend,
                            the_fact_11 = fact_11_backend_decimal,
                            the_check_fact_11 = check_fact_11_backend,

                            the_virajenie_12 = virajenie_12_backend,
                            the_fact_12 = fact_12_backend_decimal,
                            the_check_fact_12 = check_fact_12_backend,

                            the_virajenie_13 = virajenie_13_backend,
                            the_fact_13 = fact_13_backend_decimal,
                            the_check_fact_13 = check_fact_13_backend,

                            the_virajenie_14 = virajenie_14_backend,
                            the_fact_14 = fact_14_backend_decimal,
                            the_check_fact_14 = check_fact_14_backend,


                            the_virajenie_15 = virajenie_15_backend,
                            the_fact_15 = fact_15_backend_decimal,
                            the_check_fact_15 = check_fact_15_backend,

                            the_summ_dlya_7_stiha = summ_dlya_7_stiha_user,
                            the_summ_dlya_6_stiha = summ_dlya_6_stiha_user,
                            the_summ_dlya_5_stiha = summ_dlya_5_stiha_user,
                            the_summ_dlya_4_stiha = summ_dlya_4_stiha_user,
                            the_summ_dlya_3_stiha = summ_dlya_3_stiha_user,
                            the_summ_dlya_2_stiha = summ_dlya_2_stiha_user,


                            the_progressia_dlya_2_bukv = progressia_bukv_dlya_2_stiha_user,
                            the_progressia_dlya_3_bukv = progressia_bukv_dlya_3_stiha_user,
                            the_progressia_dlya_4_bukv = progressia_bukv_dlya_4_stiha_user,
                            the_progressia_dlya_5_bukv = progressia_bukv_dlya_5_stiha_user,
                            the_progressia_dlya_6_bukv = progressia_bukv_dlya_6_stiha_user,
                            the_progressia_dlya_7_bukv = progressia_bukv_dlya_7_stiha_user,


                            the_progressia_dlya_7_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_7_user,
                            the_progressia_dlya_6_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_6_user,
                            the_progressia_dlya_5_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_5_user,
                            the_progressia_dlya_4_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_4_user,
                            the_progressia_dlya_3_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_3_user,
                            the_progressia_dlya_2_cifrovogo_znachenia = progressia_dlya_cifrovogo_znachenia_2_user,


                            the_bukvo_chislo_stiha_1 = bukvo_chislo_1_stiha,
                            the_bukvo_chislo_stiha_2 = bukvo_chislo_2_stiha,
                            the_bukvo_chislo_stiha_3 = bukvo_chislo_3_stiha,
                            the_bukvo_chislo_stiha_4 = bukvo_chislo_4_stiha,
                            the_bukvo_chislo_stiha_5 = bukvo_chislo_5_stiha,
                            the_bukvo_chislo_stiha_6 = bukvo_chislo_6_stiha,
                            the_bukvo_chislo_stiha_7 = bukvo_chislo_7_stiha,



                            the_check_fact_3 = the_check_fact_3_backend,
                            the_check_fact_2 = the_check_fact_2_backend,
                            the_check_fact_1 = the_check_fact_1_backend,

                            the_shetchiki_resultatov = shetchiki_resultatov_user,
                            the_shetchiki_resultatov_net = shetchiki_resultatov_net_user,
                            the_kolichestvo_proverok_kratnosti = kolichestvo_proverok_kratnosti_user,
                            
                            the_nomer_glavi = nomer_glavi,
                            the_stih_1 = stih1,
                            the_stih_2 = stih2,
                            the_stih_3 = stih3,
                            the_stih_4 = stih4,
                            the_stih_5 = stih5,
                            the_stih_6 = stih6,
                            the_stih_7 = stih7,
                            the_number_stih_1 = number_stih_1,
                            the_number_stih_2 = number_stih_2,
                            the_number_stih_3 = number_stih_3,
                            the_number_stih_4 = number_stih_4,
                            the_number_stih_5 = number_stih_5,
                            the_number_stih_6 = number_stih_6,
                            the_number_stih_7 = number_stih_7,
                            the_kolvo_stihov_glavi_user = kolvo_stihov_glavi_user,
                            the_results = results,)



if __name__  == '__main__' :
        app.run(debug=True)
