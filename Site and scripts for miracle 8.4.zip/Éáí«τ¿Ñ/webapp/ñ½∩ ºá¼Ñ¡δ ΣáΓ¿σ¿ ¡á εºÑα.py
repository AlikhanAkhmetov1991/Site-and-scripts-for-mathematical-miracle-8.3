





import locale
locale.setlocale(locale.LC_NUMERIC, "ru_RU.UTF-8")

numint = 200000000.000332432

print(f'{numint:n}')






print (locale.format_string('%.9f', numint, grouping=True))





    
