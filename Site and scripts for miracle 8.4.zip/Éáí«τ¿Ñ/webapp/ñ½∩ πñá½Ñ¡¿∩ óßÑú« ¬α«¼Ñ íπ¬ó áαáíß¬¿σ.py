import re

data = "سيءؤ ضثض1123يسس0.... .."

dataForCalculations = map (lambda val : re.sub ("[^\u0621-\u064A]+","", val), data)
print (str (dataForCalculations))

print (re.sub ("[^\u0621-\u064A ]+","", data, gmiu))
