
import re
from decimal import *

def spisok_cifr_stiha (stih : str, bukva_1 : str , bukva_2 :str , bukva_3 : str ,
                       bukva_4 : str , bukva_5 : str , bukva_6 : str ,
                       bukva_7 : str , bukva_8 : str , bukva_9 : str , bukva_10 : str , bukva_11 : str , bukva_12 : str , bukva_13 : str , bukva_14 : str ,
                       bukva_15 : str , bukva_16 : str , bukva_17 : str , bukva_18 : str , bukva_19 : str , bukva_20 : str , bukva_21 : str , bukva_22 : str ,
                       bukva_23 : str , bukva_24 : str , bukva_25 : str , bukva_26 : str ,
                       cifra_1 : str, cifra_2 : str, cifra_3 : str, cifra_4 : str , cifra_5 : str, cifra_6 : str , cifra_7 : str,
                       cifra_8 : str, cifra_9 : str, cifra_10 : str, cifra_11 : str, cifra_12 : str, cifra_13 : str, cifra_14 : str, cifra_15 : str,
                       cifra_16 : str, cifra_17 : str, cifra_18 : str, cifra_19 : str, cifra_20 : str, cifra_21 : str,
                       cifra_22 : str, cifra_23 : str, cifra_24 : str, cifra_25 : str, cifra_26 : str) -> list :
    """Создаем список цифр стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace (bukva_1 , cifra_1) for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace (bukva_2 , cifra_2) for elem in result_g1]
    result_g1 = [elem.replace (bukva_3 , cifra_3) for elem in result_g1]
    result_g1 = [elem.replace (bukva_4 , cifra_4) for elem in result_g1]
    result_g1 = [elem.replace (bukva_5 , cifra_5) for elem in result_g1]
    result_g1 = [elem.replace (bukva_6 , cifra_6) for elem in result_g1]
    result_g1 = [elem.replace (bukva_7 , cifra_7) for elem in result_g1]
    result_g1 = [elem.replace (bukva_8 , cifra_8) for elem in result_g1]
    result_g1 = [elem.replace (bukva_9 , cifra_9) for elem in result_g1]
    result_g1 = [elem.replace (bukva_10 , cifra_10) for elem in result_g1]
    result_g1 = [elem.replace (bukva_11 , cifra_11) for elem in result_g1]
    result_g1 = [elem.replace (bukva_12 , cifra_12) for elem in result_g1]
    result_g1 = [elem.replace (bukva_13 , cifra_13) for elem in result_g1]
    result_g1 = [elem.replace (bukva_14 , cifra_14) for elem in result_g1]
    result_g1 = [elem.replace (bukva_15 , cifra_15) for elem in result_g1]
    result_g1 = [elem.replace (bukva_16 , cifra_16) for elem in result_g1]
    result_g1 = [elem.replace (bukva_17 , cifra_17) for elem in result_g1]
    result_g1 = [elem.replace (bukva_18 , cifra_18) for elem in result_g1]
    result_g1 = [elem.replace (bukva_19 , cifra_19) for elem in result_g1]
    result_g1 = [elem.replace (bukva_20 , cifra_20) for elem in result_g1]
    result_g1 = [elem.replace (bukva_21 , cifra_21) for elem in result_g1]
    result_g1 = [elem.replace (bukva_22 , cifra_22) for elem in result_g1]
    result_g1 = [elem.replace (bukva_23 , cifra_23) for elem in result_g1]
    result_g1 = [elem.replace (bukva_24 , cifra_24) for elem in result_g1]
    result_g1 = [elem.replace (bukva_25 , cifra_25) for elem in result_g1]
    spisok_cifr_stiha = [elem.replace (bukva_26 , cifra_26) for elem in result_g1]

    return spisok_cifr_stiha

def cifrovoe_znachenie_stiha (stih : str) -> int :
    """Узнаем цифровое значение стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace (bukva_1 , cifra_1) for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace (bukva_2 , cifra_2) for elem in result_g1]
    result_g1 = [elem.replace (bukva_3 , cifra_3) for elem in result_g1]
    result_g1 = [elem.replace (bukva_4 , cifra_4) for elem in result_g1]
    result_g1 = [elem.replace (bukva_5 , cifra_5) for elem in result_g1]
    result_g1 = [elem.replace (bukva_6 , cifra_6) for elem in result_g1]
    result_g1 = [elem.replace (bukva_7 , cifra_7) for elem in result_g1]
    result_g1 = [elem.replace (bukva_8 , cifra_8) for elem in result_g1]
    result_g1 = [elem.replace (bukva_9 , cifra_9) for elem in result_g1]
    result_g1 = [elem.replace (bukva_10 , cifra_10) for elem in result_g1]
    result_g1 = [elem.replace (bukva_11 , cifra_11) for elem in result_g1]
    result_g1 = [elem.replace (bukva_12 , cifra_12) for elem in result_g1]
    result_g1 = [elem.replace (bukva_13 , cifra_13) for elem in result_g1]
    result_g1 = [elem.replace (bukva_14 , cifra_14) for elem in result_g1]
    result_g1 = [elem.replace (bukva_15 , cifra_15) for elem in result_g1]
    result_g1 = [elem.replace (bukva_16 , cifra_16) for elem in result_g1]
    result_g1 = [elem.replace (bukva_17 , cifra_17) for elem in result_g1]
    result_g1 = [elem.replace (bukva_18 , cifra_18) for elem in result_g1]
    result_g1 = [elem.replace (bukva_19 , cifra_19) for elem in result_g1]
    result_g1 = [elem.replace (bukva_20 , cifra_20) for elem in result_g1]
    result_g1 = [elem.replace (bukva_21 , cifra_21) for elem in result_g1]
    result_g1 = [elem.replace (bukva_22 , cifra_22) for elem in result_g1]
    result_g1 = [elem.replace (bukva_23 , cifra_23) for elem in result_g1]
    result_g1 = [elem.replace (bukva_24 , cifra_24) for elem in result_g1]
    result_g1 = [elem.replace (bukva_25 , cifra_25) for elem in result_g1]
    spisok_cifr_stiha = [elem.replace (bukva_26 , cifra_26) for elem in result_g1]
    
    spisok_cifr_stiha_int = [int  (x) for x  in spisok_cifr_stiha]
    cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_int)
    return cifrovoe_znachenie_stiha

def cifrovoe_znachenie_glavi (stih_1 : str, stih_2 : str , stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace (bukva_1 , cifra_1) for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace (bukva_2 , cifra_2) for elem in result_g1]
        result_g1 = [elem.replace (bukva_3 , cifra_3) for elem in result_g1]
        result_g1 = [elem.replace (bukva_4 , cifra_4) for elem in result_g1]
        result_g1 = [elem.replace (bukva_5 , cifra_5) for elem in result_g1]
        result_g1 = [elem.replace (bukva_6 , cifra_6) for elem in result_g1]
        result_g1 = [elem.replace (bukva_7 , cifra_7) for elem in result_g1]
        result_g1 = [elem.replace (bukva_8 , cifra_8) for elem in result_g1]
        result_g1 = [elem.replace (bukva_9 , cifra_9) for elem in result_g1]
        result_g1 = [elem.replace (bukva_10 , cifra_10) for elem in result_g1]
        result_g1 = [elem.replace (bukva_11 , cifra_11) for elem in result_g1]
        result_g1 = [elem.replace (bukva_12 , cifra_12) for elem in result_g1]
        result_g1 = [elem.replace (bukva_13 , cifra_13) for elem in result_g1]
        result_g1 = [elem.replace (bukva_14 , cifra_14) for elem in result_g1]
        result_g1 = [elem.replace (bukva_15 , cifra_15) for elem in result_g1]
        result_g1 = [elem.replace (bukva_16 , cifra_16) for elem in result_g1]
        result_g1 = [elem.replace (bukva_17 , cifra_17) for elem in result_g1]
        result_g1 = [elem.replace (bukva_18 , cifra_18) for elem in result_g1]
        result_g1 = [elem.replace (bukva_19 , cifra_19) for elem in result_g1]
        result_g1 = [elem.replace (bukva_20 , cifra_20) for elem in result_g1]
        result_g1 = [elem.replace (bukva_21 , cifra_21) for elem in result_g1]
        result_g1 = [elem.replace (bukva_22 , cifra_22) for elem in result_g1]
        result_g1 = [elem.replace (bukva_23 , cifra_23) for elem in result_g1]
        result_g1 = [elem.replace (bukva_24 , cifra_24) for elem in result_g1]
        result_g1 = [elem.replace (bukva_25 , cifra_25) for elem in result_g1]
        spisok_cifr_stiha = [elem.replace (bukva_26 , cifra_26) for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
        
    return cifrovoe_znachenie_glavi

def bukvo_chislo_stiha (stih : str) -> str :
    """Узнаем букво-число стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace (bukva_1 , cifra_1) for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace (bukva_2 , cifra_2) for elem in result_g1]
    result_g1 = [elem.replace (bukva_3 , cifra_3) for elem in result_g1]
    result_g1 = [elem.replace (bukva_4 , cifra_4) for elem in result_g1]
    result_g1 = [elem.replace (bukva_5 , cifra_5) for elem in result_g1]
    result_g1 = [elem.replace (bukva_6 , cifra_6) for elem in result_g1]
    result_g1 = [elem.replace (bukva_7 , cifra_7) for elem in result_g1]
    result_g1 = [elem.replace (bukva_8 , cifra_8) for elem in result_g1]
    result_g1 = [elem.replace (bukva_9 , cifra_9) for elem in result_g1]
    result_g1 = [elem.replace (bukva_10 , cifra_10) for elem in result_g1]
    result_g1 = [elem.replace (bukva_11 , cifra_11) for elem in result_g1]
    result_g1 = [elem.replace (bukva_12 , cifra_12) for elem in result_g1]
    result_g1 = [elem.replace (bukva_13 , cifra_13) for elem in result_g1]
    result_g1 = [elem.replace (bukva_14 , cifra_14) for elem in result_g1]
    result_g1 = [elem.replace (bukva_15 , cifra_15) for elem in result_g1]
    result_g1 = [elem.replace (bukva_16 , cifra_16) for elem in result_g1]
    result_g1 = [elem.replace (bukva_17 , cifra_17) for elem in result_g1]
    result_g1 = [elem.replace (bukva_18 , cifra_18) for elem in result_g1]
    result_g1 = [elem.replace (bukva_19 , cifra_19) for elem in result_g1]
    result_g1 = [elem.replace (bukva_20 , cifra_20) for elem in result_g1]
    result_g1 = [elem.replace (bukva_21 , cifra_21) for elem in result_g1]
    result_g1 = [elem.replace (bukva_22 , cifra_22) for elem in result_g1]
    result_g1 = [elem.replace (bukva_23 , cifra_23) for elem in result_g1]
    result_g1 = [elem.replace (bukva_24 , cifra_24) for elem in result_g1]
    result_g1 = [elem.replace (bukva_25 , cifra_25) for elem in result_g1]
    spisok_cifr_stiha = [elem.replace (bukva_26 , cifra_26) for elem in result_g1]
    
    spisok_cifr_stiha_str = [str  (x) for x  in spisok_cifr_stiha]
    bukvo_chislo_stiha = ''.join(spisok_cifr_stiha_str)

    return bukvo_chislo_stiha
