from for_English_slova_bukvi_znachenia_kratnosti import *

def progressia_bukv_2 (kolvo_bukv_1 : int, kolvo_bukv_2 : int) -> str :
    progressia_bukv_2 = str (kolvo_bukv_1 + kolvo_bukv_2)
    return progressia_bukv_2

def progressia_bukv_3 (kolvo_bukv_1 : int, kolvo_bukv_2 : int, kolvo_bukv_3 : int) -> str :

    progressia_bukv_3 = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3)
    return progressia_bukv_3

def progressia_bukv_4 (kolvo_bukv_1 : int, kolvo_bukv_2 : int, kolvo_bukv_3 : int, kolvo_bukv_4 : int) -> str :

    progressia_bukv_4 = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4)
    return progressia_bukv_4

def progressia_bukv_5 (kolvo_bukv_1 : int, kolvo_bukv_2 : int, kolvo_bukv_3 : int, kolvo_bukv_4 : int, kolvo_bukv_5 : int) -> str :

    progressia_bukv_5 = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5)
    return progressia_bukv_5

def progressia_bukv_6 (kolvo_bukv_1 : int, kolvo_bukv_2 : int, kolvo_bukv_3 : int, kolvo_bukv_4 : int, kolvo_bukv_5 : int,
                       kolvo_bukv_6 : int) -> str :

    progressia_bukv_6 = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6)
    return progressia_bukv_6

def progressia_bukv_7 (kolvo_bukv_1 : int, kolvo_bukv_2 : int, kolvo_bukv_3 : int, kolvo_bukv_4 : int, kolvo_bukv_5 : int,
                       kolvo_bukv_6 : int, kolvo_bukv_7 : int) -> str :

    progressia_bukv_7 = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)
    return progressia_bukv_7

def progressia_dlya_cifrovogo_znachenia_7 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int, cifrovoe_znachenie_stiha_3 : int,
                                            cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
                                            cifrovoe_znachenie_stiha_7 : int) -> int :
    progressia_dlya_7_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6 +
                                             cifrovoe_znachenie_stiha_7)
    return progressia_dlya_7_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_6 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int, cifrovoe_znachenie_stiha_3 : int,
                                            cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int) -> int :
    progressia_dlya_6_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6)
    return progressia_dlya_6_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_5 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int, cifrovoe_znachenie_stiha_3 : int,
                                            cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int) -> int :
    progressia_dlya_5_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5)
    return progressia_dlya_5_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_4 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int, cifrovoe_znachenie_stiha_3 : int,
                                            cifrovoe_znachenie_stiha_4 : int) -> int :
    progressia_dlya_4_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4)
    return progressia_dlya_4_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_3 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int, cifrovoe_znachenie_stiha_3 : int) -> int :
    progressia_dlya_3_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3)
    return progressia_dlya_3_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_2 ( cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int) -> int :
    progressia_dlya_2_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2)
    return progressia_dlya_2_cifrovogo_znachenia


