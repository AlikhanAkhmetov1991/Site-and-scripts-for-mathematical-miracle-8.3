from setuptools import setup

setup (
    name = 'for_English_progressii' ,
    version = '1.0',
    description = 'Mathematical miracles of Quran, Al-Fatiha, facts 1-15, only english functions',
    author = 'Alikhan Akhmetov',
    author_email = 'ahmetov_alihan@mail.ru',
    url = 'https://ahmetovalihan.pythonanywhere.com/english',
    py_modules = ['for_English_progressii'],
)
