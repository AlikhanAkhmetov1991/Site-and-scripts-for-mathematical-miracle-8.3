
import re
from decimal import *

def kolvo_slov (stih) -> int :
    """Количество слов в стихе"""
    stih_list = stih.split ()
    kolvo_slov = len(stih_list)
    return kolvo_slov

def kolvo_slov_glavi (stih_1 : str, stih_2 :str , stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ) -> int :
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov_glavi = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7
    return kolvo_slov_glavi

def summa_poryadkovih_nomerov_stihov (nomer_stiha_1 : int, nomer_stiha_2 : int, nomer_stiha_3 : int,
                                      nomer_stiha_4 : int, nomer_stiha_5 : int, nomer_stiha_6 : int, nomer_stiha_7 : int) -> int :
    summa_poryadkovih_nomerov_stihov = nomer_stiha_1 + nomer_stiha_2 + nomer_stiha_3 + nomer_stiha_4 + nomer_stiha_5 + nomer_stiha_6 + nomer_stiha_7
    return summa_poryadkovih_nomerov_stihov

def kolvo_bukv (stih : str) -> int :
    """Считаем количество букв стиха"""
    stroka_bez_probela = re.sub (' ' ,'', stih)
    kolvo_bukv_stiha = len (stroka_bez_probela)
    return kolvo_bukv_stiha

def kolvo_bukv_glavi (stih_1 : str, stih_2 : str, stih_3 : str , stih_4 :str , stih_5 :str , stih_6 :str, stih_7 :str) -> int :
    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    return kolvo_bukv_glavi

def spisok_bukv_stiha (stih : str) -> list :
    """Создаем список букв стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    return spisok_bukv_stiha
def spisok_cifr_stiha (stih : str, ) -> list :
    """Создаем список цифр стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('A' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('a' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('B' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('b' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('C' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('c' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('D' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('d' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('E' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('e' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('F' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('f' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('G' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('g' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('H' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('h' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('I' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('i' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('J' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('j' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('K' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('k' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('L' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('l' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('M' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('m' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('N' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('n' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('O' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('o' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('P' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('p' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('Q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('R' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('r' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('S' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('s' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('T' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('t' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('U' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('u' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('V' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('v' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('W' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('w' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('X' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('x' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('Z' , '800') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('z' , '800') for elem in result_g1]

    return spisok_cifr_stiha

def cifrovoe_znachenie_stiha (stih : str) -> int :
    """Узнаем цифровое значение стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('A' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('a' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('B' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('b' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('C' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('c' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('D' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('d' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('E' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('e' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('F' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('f' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('G' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('g' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('H' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('h' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('I' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('i' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('J' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('j' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('K' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('k' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('L' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('l' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('M' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('m' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('N' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('n' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('O' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('o' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('P' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('p' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('Q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('R' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('r' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('S' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('s' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('T' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('t' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('U' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('u' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('V' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('v' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('W' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('w' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('X' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('x' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('Z' , '800') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('z' , '800') for elem in result_g1]
    
    spisok_cifr_stiha_int = [int  (x) for x  in spisok_cifr_stiha]
    cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_int)
    return cifrovoe_znachenie_stiha

def cifrovoe_znachenie_glavi (stih_1 : str, stih_2 : str , stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('A' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('a' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('B' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('b' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('C' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('c' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('D' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('d' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('E' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('e' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('F' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('f' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('G' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('g' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('H' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('h' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('I' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('i' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('J' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('j' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('K' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('k' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('L' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('l' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('M' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('m' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('N' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('n' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('O' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('o' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('P' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('p' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('Q' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('q' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('R' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('r' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('S' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('s' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('T' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('t' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('U' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('u' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('V' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('v' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('W' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('w' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('X' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('x' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('Y' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('y' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('Z' , '800') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('z' , '800') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
        
    return cifrovoe_znachenie_glavi

def bukvo_chislo_stiha (stih : str) -> str :
    """Узнаем букво-число стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('A' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('a' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('B' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('b' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('C' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('c' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('D' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('d' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('E' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('e' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('F' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('f' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('G' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('g' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('H' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('h' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('I' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('i' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('J' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('j' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('K' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('k' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('L' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('l' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('M' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('m' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('N' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('n' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('O' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('o' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('P' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('p' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('Q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('q' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('R' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('r' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('S' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('s' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('T' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('t' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('U' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('u' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('V' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('v' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('W' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('w' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('X' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('x' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('y' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('Z' , '800') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('z' , '800') for elem in result_g1]
    
    spisok_cifr_stiha_str = [str  (x) for x  in spisok_cifr_stiha]
    bukvo_chislo_stiha = ''.join(spisok_cifr_stiha_str)

    return bukvo_chislo_stiha

def proverka_kratnosti_19 (virajenie : int) -> str :
    virajenie_decimal = Decimal (virajenie % 19)
    if virajenie_decimal == 0 :
        return 'Yes'
    else: return 'No'

def  shetchiki_resultatov (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Yes' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_da

def  shetchiki_resultatov_net (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Yes' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_net

def kolichestvo_proverok_kratnosti (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    kolichestvo_proverok_kratnosti = len (spisok_shetchika)
    return kolichestvo_proverok_kratnosti

def fact_str_iz_int (virajenie : int) -> str :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_decimal = Decimal (virajenie)
    divisor = Decimal ('19')
    fact = Decimal (virajenie_decimal / divisor)
    fact_str = str (fact)
    return fact_str

