import re
from decimal import *
from for_English_slova_bukvi_znachenia_kratnosti import *


def virajenie_1 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
                 nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int) -> int :
    """Выражение  первого факта = номер главы + номер стиха первого + номер стиха второго и так до последнего стиха включительно"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

   

    virajenie_1 = nomer_glavi_str + nomer_stiha_1_str + nomer_stiha_2_str + nomer_stiha_3_str + nomer_stiha_4_str + nomer_stiha_5_str+ nomer_stiha_6_str +nomer_stiha_7_str
    return  int(virajenie_1)
    
def fact_1 (nomer_glavi : int, nomer_stiha1 :int , nomer_stiha2 : int,nomer_stiha3 :int, nomer_stiha4 :int ,
            nomer_stiha5 : int, nomer_stiha6 : int, nomer_stiha7 : int) -> float :
    """Факт 1 = номер главы + номер стиха первого + номер стиха второго и так до последнего стиха включительно потом поделить на 19"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

   

    virajenie_1 = nomer_glavi_str + nomer_stiha_1_str + nomer_stiha_2_str + nomer_stiha_3_str + nomer_stiha_4_str + nomer_stiha_5_str+ nomer_stiha_6_str +nomer_stiha_7_str
    
    fact_1_str = fact_str_iz_int (virajenie_1)

    
    return fact_1_str


def virajenie_2 (kolvo_slov_glavi : int , nomer_glavi : int , kolvo_stihov : int ) -> int :
    """Выражение номер 2 = номер главы + количество стихов в главе + количество слов в главе """
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)

    kolvo_slov_glavi_str = str (kolvo_slov_glavi)
    virajenie_2 = nomer_glavi_str + kolichestvo_stihov_str + kolvo_slov_glavi_str

    return  int (virajenie_2)

def fact_2 (kolvo_slov_glavi : int , nomer_glavi : int , kolvo_stihov : int ) -> str :
    """Факт номер 2 = (номер главы + количество стихов в главе + количество слов в главе) / 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)

    kolvo_slov_glavi_str = str (kolvo_slov_glavi)
    virajenie_2 = nomer_glavi_str + kolichestvo_stihov_str + kolvo_slov_glavi_str

    fact_2_str = fact_str_iz_int (virajenie_2)

    
    return fact_2_str

def virajenie_3 (summa_poryadkovih_nomerov_stihov : int, kolvo_slov_glavi : int, kolvo_bukv_glavi : int, cifrovoe_znachenie_glavi : int) -> int :
    """Выражение  номер 3: Сумма порядковых номеров стихов + количество слов в главе + количество букв в главе + числовое значение главы"""
    """Переводим в нужный формат в строку, чтобы сложить строку в последовательность"""
    
    summa_poryadkovih_nomerov_stihov_str = str (summa_poryadkovih_nomerov_stihov)
    kolvo_slov_glavi_str = str (kolvo_slov_glavi)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    virajenie_3 = summa_poryadkovih_nomerov_stihov_str + kolvo_slov_glavi_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    return int (virajenie_3)

def fact_3 (summa_poryadkovih_nomerov_stihov : int, kolvo_slov_glavi : int, kolvo_bukv_glavi : int, cifrovoe_znachenie_glavi : int) -> str :
    """ِФакт  номер 3: (Сумма порядковых номеров стихов + количество слов в главе + количество букв в главе + числовое значение главы) / 19"""
    """Переводим в нужный формат в строку, чтобы сложить строку в последовательность"""
    
    summa_poryadkovih_nomerov_stihov_str = str (summa_poryadkovih_nomerov_stihov)
    kolvo_slov_glavi_str = str (kolvo_slov_glavi)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    virajenie_3 = summa_poryadkovih_nomerov_stihov_str + kolvo_slov_glavi_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    fact_3_str = fact_str_iz_int (virajenie_3)

    
    return fact_3_str

def virajenie_4 ( nomer_glavi : int, kolvo_stihov : int, kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
                  kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int) -> str :
    """Выражение 4 = номер главы + количество стихов в главе + количество слов в 1 стихе + количество слов во 2 стихе +
    количество слов в 3 стихе + количество слов в 4 стихе + количество слов в 5 стихе + количество слов в 6 стихе +
    количество слов в 7 стихе"""

    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)

    virajenie_4 = (nomer_glavi_str + kolvo_stihov_str + kolvo_slov_1_stih_str + kolvo_slov_2_stih_str +
                   kolvo_slov_3_stih_str + kolvo_slov_4_stih_str + kolvo_slov_5_stih_str + kolvo_slov_6_stih_str
                   + kolvo_slov_7_stih_str)
    return virajenie_4

def fact_4 ( nomer_glavi : int, kolvo_stihov : int, kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
                  kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int) -> str :
    """ِФакт 4 = (номер главы + количество стихов в главе + количество слов в 1 стихе + количество слов во 2 стихе +
    количество слов в 3 стихе + количество слов в 4 стихе + количество слов в 5 стихе + количество слов в 6 стихе +
    количество слов в 7 стихе) / 19"""
    
    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)

    virajenie_4 = (nomer_glavi_str + kolvo_stihov_str + kolvo_slov_1_stih_str + kolvo_slov_2_stih_str +
                   kolvo_slov_3_stih_str + kolvo_slov_4_stih_str + kolvo_slov_5_stih_str + kolvo_slov_6_stih_str
                   + kolvo_slov_7_stih_str)

    fact_4_str = fact_str_iz_int (virajenie_4)


    return fact_4_str


def virajenie_5 ( nomer_glavi : int, kolvo_stihov : int, kolvo_bukv_glavi : int, cifrovoe_znachenie_glavi : int) -> str :
    """ Выражение 5 = номер главы + количество стихов в главе + количество букв в главе + числовое значение всей главы"""
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    virajenie_5 = nomer_glavi_str + kolvo_stihov_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    return virajenie_5

def fact_5 ( nomer_glavi : int, kolvo_stihov : int, kolvo_bukv_glavi : int, cifrovoe_znachenie_glavi : int) -> str :
    """ Факт 5 = (номер главы + количество стихов в главе + количество букв в главе + числовое значение всей главы)/19"""
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    virajenie_5 = nomer_glavi_str + kolvo_stihov_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    
    fact_5_str = fact_str_iz_int (virajenie_5)
    return fact_5_str



def virajenie_6  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int) -> str :
    """ Выражение 6 = номер главы  + количество букв в первом стихе + количество букв в втором стихе + количество букв в третьем стихе +
    количество букв в четвертом стихе + количество букв в пятом стихе + количество букв в шестом стихе + количество букв в седьмом стихе """

    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    virajenie_6 = nomer_glavi_str + kolvo_bukv_1_str + kolvo_bukv_2_str + kolvo_bukv_3_str + kolvo_bukv_4_str + kolvo_bukv_5_str + kolvo_bukv_6_str + kolvo_bukv_7_str

    return virajenie_6

def fact_6  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int) -> str :
    """ Выражение 6 = номер главы  + количество букв в первом стихе + количество букв в втором стихе + количество букв в третьем стихе +
    количество букв в четвертом стихе + количество букв в пятом стихе + количество букв в шестом стихе + количество букв в седьмом стихе """

    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    virajenie_6 = nomer_glavi_str + kolvo_bukv_1_str + kolvo_bukv_2_str + kolvo_bukv_3_str + kolvo_bukv_4_str + kolvo_bukv_5_str + kolvo_bukv_6_str + kolvo_bukv_7_str

    fact_6_str = fact_str_iz_int (virajenie_6)
    return fact_6_str

def virajenie_7 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
                 nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int ,
                 kolvo_bukv_3 : int, kolvo_bukv_4 : int ,kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int,
                 kolvo_bukv_glavi) -> int :
    """Выражение  7 = номер главы + номер стиха 1 + количество букв в 1 стихе + номер стиха 2 + количество букв во 2 стихе
    + номер стиха 3 + количество букв в 3 стихе + номер стиха 4 + количество букв в 4 стихе + номер стиха 5 + количество букв в 5 стихе
    + номер стиха 6 + количество букв в 6 стихе + номер стиха 7 + количество букв во 7 стихе + количество букв в главе"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

  
    kolvo_bukv_glavi_str = str(kolvo_bukv_glavi)

    
    

    virajenie_7 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str +  nomer_stiha_2_str +
                   kolvo_bukv_2_str  + nomer_stiha_3_str + kolvo_bukv_3_str + nomer_stiha_4_str + kolvo_bukv_4_str
                   + nomer_stiha_5_str + kolvo_bukv_5_str + nomer_stiha_6_str + kolvo_bukv_6_str +
                   nomer_stiha_7_str + kolvo_bukv_7_str + kolvo_bukv_glavi_str)
    return virajenie_7

def fact_7 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int ,
            kolvo_bukv_3 : int, kolvo_bukv_4 : int ,kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int,
            kolvo_bukv_glavi) -> int :
    """Факт  7 = (номер главы + номер стиха 1 + количество букв в 1 стихе + номер стиха 2 + количество букв во 2 стихе
    + номер стиха 3 + количество букв в 3 стихе + номер стиха 4 + количество букв в 4 стихе + номер стиха 5 + количество букв в 5 стихе
    + номер стиха 6 + количество букв в 6 стихе + номер стиха 7 + количество букв во 7 стихе + количество букв в главе) / 19"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

  
    kolvo_bukv_glavi_str = str(kolvo_bukv_glavi)

    
    

    virajenie_7 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str +  nomer_stiha_2_str +
                   kolvo_bukv_2_str  + nomer_stiha_3_str + kolvo_bukv_3_str + nomer_stiha_4_str + kolvo_bukv_4_str
                   + nomer_stiha_5_str + kolvo_bukv_5_str + nomer_stiha_6_str + kolvo_bukv_6_str +
                   nomer_stiha_7_str + kolvo_bukv_7_str + kolvo_bukv_glavi_str)

    fact_7_str = fact_str_iz_int (virajenie_7)
    return fact_7_str


def fact_8 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, progressia_bukv_2 : str, progressia_bukv_3 : str,
             progressia_bukv_4 : str, progressia_bukv_5 : str, progressia_bukv_6 : str, progressia_bukv_7 : str) -> str :
    """Факт 8 = (номер главы + номер 1 стиха + количество букв 1 стиха + номер 2 стиха +
    сумма цифр(количество букв 1 стиха + количество букв 2 стиха) + номер 3 стиха + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха) + номер стиха 4 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха) + номер стиха 5 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха) + номер стиха 6 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха) + номер стиха 7 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха + количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха + количество букв 7 стиха)) / 19"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)

    virajenie_8 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + nomer_stiha_2_str + progressia_bukv_2 +
                   nomer_stiha_3_str + progressia_bukv_3 + nomer_stiha_4_str + progressia_bukv_4 +
                   nomer_stiha_5_str + progressia_bukv_5 + nomer_stiha_6_str + progressia_bukv_6 +
                   nomer_stiha_7_str + progressia_bukv_7)
    fact_8_str = fact_str_iz_int (virajenie_8)
    return fact_8_str

def virajenie_8 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, progressia_bukv_2 : str, progressia_bukv_3 : str,
             progressia_bukv_4 : str, progressia_bukv_5 : str, progressia_bukv_6 : str, progressia_bukv_7 : str) -> str :
    """Выражение 8 = номер главы + номер 1 стиха + количество букв 1 стиха + номер 2 стиха +
    сумма цифр(количество букв 1 стиха + количество букв 2 стиха) + номер 3 стиха + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха) + номер стиха 4 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха) + номер стиха 5 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха) + номер стиха 6 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха) + номер стиха 7 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха + количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха + количество букв 7 стиха)"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)

    virajenie_8 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + nomer_stiha_2_str + progressia_bukv_2 +
                   nomer_stiha_3_str + progressia_bukv_3 + nomer_stiha_4_str + progressia_bukv_4 +
                   nomer_stiha_5_str + progressia_bukv_5 + nomer_stiha_6_str + progressia_bukv_6 +
                   nomer_stiha_7_str + progressia_bukv_7)
    return virajenie_8

def virajenie_9  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
                   cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
                   cifrovoe_znachenie_stiha_7 : int, ) -> str :
    """ Выражение 9 = номер главы  + количество букв в первом стихе + цифровое значение 1 стиха + количество букв в втором стихе +
    цифровое значение 2 стиха + количество букв в третьем стихе + цифровое значение 3 стиха + количество букв в четвертом стихе +
    цифровое значение 4 стиха + количество букв в пятом стихе + цифровое значение 5 стиха  +
    количество букв в шестом стихе + цифровое значение 6 стиха + количество букв в седьмом стихе + цифровое значение 7 стиха """

    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 9"""
    virajenie_9 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                   kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                   kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                   kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    
    

    return virajenie_9

def fact_9  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
                   cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
                   cifrovoe_znachenie_stiha_7 : int, ) -> str :
    """ Факт 9 =( номер главы  + количество букв в первом стихе + цифровое значение 1 стиха + количество букв в втором стихе +
    цифровое значение 2 стиха + количество букв в третьем стихе + цифровое значение 3 стиха + количество букв в четвертом стихе +
    цифровое значение 4 стиха + количество букв в пятом стихе + цифровое значение 5 стиха  +
    количество букв в шестом стихе + цифровое значение 6 стиха + количество букв в седьмом стихе + цифровое значение 7 стиха ) / 19"""

    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 9"""
    virajenie_9 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                   kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                   kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                   kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    
    fact_9_str = fact_str_iz_int (virajenie_9)
    return fact_9_str



def virajenie_10  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
                   cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
                   cifrovoe_znachenie_stiha_7 : int, ) -> str :
    """ Факт 10 =(  цифровое значение 7 стиха + количество букв в седьмом стихе + цифровое значение 6 стиха + количество букв в шестом стихе
    + цифровое значение 5 стиха  + количество букв в пятом стихе + цифровое значение 4 стиха  + количество букв в четвертом стихе +
    цифровое значение 3 стиха + количество букв в третьем стихе + цифровое значение 2 стиха + количество букв в втором стихе +
    цифровое значение 1 стиха + количество букв в первом стихе + номер главы ) / 19"""
    
    nomer_glavi_str = str (nomer_glavi)
    
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    """Создаем формулы для выражения 10"""
    virajenie_10 = (cifrovoe_znachenie_stiha_7_str + kolvo_bukv_7_str  + cifrovoe_znachenie_stiha_6_str + kolvo_bukv_6_str
                    + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_4_str + kolvo_bukv_4_str
                    + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_2_str + kolvo_bukv_2_str
                    + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_1_str + nomer_glavi_str)

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_10_decimal = Decimal (virajenie_10)
    virajenie_10_str = str (virajenie_10_decimal)
    
    return virajenie_10_str


def fact_10  ( nomer_glavi : int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
                   kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
                   cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
                   cifrovoe_znachenie_stiha_7 : int, ) -> str :
    """ Выражение 10 = цифровое значение 7 стиха + количество букв в седьмом стихе + цифровое значение 6 стиха + количество букв в шестом стихе
    + цифровое значение 5 стиха  + количество букв в пятом стихе + цифровое значение 4 стиха  + количество букв в четвертом стихе +
    цифровое значение 3 стиха + количество букв в третьем стихе + цифровое значение 2 стиха + количество букв в втором стихе +
    цифровое значение 1 стиха + количество букв в первом стихе + номер главы """
    
    nomer_glavi_str = str (nomer_glavi)


    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    """Создаем формулы для выражения 10"""
    virajenie_10 = (cifrovoe_znachenie_stiha_7_str + kolvo_bukv_7_str  + cifrovoe_znachenie_stiha_6_str + kolvo_bukv_6_str
                    + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_4_str + kolvo_bukv_4_str
                    + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_2_str + kolvo_bukv_2_str
                    + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_1_str + nomer_glavi_str)



    fact_10_str = fact_str_iz_int (virajenie_10)
    return fact_10_str

def fact_11  ( nomer_glavi : int, kolvo_bukv_1 : int, cifrovoe_znachenie_stiha_1 : int ,
              progressia_bukv_2 : str , progressia_bukv_3 :str, progressia_bukv_4 :str, progressia_bukv_5 :str,
               progressia_bukv_6 :str, progressia_bukv_7 : str ,
               progressia_dlya_cifrovogo_znachenia_2 : int, progressia_dlya_cifrovogo_znachenia_3 : int,
               progressia_dlya_cifrovogo_znachenia_4 : int,
               progressia_dlya_cifrovogo_znachenia_5 : int, progressia_dlya_cifrovogo_znachenia_6 : int,
               progressia_dlya_cifrovogo_znachenia_7 : int) -> str :
    """ Факт 11 = номер главы + количество букв в 1 стихе + цифровое значение 1 стиха + (количество букв в 1 стихе + количество букв во 2 стихе)
    + (цифровое значение 1 стиха + цифровое значение 2 стиха) + (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе )
    + (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе ) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха  ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе) +
     (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе + количество букв в 7 стихе)
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха + цифровое значение 7 стиха)
       после всех  операций идет деление в конце  / 19"""
    
    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    progressia_dlya_cifrovogo_znachenia_2_str = str (progressia_dlya_cifrovogo_znachenia_2)
    progressia_dlya_cifrovogo_znachenia_3_str = str (progressia_dlya_cifrovogo_znachenia_3)
    progressia_dlya_cifrovogo_znachenia_4_str = str (progressia_dlya_cifrovogo_znachenia_4)
    progressia_dlya_cifrovogo_znachenia_5_str = str (progressia_dlya_cifrovogo_znachenia_5)
    progressia_dlya_cifrovogo_znachenia_6_str = str (progressia_dlya_cifrovogo_znachenia_6)
    progressia_dlya_cifrovogo_znachenia_7_str = str (progressia_dlya_cifrovogo_znachenia_7)





    
    virajenie_11 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + progressia_bukv_2 +
                    progressia_dlya_cifrovogo_znachenia_2_str + progressia_bukv_3 + progressia_dlya_cifrovogo_znachenia_3_str
                    + progressia_bukv_4 + progressia_dlya_cifrovogo_znachenia_4_str
                    + progressia_bukv_5 + progressia_dlya_cifrovogo_znachenia_5_str
                    + progressia_bukv_6 + progressia_dlya_cifrovogo_znachenia_6_str
                    + progressia_bukv_7 + progressia_dlya_cifrovogo_znachenia_7_str)


    fact_11_str = fact_str_iz_int (virajenie_11)
    return fact_11_str

def virajenie_11  ( nomer_glavi : int, kolvo_bukv_1 : int, cifrovoe_znachenie_stiha_1 : int ,
              progressia_bukv_2 : str , progressia_bukv_3 :str, progressia_bukv_4 :str, progressia_bukv_5 :str,
               progressia_bukv_6 :str, progressia_bukv_7 : str ,
               progressia_dlya_cifrovogo_znachenia_2 : int, progressia_dlya_cifrovogo_znachenia_3 : int,
               progressia_dlya_cifrovogo_znachenia_4 : int,
               progressia_dlya_cifrovogo_znachenia_5 : int, progressia_dlya_cifrovogo_znachenia_6 : int,
               progressia_dlya_cifrovogo_znachenia_7 : int) -> str :
    """ Выражение 11 = номер главы + количество букв в 1 стихе + цифровое значение 1 стиха + (количество букв в 1 стихе + количество букв во 2 стихе)
    + (цифровое значение 1 стиха + цифровое значение 2 стиха) + (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе )
    + (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе ) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха  ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе) +
     (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе + количество букв в 7 стихе)
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха + цифровое значение 7 стиха)"""
    
    nomer_glavi_str = str (nomer_glavi)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    progressia_dlya_cifrovogo_znachenia_2_str = str (progressia_dlya_cifrovogo_znachenia_2)
    progressia_dlya_cifrovogo_znachenia_3_str = str (progressia_dlya_cifrovogo_znachenia_3)
    progressia_dlya_cifrovogo_znachenia_4_str = str (progressia_dlya_cifrovogo_znachenia_4)
    progressia_dlya_cifrovogo_znachenia_5_str = str (progressia_dlya_cifrovogo_znachenia_5)
    progressia_dlya_cifrovogo_znachenia_6_str = str (progressia_dlya_cifrovogo_znachenia_6)
    progressia_dlya_cifrovogo_znachenia_7_str = str (progressia_dlya_cifrovogo_znachenia_7)





    
    virajenie_11 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + progressia_bukv_2 +
                    progressia_dlya_cifrovogo_znachenia_2_str + progressia_bukv_3 + progressia_dlya_cifrovogo_znachenia_3_str
                    + progressia_bukv_4 + progressia_dlya_cifrovogo_znachenia_4_str
                    + progressia_bukv_5 + progressia_dlya_cifrovogo_znachenia_5_str
                    + progressia_bukv_6 + progressia_dlya_cifrovogo_znachenia_6_str
                    + progressia_bukv_7 + progressia_dlya_cifrovogo_znachenia_7_str)


    return virajenie_11
    
def fact_12 ( kolvo_bukv_glavi: int, kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
              kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int,
              kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """ Факт 12 = количество букв в главе + количество слов в 1 стихе + количество букв в 1 стихе + цифровое значение 1 стиха +
    количество слов в 2 стихе + количество букв во 2 стихе + цифровое значение 2 стиха +
    количество слов в 3 стихе + количество букв в 3 стихе + цифровое значение 2 стиха +
    количество слов в 4 стихе + количество букв в 4 стихе + цифровое значение 4 стиха +
    количество слов в 5 стихе + количество букв в 5 стихе + цифровое значение 5 стиха +
    количество слов в 6 стихе + количество букв в 6 стихе + цифровое значение 6 стиха +
    количество слов в 7 стихе + количество букв в 7 стихе + цифровое значение 7 стиха
    и в конце после всех расчетов поделить на 19"""


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)

    virajenie_12 = (kolvo_bukv_glavi_str + kolvo_slov_1_stih_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    kolvo_slov_2_stih_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    kolvo_slov_3_stih_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    kolvo_slov_4_stih_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    kolvo_slov_5_stih_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    kolvo_slov_6_stih_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    kolvo_slov_7_stih_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    fact_12_str = fact_str_iz_int (virajenie_12)
    return fact_12_str

def virajenie_12 ( kolvo_bukv_glavi: int, kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
              kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int,
              kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """ Выражение 12 = количество букв в главе + количество слов в 1 стихе + количество букв в 1 стихе + цифровое значение 1 стиха +
    количество слов в 2 стихе + количество букв во 2 стихе + цифровое значение 2 стиха +
    количество слов в 3 стихе + количество букв в 3 стихе + цифровое значение 2 стиха +
    количество слов в 4 стихе + количество букв в 4 стихе + цифровое значение 4 стиха +
    количество слов в 5 стихе + количество букв в 5 стихе + цифровое значение 5 стиха +
    количество слов в 6 стихе + количество букв в 6 стихе + цифровое значение 6 стиха +
    количество слов в 7 стихе + количество букв в 7 стихе + цифровое значение 7 стиха """


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)

    virajenie_12 = (kolvo_bukv_glavi_str + kolvo_slov_1_stih_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    kolvo_slov_2_stih_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    kolvo_slov_3_stih_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    kolvo_slov_4_stih_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    kolvo_slov_5_stih_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    kolvo_slov_6_stih_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    kolvo_slov_7_stih_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    
    return virajenie_12

def fact_13 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """Факт 13 = номер главы + номер 1 стиха + количество букв 1 стиха + цифровое значение 1 стиха + номер 2 стиха + количество букв 2 стиха
    + цифровое значение 2 стиха +  номер 3 стиха + количество букв 3 стиха + цифровое значение 3 стиха +  номер стиха 4 +
    количество букв 4 стиха + цифровое значение 4 стиха +  номер стиха 5 + количество букв 5 стиха + цифровое значение 5 стиха +
    номер стиха 6 + количество букв 6 стиха + цифровое значение 6 стиха + номер стиха 7 + количество букв 7 стиха + цифровое значение 7 стиха  
    после всех операций деления на / 19"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)


    virajenie_13 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    fact_13_str = fact_str_iz_int (virajenie_13)
    return fact_13_str

def virajenie_13 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """Выражение 13 = номер главы + номер 1 стиха + количество букв 1 стиха + цифровое значение 1 стиха + номер 2 стиха + количество букв 2 стиха
    + цифровое значение 2 стиха +  номер 3 стиха + количество букв 3 стиха + цифровое значение 3 стиха +  номер стиха 4 +
    количество букв 4 стиха + цифровое значение 4 стиха +  номер стиха 5 + количество букв 5 стиха + цифровое значение 5 стиха +
    номер стиха 6 + количество букв 6 стиха + цифровое значение 6 стиха + номер стиха 7 + количество букв 7 стиха + цифровое значение 7 стиха"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)


    virajenie_13 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    
    return virajenie_13

def fact_14 ( nomer_glavi : int , kolvo_stihov : int, cifrovoe_znachenie_glavi : int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int,kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
              kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int,
              kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """Факт 14 = номер главы + количество стихов в главе + цифровое значение всей главы +
    номер 1 стиха + количество слов 1 стиха  + количество букв 1 стиха + цифровое значение 1 стиха +
    номер 2 стиха + количество слов 2 стиха  + количество букв 2 стиха + цифровое значение 2 стиха +
    номер 3 стиха + количество слов 3 стиха  + количество букв 3 стиха + цифровое значение 3 стиха +
    номер 4 стиха + количество слов 4 стиха  + количество букв 4 стиха + цифровое значение 4 стиха +
    номер 5 стиха + количество слов 5 стиха  + количество букв 5 стиха + цифровое значение 5 стиха +
    номер 6 стиха + количество слов 6 стиха  + количество букв 6 стиха + цифровое значение 6 стиха +
    номер 7 стиха + количество слов 7 стиха  + количество букв 7 стиха + цифровое значение 7 стиха
    в конце поделить на 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)


    virajenie_14 = (nomer_glavi_str + kolichestvo_stihov_str + cifrovoe_znachenie_glavi_str + 
                    nomer_stiha_1_str + kolvo_slov_1_stih_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_slov_2_stih_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_slov_3_stih_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_slov_4_stih_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_slov_5_stih_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_slov_6_stih_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_slov_7_stih_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    fact_14_str = fact_str_iz_int (virajenie_14)
    return fact_14_str




def virajenie_14 ( nomer_glavi : int , kolvo_stihov : int, cifrovoe_znachenie_glavi : int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int,kolvo_slov_1_stih : int, kolvo_slov_2_stih : int, kolvo_slov_3_stih : int,
              kolvo_slov_4_stih : int, kolvo_slov_5_stih : int, kolvo_slov_6_stih : int, kolvo_slov_7_stih : int,
              kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, cifrovoe_znachenie_stiha_1 : int, cifrovoe_znachenie_stiha_2 : int,
              cifrovoe_znachenie_stiha_3 : int, cifrovoe_znachenie_stiha_4 : int, cifrovoe_znachenie_stiha_5 : int, cifrovoe_znachenie_stiha_6 : int,
              cifrovoe_znachenie_stiha_7 : int ) -> str :
    """Выражение 14 = номер главы + количество стихов в главе + цифровое значение всей главы +
    номер 1 стиха + количество слов 1 стиха  + количество букв 1 стиха + цифровое значение 1 стиха +
    номер 2 стиха + количество слов 2 стиха  + количество букв 2 стиха + цифровое значение 2 стиха +
    номер 3 стиха + количество слов 3 стиха  + количество букв 3 стиха + цифровое значение 3 стиха +
    номер 4 стиха + количество слов 4 стиха  + количество букв 4 стиха + цифровое значение 4 стиха +
    номер 5 стиха + количество слов 5 стиха  + количество букв 5 стиха + цифровое значение 5 стиха +
    номер 6 стиха + количество слов 6 стиха  + количество букв 6 стиха + цифровое значение 6 стиха +
    номер 7 стиха + количество слов 7 стиха  + количество букв 7 стиха + цифровое значение 7 стиха"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    kolvo_slov_1_stih_str = str (kolvo_slov_1_stih)
    kolvo_slov_2_stih_str = str (kolvo_slov_2_stih)
    kolvo_slov_3_stih_str = str (kolvo_slov_3_stih)
    kolvo_slov_4_stih_str = str (kolvo_slov_4_stih)
    kolvo_slov_5_stih_str = str (kolvo_slov_5_stih)
    kolvo_slov_6_stih_str = str (kolvo_slov_6_stih)
    kolvo_slov_7_stih_str = str (kolvo_slov_7_stih)


    virajenie_14 = (nomer_glavi_str + kolichestvo_stihov_str + cifrovoe_znachenie_glavi_str + 
                    nomer_stiha_1_str + kolvo_slov_1_stih_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_slov_2_stih_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_slov_3_stih_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_slov_4_stih_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_slov_5_stih_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_slov_6_stih_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_slov_7_stih_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    return virajenie_14


def fact_15 ( nomer_glavi : int , kolvo_stihov : int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, bukvo_chislo_stiha_1 : int, bukvo_chislo_stiha_2 : int,
              bukvo_chislo_stiha_3 : int, bukvo_chislo_stiha_4 : int, bukvo_chislo_stiha_5 : int, bukvo_chislo_stiha_6 : int,
              bukvo_chislo_stiha_7 : int) -> str :
    """Факт 15 = номер главы + количество стихов в главе + 
    номер 1 стиха + количество букв 1 стиха + каждое букво-число 1 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 2 стиха + количество букв 2 стиха + каждое букво-число 2 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) + 
    номер 3 стиха + количество букв 3 стиха + каждое букво-число 3 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 4 стиха + количество букв 4 стиха + каждое букво-число 4 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 5 стиха + количество букв 5 стиха + каждое букво-число 5 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 6 стиха + количество букв 6 стиха + каждое букво-число 6 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 7 стиха + количество букв 7 стиха + каждое букво-число 7 стиха (это сложение  в строку списка замененных на цифры букв в одну строку)
    затем после всех операций делится на 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    bukvo_chislo_stiha_1_str = str (bukvo_chislo_stiha_1)
    bukvo_chislo_stiha_2_str = str (bukvo_chislo_stiha_2)
    bukvo_chislo_stiha_3_str = str (bukvo_chislo_stiha_3)
    bukvo_chislo_stiha_4_str = str (bukvo_chislo_stiha_4)
    bukvo_chislo_stiha_5_str = str (bukvo_chislo_stiha_5)
    bukvo_chislo_stiha_6_str = str (bukvo_chislo_stiha_6)
    bukvo_chislo_stiha_7_str = str (bukvo_chislo_stiha_7)

    virajenie_15 = (nomer_glavi_str + kolichestvo_stihov_str +
                    nomer_stiha_1_str + kolvo_bukv_1_str + bukvo_chislo_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + bukvo_chislo_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + bukvo_chislo_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + bukvo_chislo_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + bukvo_chislo_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + bukvo_chislo_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + bukvo_chislo_stiha_7_str)


    fact_15_str = fact_str_iz_int (virajenie_15)
    return fact_15_str



def virajenie_15 ( nomer_glavi : int , kolvo_stihov : int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, kolvo_bukv_1 : int, kolvo_bukv_2 : int , kolvo_bukv_3 : int, kolvo_bukv_4 : int ,
              kolvo_bukv_5 : int, kolvo_bukv_6 : int , kolvo_bukv_7 : int, bukvo_chislo_stiha_1 : int, bukvo_chislo_stiha_2 : int,
              bukvo_chislo_stiha_3 : int, bukvo_chislo_stiha_4 : int, bukvo_chislo_stiha_5 : int, bukvo_chislo_stiha_6 : int,
              bukvo_chislo_stiha_7 : int) -> str :
    """Выражение 15 = номер главы + количество стихов в главе + 
    номер 1 стиха + количество букв 1 стиха + каждое букво-число 1 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 2 стиха + количество букв 2 стиха + каждое букво-число 2 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) + 
    номер 3 стиха + количество букв 3 стиха + каждое букво-число 3 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 4 стиха + количество букв 4 стиха + каждое букво-число 4 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 5 стиха + количество букв 5 стиха + каждое букво-число 5 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 6 стиха + количество букв 6 стиха + каждое букво-число 6 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 7 стиха + количество букв 7 стиха + каждое букво-число 7 стиха (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    bukvo_chislo_stiha_1_str = str (bukvo_chislo_stiha_1)
    bukvo_chislo_stiha_2_str = str (bukvo_chislo_stiha_2)
    bukvo_chislo_stiha_3_str = str (bukvo_chislo_stiha_3)
    bukvo_chislo_stiha_4_str = str (bukvo_chislo_stiha_4)
    bukvo_chislo_stiha_5_str = str (bukvo_chislo_stiha_5)
    bukvo_chislo_stiha_6_str = str (bukvo_chislo_stiha_6)
    bukvo_chislo_stiha_7_str = str (bukvo_chislo_stiha_7)

    virajenie_15 = (nomer_glavi_str + kolichestvo_stihov_str +
                    nomer_stiha_1_str + kolvo_bukv_1_str + bukvo_chislo_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + bukvo_chislo_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + bukvo_chislo_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + bukvo_chislo_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + bukvo_chislo_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + bukvo_chislo_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + bukvo_chislo_stiha_7_str)



    return virajenie_15




    






