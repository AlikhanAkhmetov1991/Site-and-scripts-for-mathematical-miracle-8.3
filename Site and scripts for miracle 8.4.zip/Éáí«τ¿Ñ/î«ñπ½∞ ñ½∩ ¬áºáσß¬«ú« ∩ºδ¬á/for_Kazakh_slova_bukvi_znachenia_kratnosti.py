
import re
from decimal import *

def kolvo_slov (stih) -> int :
    """Количество слов в стихе"""
    stih_list = stih.split ()
    kolvo_slov = len(stih_list)
    return kolvo_slov

def kolvo_slov_glavi (stih_1 : str, stih_2 :str , stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ) -> int :
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov_glavi = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7
    return kolvo_slov_glavi

def summa_poryadkovih_nomerov_stihov (nomer_stiha_1 : int, nomer_stiha_2 : int, nomer_stiha_3 : int,
                                      nomer_stiha_4 : int, nomer_stiha_5 : int, nomer_stiha_6 : int, nomer_stiha_7 : int) -> int :
    summa_poryadkovih_nomerov_stihov = nomer_stiha_1 + nomer_stiha_2 + nomer_stiha_3 + nomer_stiha_4 + nomer_stiha_5 + nomer_stiha_6 + nomer_stiha_7
    return summa_poryadkovih_nomerov_stihov

def kolvo_bukv (stih : str) -> int :
    """Считаем количество букв стиха"""
    stroka_bez_probela = re.sub (' ' ,'', stih)
    kolvo_bukv_stiha = len (stroka_bez_probela)
    return kolvo_bukv_stiha

def kolvo_bukv_glavi (stih_1 : str, stih_2 : str, stih_3 : str , stih_4 :str , stih_5 :str , stih_6 :str, stih_7 :str) -> int :
    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    return kolvo_bukv_glavi

def spisok_bukv_stiha (stih : str) -> list :
    """Создаем список букв стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    return spisok_bukv_stiha
def spisok_cifr_stiha (stih : str, ) -> list :
    """Создаем список цифр стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('А' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('а' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('Ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('Б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('В' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('в' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('Г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('Ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('Д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('Е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('Ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('Ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('З' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('з' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('И' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('и' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('Й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('К' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('к' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('Қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('Л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('М' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('м' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('Н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('Ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('О' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('о' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('Ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('П' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('п' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('Р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('С' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('с' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('У' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('у' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('Ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('Ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('Ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('Х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('Һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('Ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('Ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('Ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('Щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('Ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('Ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('І' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('і' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('Ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('Э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('Ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('Я' , '2400') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('я' , '2400') for elem in result_g1]

    return spisok_cifr_stiha

def cifrovoe_znachenie_stiha (stih : str) -> int :
    """Узнаем цифровое значение стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('А' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('а' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('Ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('Б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('В' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('в' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('Г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('Ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('Д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('Е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('Ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('Ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('З' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('з' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('И' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('и' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('Й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('К' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('к' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('Қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('Л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('М' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('м' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('Н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('Ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('О' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('о' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('Ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('П' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('п' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('Р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('С' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('с' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('У' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('у' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('Ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('Ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('Ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('Х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('Һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('Ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('Ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('Ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('Щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('Ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('Ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('І' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('і' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('Ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('Э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('Ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('Я' , '2400') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('я' , '2400') for elem in result_g1]
    
    spisok_cifr_stiha_int = [int  (x) for x  in spisok_cifr_stiha]
    cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_int)
    return cifrovoe_znachenie_stiha

def cifrovoe_znachenie_glavi (stih_1 : str, stih_2 : str , stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('А' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('а' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('Ә' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ә' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('Б' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('б' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('В' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('в' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('Г' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('г' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('Ғ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ғ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('Д' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('д' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('Е' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('е' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('Ё' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ё' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('Ж' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ж' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('З' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('з' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('И' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('и' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('Й' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('й' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('К' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('к' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('Қ' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('қ' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('Л' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('л' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('М' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('м' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('Н' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('н' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('Ң' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ң' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('О' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('о' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('Ө' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('ө' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('П' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('п' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('Р' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('р' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('С' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('с' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('Т' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('т' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('У' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('у' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('Ұ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('ұ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('Ү' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ү' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('Ф' , '1100') for elem in result_g1]
        result_g1 = [elem.replace ('ф' , '1100') for elem in result_g1]
        result_g1 = [elem.replace ('Х' , '1200') for elem in result_g1]
        result_g1 = [elem.replace ('х' , '1200') for elem in result_g1]
        result_g1 = [elem.replace ('Һ' , '1300') for elem in result_g1]
        result_g1 = [elem.replace ('һ' , '1300') for elem in result_g1]
        result_g1 = [elem.replace ('Ц' , '1400') for elem in result_g1]
        result_g1 = [elem.replace ('ц' , '1400') for elem in result_g1]
        result_g1 = [elem.replace ('Ч' , '1500') for elem in result_g1]
        result_g1 = [elem.replace ('ч' , '1500') for elem in result_g1]
        result_g1 = [elem.replace ('Ш' , '1600') for elem in result_g1]
        result_g1 = [elem.replace ('ш' , '1600') for elem in result_g1]
        result_g1 = [elem.replace ('Щ' , '1700') for elem in result_g1]
        result_g1 = [elem.replace ('щ' , '1700') for elem in result_g1]
        result_g1 = [elem.replace ('Ъ' , '1800') for elem in result_g1]
        result_g1 = [elem.replace ('ъ' , '1800') for elem in result_g1]
        result_g1 = [elem.replace ('Ы' , '1900') for elem in result_g1]
        result_g1 = [elem.replace ('ы' , '1900') for elem in result_g1]
        result_g1 = [elem.replace ('І' , '2000') for elem in result_g1]
        result_g1 = [elem.replace ('і' , '2000') for elem in result_g1]
        result_g1 = [elem.replace ('Ь' , '2100') for elem in result_g1]
        result_g1 = [elem.replace ('ь' , '2100') for elem in result_g1]
        result_g1 = [elem.replace ('Э' , '2200') for elem in result_g1]
        result_g1 = [elem.replace ('э' , '2200') for elem in result_g1]
        result_g1 = [elem.replace ('Ю' , '2300') for elem in result_g1]
        result_g1 = [elem.replace ('ю' , '2300') for elem in result_g1]
        result_g1 = [elem.replace ('Я' , '2400') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('я' , '2400') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
        
    return cifrovoe_znachenie_glavi

def bukvo_chislo_stiha (stih : str) -> str :
    """Узнаем букво-число стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('А' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('а' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('Ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ә' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('Б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('б' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('В' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('в' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('Г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('г' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('Ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ғ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('Д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('д' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('Е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('е' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('Ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ё' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('Ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ж' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('З' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('з' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('И' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('и' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('Й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('й' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('К' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('к' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('Қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('қ' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('Л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('л' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('М' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('м' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('Н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('н' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('Ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ң' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('О' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('о' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('Ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('ө' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('П' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('п' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('Р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('р' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('С' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('с' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('Т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('т' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('У' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('у' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('Ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('ұ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('Ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ү' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('Ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('ф' , '1100') for elem in result_g1]
    result_g1 = [elem.replace ('Х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('х' , '1200') for elem in result_g1]
    result_g1 = [elem.replace ('Һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('һ' , '1300') for elem in result_g1]
    result_g1 = [elem.replace ('Ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('ц' , '1400') for elem in result_g1]
    result_g1 = [elem.replace ('Ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('ч' , '1500') for elem in result_g1]
    result_g1 = [elem.replace ('Ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('ш' , '1600') for elem in result_g1]
    result_g1 = [elem.replace ('Щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('щ' , '1700') for elem in result_g1]
    result_g1 = [elem.replace ('Ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('ъ' , '1800') for elem in result_g1]
    result_g1 = [elem.replace ('Ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('ы' , '1900') for elem in result_g1]
    result_g1 = [elem.replace ('І' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('і' , '2000') for elem in result_g1]
    result_g1 = [elem.replace ('Ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('ь' , '2100') for elem in result_g1]
    result_g1 = [elem.replace ('Э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('э' , '2200') for elem in result_g1]
    result_g1 = [elem.replace ('Ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('ю' , '2300') for elem in result_g1]
    result_g1 = [elem.replace ('Я' , '2400') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('я' , '2400') for elem in result_g1]
    
    spisok_cifr_stiha_str = [str  (x) for x  in spisok_cifr_stiha]
    bukvo_chislo_stiha = ''.join(spisok_cifr_stiha_str)

    return bukvo_chislo_stiha

def proverka_kratnosti_19 (virajenie : int) -> str :
    virajenie_decimal = Decimal (virajenie % 19)
    if virajenie_decimal == 0 :
        return 'Иә'
    else: return 'Жоқ'

def  shetchiki_resultatov (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Иә' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_da

def  shetchiki_resultatov_net (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Иә' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_net

def kolichestvo_proverok_kratnosti (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    kolichestvo_proverok_kratnosti = len (spisok_shetchika)
    return kolichestvo_proverok_kratnosti

def fact_str_iz_int (virajenie : int) -> str :
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_decimal = Decimal (virajenie)
    divisor = Decimal ('19')
    fact = Decimal (virajenie_decimal / divisor)
    fact_str = str (fact)
    return fact_str

