from setuptools import setup

setup (
    name = 'example_russian_for_Miracle' ,
    version = '2.0',
    description = 'Mathematical miracles of Quran, Al-Fatiha, facts 1-15, only russian functions',
    author = 'Alikhan Akhmetov',
    author_email = 'ahmetov_alihan@mail.ru',
    url = 'ahmetovalihan.pythonanywhere.com',
    py_modules = ['for_example_russian'],
)
