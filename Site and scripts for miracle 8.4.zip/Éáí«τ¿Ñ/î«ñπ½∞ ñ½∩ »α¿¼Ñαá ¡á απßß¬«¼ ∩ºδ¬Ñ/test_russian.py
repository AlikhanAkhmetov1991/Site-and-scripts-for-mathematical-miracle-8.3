import re
from decimal import *

data = ['ываыв мсмюб..,' , 'ываыв 23423 ыав2']


def replacing (data) :
    replacing = re.findall(r'[А-я]+', data)
    return replacing
data_for_calculations = list( map (replacing, data))

                            
