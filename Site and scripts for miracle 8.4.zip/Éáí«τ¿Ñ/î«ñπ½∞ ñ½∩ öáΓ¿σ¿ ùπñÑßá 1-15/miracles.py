import re
from decimal import *

def virajenie_1 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
                 nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int) -> int :
    """Выражение  первого факта = номер главы + номер стиха первого + номер стиха второго и так до последнего стиха включительно"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

   

    virajenie_1 = nomer_glavi_str + nomer_stiha_1_str + nomer_stiha_2_str + nomer_stiha_3_str + nomer_stiha_4_str + nomer_stiha_5_str+ nomer_stiha_6_str +nomer_stiha_7_str
    return  int(virajenie_1)
    
def fact_1 (nomer_glavi : int, nomer_stiha1 :int , nomer_stiha2 : int,nomer_stiha3 :int, nomer_stiha4 :int ,
            nomer_stiha5 : int, nomer_stiha6 : int, nomer_stiha7 : int) -> float :
    """Факт 1 = номер главы + номер стиха первого + номер стиха второго и так до последнего стиха включительно потом поделить на 19"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

   

    virajenie_1 = nomer_glavi_str + nomer_stiha_1_str + nomer_stiha_2_str + nomer_stiha_3_str + nomer_stiha_4_str + nomer_stiha_5_str+ nomer_stiha_6_str +nomer_stiha_7_str
    
    virajenie_1_float = float (virajenie_1)

    fact1 = virajenie_1_float / 19

    
    return fact1

def kolvo_slov (stih) -> int :
    """Количество слов в стихе"""
    stih_list = stih.split ()
    kolvo_slov = len(stih_list)
    return kolvo_slov

def kolvo_slov_glavi (stih_1 : str, stih_2 :str , stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ) -> int :
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov_glavi = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7
    return kolvo_slov_glavi

def virajenie_2 (stih_1 : str, stih_2 :str , stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str , nomer_glavi : int , kolvo_stihov : int ) -> int :
    """Выражение номер 2 = номер главы + количество стихов в главе + количество слов в главе """
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7

    
    kolvo_slov_str = str (kolvo_slov)
    virajenie_2 = nomer_glavi_str + kolichestvo_stihov_str + kolvo_slov_str

    return  int (virajenie_2)

def fact_2 (stih_1 : str, stih_2 :str , stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str , nomer_glavi : int , kolvo_stihov : int ) -> float :
    """Факт номер 2 = (номер главы + количество стихов в главе + количество слов в главе) / 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7

    
    kolvo_slov_str = str (kolvo_slov)
    virajenie_2 = nomer_glavi_str + kolichestvo_stihov_str + kolvo_slov_str

    virajenie_2_float = float (virajenie_2)

    
    fact_2 = virajenie_2_float / 19

    return fact_2

def summa_poryadkovih_nomerov_stihov (nomer_stiha_1 : int, nomer_stiha_2 : int, nomer_stiha_3 : int,
                                      nomer_stiha_4 : int, nomer_stiha_5 : int, nomer_stiha_6 : int, nomer_stiha_7 : int) -> int :
    summa_poryadkovih_nomerov_stihov = nomer_stiha_1 + nomer_stiha_2 + nomer_stiha_3 + nomer_stiha_4 + nomer_stiha_5 + nomer_stiha_6 + nomer_stiha_7
    return summa_poryadkovih_nomerov_stihov

def kolvo_bukv (stih : str) -> int :
    """Считаем количество букв стиха"""
    stroka_bez_probela = re.sub (' ' ,'', stih)
    kolvo_bukv_stiha = len (stroka_bez_probela)
    return kolvo_bukv_stiha

def kolvo_bukv_glavi (stih_1 : str, stih_2 : str, stih_3 : str , stih_4 :str , stih_5 :str , stih_6 :str, stih_7 :str) -> int :
    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    return kolvo_bukv_glavi

def spisok_bukv_stiha (stih : str) -> list :
    """Создаем список букв стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    return spisok_bukv_stiha
def spisok_cifr_stiha (stih : str) -> list :
    """Создаем список цифр стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]

    return spisok_cifr_stiha

def cifrovoe_znachenie_stiha (stih : str) -> int :
    """Узнаем цифровое значение стиха"""
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_int = [int  (x) for x  in spisok_cifr_stiha]
    cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_int)
    return cifrovoe_znachenie_stiha

def cifrovoe_znachenie_glavi (stih_1 : str, stih_2 : str , stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
        
    return cifrovoe_znachenie_glavi

def virajenie_3 (nomer_stiha_1 : int, nomer_stiha_2 : int, nomer_stiha_3 : int, nomer_stiha_4 : int,
                 nomer_stiha_5 : int, nomer_stiha_6 : int, nomer_stiha_7 : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Выражение  номер 3: Сумма порядковых номеров стихов + количество слов в главе + количество букв в главе + числовое значение главы"""
    """Определяем сумму номеров стихов"""
    summa_poryadkovih_nomerov_stihov = nomer_stiha_1 + nomer_stiha_2 + nomer_stiha_3 + nomer_stiha_4 + nomer_stiha_5 + nomer_stiha_6 + nomer_stiha_7
    summa_poryadkovih_nomerov_stihov_str = str (summa_poryadkovih_nomerov_stihov)
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7

    
    kolvo_slov_str = str (kolvo_slov)

    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)

    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    virajenie_3 = summa_poryadkovih_nomerov_stihov_str + kolvo_slov_str + kolvo_bukv_glavi_str + str (cifrovoe_znachenie_glavi)
    return int (virajenie_3)

def fact_3 (nomer_stiha_1 : int, nomer_stiha_2 : int, nomer_stiha_3 : int, nomer_stiha_4 : int,
                 nomer_stiha_5 : int, nomer_stiha_6 : int, nomer_stiha_7 : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> float :
    """ِФакт  номер 3: (Сумма порядковых номеров стихов + количество слов в главе + количество букв в главе + числовое значение главы) / 19"""
    """Определяем сумму номеров стихов"""
    summa_poryadkovih_nomerov_stihov = nomer_stiha_1 + nomer_stiha_2 + nomer_stiha_3 + nomer_stiha_4 + nomer_stiha_5 + nomer_stiha_6 + nomer_stiha_7
    summa_poryadkovih_nomerov_stihov_str = str (summa_poryadkovih_nomerov_stihov)
    """Количество слов в главе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split ()
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1 = len(a1list)
    slova2 = len(a2list)
    slova3 = len(a3list)
    slova4 = len(a4list)
    slova5 = len(a5list)
    slova6 = len(a6list)
    slova7 = len(a7list)

    kolvo_slov = slova1 + slova2 +slova3 + slova4 + slova5 + slova6 + slova7

    
    kolvo_slov_str = str (kolvo_slov)

    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)

    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    virajenie_3 = summa_poryadkovih_nomerov_stihov_str + kolvo_slov_str + kolvo_bukv_glavi_str + str (cifrovoe_znachenie_glavi)
    fact_3 = float (virajenie_3) / 19
    return fact_3

def virajenie_4 ( nomer_glavi : int, kolvo_stihov : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """Выражение 4 = номер главы + количество стихов в главе + количество слов в 1 стихе + количество слов во 2 стихе +
    количество слов в 3 стихе + количество слов в 4 стихе + количество слов в 5 стихе + количество слов в 6 стихе +
    количество слов в 7 стихе"""

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))
    

    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)

    virajenie_4 = nomer_glavi_str + kolvo_stihov_str + slova1_str + slova2_str +  slova3_str + slova4_str + slova5_str + slova6_str + slova7_str
    return virajenie_4

def fact_4 ( nomer_glavi : int, kolvo_stihov : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> float :
    """ِФакт 4 = (номер главы + количество стихов в главе + количество слов в 1 стихе + количество слов во 2 стихе +
    количество слов в 3 стихе + количество слов в 4 стихе + количество слов в 5 стихе + количество слов в 6 стихе +
    количество слов в 7 стихе) / 19"""

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))
    

    nomer_glavi_str = str (nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)

    virajenie_4 = nomer_glavi_str + kolvo_stihov_str + slova1_str + slova2_str +  slova3_str + slova4_str + slova5_str + slova6_str + slova7_str

    virajenie_4_float = float (virajenie_4)

    fact_4 = virajenie_4_float / 19
    return fact_4

def virajenie_5 ( nomer_glavi : int, kolvo_stihov : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 5 = номер главы + количество стихов в главе + количество букв в главе + числовое значение всей главы"""
    
    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)

    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    nomer_glavi_str = str(nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    

    virajenie_5 = nomer_glavi_str + kolvo_stihov_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    return virajenie_5

def fact_5 ( nomer_glavi : int, kolvo_stihov : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> float :
    """ Факт 5 = (номер главы + количество стихов в главе + количество букв в главе + числовое значение всей главы)/19"""
    
    """Считаем количество букв главы"""
    a1bez = re.sub (' ' ,'', stih_1)
    a2bez = re.sub (' ' ,'', stih_2)
    a3bez = re.sub (' ' ,'', stih_3)
    a4bez = re.sub (' ' ,'', stih_4)
    a5bez = re.sub (' ' ,'', stih_5)
    a6bez = re.sub (' ' ,'', stih_6)
    a7bez = re.sub (' ' ,'', stih_7)


    kolvo_bukv_glavi = len (a1bez) + len (a2bez) + len (a3bez) + len (a4bez) + len (a5bez) +len (a6bez) + len (a7bez)
    kolvo_bukv_glavi_str = str (kolvo_bukv_glavi)

    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)

    nomer_glavi_str = str(nomer_glavi)
    kolvo_stihov_str = str (kolvo_stihov)
    

    virajenie_5 = nomer_glavi_str + kolvo_stihov_str + kolvo_bukv_glavi_str + cifrovoe_znachenie_glavi_str
    virajenie_5_float = float ( virajenie_5)
    fact_5 = virajenie_5_float / 19
    
    return fact_5

def virajenie_6  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 6 = номер главы  + количество букв в первом стихе + количество букв в втором стихе + количество букв в третьем стихе +
    количество букв в четвертом стихе + количество букв в пятом стихе + количество букв в шестом стихе + количество букв в седьмом стихе """

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1_str = str (len (re.sub (' ' ,'', stih_1)))
    kolvo_bukv_2_str = str (len (re.sub (' ' ,'', stih_2)))
    kolvo_bukv_3_str = str (len (re.sub (' ' ,'', stih_3)))
    kolvo_bukv_4_str = str (len (re.sub (' ' ,'', stih_4)))
    kolvo_bukv_5_str = str (len (re.sub (' ' ,'', stih_5)))
    kolvo_bukv_6_str = str (len (re.sub (' ' ,'', stih_6)))
    kolvo_bukv_7_str = str (len (re.sub (' ' ,'', stih_7)))
    

    nomer_glavi_str = str (nomer_glavi)

    virajenie_6 = nomer_glavi_str + kolvo_bukv_1_str + kolvo_bukv_2_str + kolvo_bukv_3_str + kolvo_bukv_4_str + kolvo_bukv_5_str + kolvo_bukv_6_str + kolvo_bukv_7_str

    return virajenie_6

def fact_6  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> float :
    """ Факт 6 = (номер главы  + количество букв в первом стихе + количество букв в втором стихе + количество букв в третьем стихе +
    количество букв в четвертом стихе + количество букв в пятом стихе + количество букв в шестом стихе + количество букв в седьмом стихе) / 19 """

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1_str = str (len (re.sub (' ' ,'', stih_1)))
    kolvo_bukv_2_str = str (len (re.sub (' ' ,'', stih_2)))
    kolvo_bukv_3_str = str (len (re.sub (' ' ,'', stih_3)))
    kolvo_bukv_4_str = str (len (re.sub (' ' ,'', stih_4)))
    kolvo_bukv_5_str = str (len (re.sub (' ' ,'', stih_5)))
    kolvo_bukv_6_str = str (len (re.sub (' ' ,'', stih_6)))
    kolvo_bukv_7_str = str (len (re.sub (' ' ,'', stih_7)))
    

    nomer_glavi_str = str (nomer_glavi)

    virajenie_6 = nomer_glavi_str + kolvo_bukv_1_str + kolvo_bukv_2_str + kolvo_bukv_3_str + kolvo_bukv_4_str + kolvo_bukv_5_str + kolvo_bukv_6_str + kolvo_bukv_7_str
    fact_6 = float (virajenie_6) / 19
    return fact_6

def virajenie_7 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
                 nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> int :
    """Выражение  7 = номер главы + номер стиха 1 + количество букв в 1 стихе + номер стиха 2 + количество букв во 2 стихе
    + номер стиха 3 + количество букв в 3 стихе + номер стиха 4 + количество букв в 4 стихе + номер стиха 5 + количество букв в 5 стихе
    + номер стиха 6 + количество букв в 6 стихе + номер стиха 7 + количество букв во 7 стихе + количество букв в главе"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    """Считаем количество букв главы"""
    kolvo_bukv_glavi_str = str(kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 +
                               kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)

    
    

    virajenie_7 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str +  nomer_stiha_2_str +
                   kolvo_bukv_2_str  + nomer_stiha_3_str + kolvo_bukv_3_str + nomer_stiha_4_str + kolvo_bukv_4_str
                   + nomer_stiha_5_str + kolvo_bukv_5_str + nomer_stiha_6_str + kolvo_bukv_6_str +
                   nomer_stiha_7_str + kolvo_bukv_7_str + kolvo_bukv_glavi_str)
    return virajenie_7

def fact_7 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
            stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> str :
    """Факт  7 = (номер главы + номер стиха 1 + количество букв в 1 стихе + номер стиха 2 + количество букв во 2 стихе
    + номер стиха 3 + количество букв в 3 стихе + номер стиха 4 + количество букв в 4 стихе + номер стиха 5 + количество букв в 5 стихе
    + номер стиха 6 + количество букв в 6 стихе + номер стиха 7 + количество букв во 7 стихе + количество букв в главе) / 19"""
    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    """Считаем количество букв главы"""
    kolvo_bukv_glavi_str = str(kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 +
                               kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)

    
    

    virajenie_7 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str +  nomer_stiha_2_str +
                   kolvo_bukv_2_str  + nomer_stiha_3_str + kolvo_bukv_3_str + nomer_stiha_4_str + kolvo_bukv_4_str
                   + nomer_stiha_5_str + kolvo_bukv_5_str + nomer_stiha_6_str + kolvo_bukv_6_str +
                   nomer_stiha_7_str + kolvo_bukv_7_str + kolvo_bukv_glavi_str)

    virajenie_7_decimal = Decimal (virajenie_7)
    divisor = Decimal ('19')
    fact_7 = virajenie_7_decimal / divisor
    fact_7_str = str (fact_7)
    
    return fact_7_str

def virajenie_8 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
                 nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> str :
    """Выражение 8 = номер главы + номер 1 стиха + количество букв 1 стиха + номер 2 стиха +
    сумма цифр(количество букв 1 стиха + количество букв 2 стиха) + номер 3 стиха + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха) + номер стиха 4 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха) + номер стиха 5 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха) + номер стиха 6 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха) + номер стиха 7 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха + количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха + количество букв 6 стиха)"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    

    summ_dlya_2_stiha = str (kolvo_bukv_1 + kolvo_bukv_2)
    summ_dlya_3_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3)
    summ_dlya_4_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4)
    summ_dlya_5_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5)
    summ_dlya_6_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6)
    summ_dlya_7_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)

    virajenie_8 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + nomer_stiha_2_str + summ_dlya_2_stiha +
                   nomer_stiha_3_str + summ_dlya_3_stiha + nomer_stiha_4_str + summ_dlya_4_stiha +
                   nomer_stiha_5_str + summ_dlya_5_stiha + nomer_stiha_6_str + summ_dlya_6_stiha +
                   nomer_stiha_7_str + summ_dlya_7_stiha)
    return virajenie_8

def fact_8 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
            stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> str :
    """Факт 8 = (номер главы + номер 1 стиха + количество букв 1 стиха + номер 2 стиха +
    сумма цифр(количество букв 1 стиха + количество букв 2 стиха) + номер 3 стиха + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха) + номер стиха 4 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха) + номер стиха 5 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха) + номер стиха 6 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха + количество букв 3 стиха +
    количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха) + номер стиха 7 + сумма цифр(количество букв 1 стиха + количество букв 2 стиха +
    количество букв 3 стиха + количество букв 4 стиха + количество букв 5 стиха + количество букв 6 стиха + количество букв 7 стиха)) / 19"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    

    summ_dlya_2_stiha = str (kolvo_bukv_1 + kolvo_bukv_2)
    summ_dlya_3_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3)
    summ_dlya_4_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4)
    summ_dlya_5_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5)
    summ_dlya_6_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6)
    summ_dlya_7_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)

    virajenie_8 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + nomer_stiha_2_str + summ_dlya_2_stiha +
                   nomer_stiha_3_str + summ_dlya_3_stiha + nomer_stiha_4_str + summ_dlya_4_stiha +
                   nomer_stiha_5_str + summ_dlya_5_stiha + nomer_stiha_6_str + summ_dlya_6_stiha +
                   nomer_stiha_7_str + summ_dlya_7_stiha)

    virajenie_8_decimal = Decimal (virajenie_8)
    divisor = Decimal ('19')
    fact_8 = virajenie_8_decimal / divisor
    fact_8_str = str (fact_8)
    
    return fact_8_str

def summ_dlya_2_stiha (stih_1 : str, stih_2 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    summ_dlya_2_stiha = str (kolvo_bukv_1 + kolvo_bukv_2)
    return summ_dlya_2_stiha

def summ_dlya_3_stiha (stih_1 : str, stih_2 : str, stih_3 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    summ_dlya_3_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3)
    return summ_dlya_3_stiha

def summ_dlya_4_stiha (stih_1 : str, stih_2 : str, stih_3 : str, stih_4 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    summ_dlya_4_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4)
    return summ_dlya_4_stiha

def summ_dlya_5_stiha (stih_1 : str, stih_2 : str, stih_3 : str, stih_4 : str, stih_5 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    summ_dlya_5_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5)
    return summ_dlya_5_stiha

def summ_dlya_6_stiha (stih_1 : str, stih_2 : str, stih_3 : str, stih_4 : str, stih_5 : str,  stih_6 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    summ_dlya_6_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6)
    return summ_dlya_6_stiha

def summ_dlya_7_stiha (stih_1 : str, stih_2 : str, stih_3 : str, stih_4 : str, stih_5 : str, stih_6 : str, stih_7 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    summ_dlya_7_stiha = str (kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)
    return summ_dlya_7_stiha

def virajenie_9  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
                 stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 9 = номер главы  + количество букв в первом стихе + цифровое значение 1 стиха + количество букв в втором стихе +
    цифровое значение 2 стиха + количество букв в третьем стихе + цифровое значение 3 стиха + количество букв в четвертом стихе +
    цифровое значение 4 стиха + количество букв в пятом стихе + цифровое значение 5 стиха  +
    количество букв в шестом стихе + цифровое значение 6 стиха + количество букв в седьмом стихе + цифровое значение 7 стиха """

    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 9"""
    virajenie_9 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                   kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                   kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                   kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    
    

    return virajenie_9

def fact_9  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Факт 9 =( номер главы  + количество букв в первом стихе + цифровое значение 1 стиха + количество букв в втором стихе +
    цифровое значение 2 стиха + количество букв в третьем стихе + цифровое значение 3 стиха + количество букв в четвертом стихе +
    цифровое значение 4 стиха + количество букв в пятом стихе + цифровое значение 5 стиха  +
    количество букв в шестом стихе + цифровое значение 6 стиха + количество букв в седьмом стихе + цифровое значение 7 стиха ) / 19"""

    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 9"""
    virajenie_9 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                   kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                   kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                   kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_9_decimal = Decimal (virajenie_9)
    divisor = Decimal ('19')
    fact_9 = Decimal (virajenie_9_decimal / divisor)
    fact_9_str = str (fact_9)
    
    
    return fact_9_str


def virajenie_10  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 10 =( цифровое значение 7 стиха + количество букв в седьмом стихе + цифровое значение 6 стиха + количество букв в шестом стихе
     + цифровое значение 5 стиха  + количество букв в пятом стихе + цифровое значение 4 стиха  + количество букв в четвертом стихе +
     цифровое значение 3 стиха + количество букв в третьем стихе + цифровое значение 2 стиха + количество букв в втором стихе +
     цифровое значение 1 стиха + количество букв в первом стихе + номер главы ) / 19"""
    
    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 10"""
    virajenie_10 = (cifrovoe_znachenie_stiha_7_str + kolvo_bukv_7_str  + cifrovoe_znachenie_stiha_6_str + kolvo_bukv_6_str
                    + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_4_str + kolvo_bukv_4_str
                    + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_2_str + kolvo_bukv_2_str
                    + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_1_str + nomer_glavi_str)

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_10_decimal = Decimal (virajenie_10)

    
    
    return virajenie_10

def fact_10  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Факт 10 =(  цифровое значение 7 стиха + количество букв в седьмом стихе + цифровое значение 6 стиха + количество букв в шестом стихе
     + цифровое значение 5 стиха  + количество букв в пятом стихе + цифровое значение 4 стиха  + количество букв в четвертом стихе +
     цифровое значение 3 стиха + количество букв в третьем стихе + цифровое значение 2 стиха + количество букв в втором стихе +
     цифровое значение 1 стиха + количество букв в первом стихе + номер главы ) / 19"""
    
    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 10"""
    virajenie_10 = (cifrovoe_znachenie_stiha_7_str + kolvo_bukv_7_str  + cifrovoe_znachenie_stiha_6_str + kolvo_bukv_6_str
                    + cifrovoe_znachenie_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_4_str + kolvo_bukv_4_str
                    + cifrovoe_znachenie_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_2_str + kolvo_bukv_2_str
                    + cifrovoe_znachenie_stiha_1_str + kolvo_bukv_1_str + nomer_glavi_str)

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_10_decimal = Decimal (virajenie_10)
    divisor = Decimal ('19')
    fact_10 = Decimal (virajenie_10_decimal / divisor)
    fact_10_str = str (fact_10)
    
    
    return fact_10_str

def fact_11  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Факт 11 = номер главы + количество букв в 1 стихе + цифровое значение 1 стиха + (количество букв в 1 стихе + количество букв во 2 стихе)
    + (цифровое значение 1 стиха + цифровое значение 2 стиха) + (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе )
    + (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе ) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха  ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе) +
     (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе + количество букв в 7 стихе)
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха + цифровое значение 7 стиха)
       после всех  операций идет деление в конце  / 19"""
    
    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 11"""
    progressia_dlya_2_bukv = kolvo_bukv_1 + kolvo_bukv_2
    progressia_dlya_3_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3
    progressia_dlya_4_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4
    progressia_dlya_5_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5
    progressia_dlya_6_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6
    progressia_dlya_7_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7

    progressia_dlya_2_bukv_str = str (progressia_dlya_2_bukv)
    progressia_dlya_3_bukv_str = str (progressia_dlya_3_bukv)
    progressia_dlya_4_bukv_str = str (progressia_dlya_4_bukv)
    progressia_dlya_5_bukv_str = str (progressia_dlya_5_bukv)
    progressia_dlya_6_bukv_str = str (progressia_dlya_6_bukv)
    progressia_dlya_7_bukv_str = str (progressia_dlya_7_bukv)

    


    
    progressia_dlya_2_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2)


    progressia_dlya_3_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3)
    progressia_dlya_4_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4)

    progressia_dlya_5_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5)
    progressia_dlya_6_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6)
    progressia_dlya_7_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6 +
                                             cifrovoe_znachenie_stiha_7)

    progressia_dlya_2_cifrovogo_znachenia_str = str (progressia_dlya_2_cifrovogo_znachenia)
    progressia_dlya_3_cifrovogo_znachenia_str = str (progressia_dlya_3_cifrovogo_znachenia)
    progressia_dlya_4_cifrovogo_znachenia_str = str (progressia_dlya_4_cifrovogo_znachenia)
    progressia_dlya_5_cifrovogo_znachenia_str = str (progressia_dlya_5_cifrovogo_znachenia)
    progressia_dlya_6_cifrovogo_znachenia_str = str (progressia_dlya_6_cifrovogo_znachenia)
    progressia_dlya_7_cifrovogo_znachenia_str = str (progressia_dlya_7_cifrovogo_znachenia)





    
    virajenie_11 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + progressia_dlya_2_bukv_str +
                    progressia_dlya_2_cifrovogo_znachenia_str + progressia_dlya_3_bukv_str + progressia_dlya_3_cifrovogo_znachenia_str
                    + progressia_dlya_4_bukv_str + progressia_dlya_4_cifrovogo_znachenia_str
                    + progressia_dlya_5_bukv_str + progressia_dlya_5_cifrovogo_znachenia_str
                    + progressia_dlya_6_bukv_str + progressia_dlya_6_cifrovogo_znachenia_str
                    + progressia_dlya_7_bukv_str + progressia_dlya_7_cifrovogo_znachenia_str)
                    
     

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_11_decimal = Decimal (virajenie_11)
    divisor = Decimal ('19')
    fact_11 = Decimal (virajenie_11_decimal / divisor)
    fact_11_str = str (fact_11)
    
    
    return fact_11_str


def virajenie_11  ( nomer_glavi : int, stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 11 = номер главы + количество букв в 1 стихе + цифровое значение 1 стиха + (количество букв в 1 стихе + количество букв во 2 стихе)
    + (цифровое значение 1 стиха + цифровое значение 2 стиха) + (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе )
    + (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе ) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха  ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе) +
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха ) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе) +
     (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха) +
    (количество букв в 1 стихе + количество букв во 2 стихе + количество букв в 3 стихе  + количество букв в 4 стихе 
    + количество букв в 5 стихе + количество букв в 6 стихе + количество букв в 7 стихе)
    (цифровое значение 1 стиха + цифровое значение 2 стиха + цифровое значение 3 стиха + цифровое значение 4 стиха +
    цифровое значение 5 стиха  + цифровое значение 6 стиха + цифровое значение 7 стиха)"""
    
    nomer_glavi_str = str (nomer_glavi)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)
    """Создаем формулы для выражения 11"""
    progressia_dlya_2_bukv = kolvo_bukv_1 + kolvo_bukv_2
    progressia_dlya_3_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3
    progressia_dlya_4_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4
    progressia_dlya_5_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5
    progressia_dlya_6_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6
    progressia_dlya_7_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7

    progressia_dlya_2_bukv_str = str (progressia_dlya_2_bukv)
    progressia_dlya_3_bukv_str = str (progressia_dlya_3_bukv)
    progressia_dlya_4_bukv_str = str (progressia_dlya_4_bukv)
    progressia_dlya_5_bukv_str = str (progressia_dlya_5_bukv)
    progressia_dlya_6_bukv_str = str (progressia_dlya_6_bukv)
    progressia_dlya_7_bukv_str = str (progressia_dlya_7_bukv)

    


    
    progressia_dlya_2_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2)


    progressia_dlya_3_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3)
    progressia_dlya_4_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4)

    progressia_dlya_5_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5)
    progressia_dlya_6_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6)
    progressia_dlya_7_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6 +
                                             cifrovoe_znachenie_stiha_7)

    progressia_dlya_2_cifrovogo_znachenia_str = str (progressia_dlya_2_cifrovogo_znachenia)
    progressia_dlya_3_cifrovogo_znachenia_str = str (progressia_dlya_3_cifrovogo_znachenia)
    progressia_dlya_4_cifrovogo_znachenia_str = str (progressia_dlya_4_cifrovogo_znachenia)
    progressia_dlya_5_cifrovogo_znachenia_str = str (progressia_dlya_5_cifrovogo_znachenia)
    progressia_dlya_6_cifrovogo_znachenia_str = str (progressia_dlya_6_cifrovogo_znachenia)
    progressia_dlya_7_cifrovogo_znachenia_str = str (progressia_dlya_7_cifrovogo_znachenia)





    
    virajenie_11 = (nomer_glavi_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str + progressia_dlya_2_bukv_str +
                    progressia_dlya_2_cifrovogo_znachenia_str + progressia_dlya_3_bukv_str + progressia_dlya_3_cifrovogo_znachenia_str
                    + progressia_dlya_4_bukv_str + progressia_dlya_4_cifrovogo_znachenia_str
                    + progressia_dlya_5_bukv_str + progressia_dlya_5_cifrovogo_znachenia_str
                    + progressia_dlya_6_bukv_str + progressia_dlya_6_cifrovogo_znachenia_str
                    + progressia_dlya_7_bukv_str + progressia_dlya_7_cifrovogo_znachenia_str)
                    
     

    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_11_decimal = Decimal (virajenie_11)
    
    
    
    return virajenie_11

def fact_12 ( stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Факт 12 = количество букв в главе + количество слов в 1 стихе + количество букв в 1 стихе + цифровое значение 1 стиха +
    количество слов в 2 стихе + количество букв во 2 стихе + цифровое значение 2 стиха +
    количество слов в 3 стихе + количество букв в 3 стихе + цифровое значение 2 стиха +
    количество слов в 4 стихе + количество букв в 4 стихе + цифровое значение 4 стиха +
    количество слов в 5 стихе + количество букв в 5 стихе + цифровое значение 5 стиха +
    количество слов в 6 стихе + количество букв в 6 стихе + цифровое значение 6 стиха +
    количество слов в 7 стихе + количество букв в 7 стихе + цифровое значение 7 стиха
    и в конце после всех расчетов поделить на 19"""
    
    


    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)


    """Считаем количество букв главы"""
    kolvo_bukv_glavi_str = str(kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 +
                               kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))


    virajenie_12 = (kolvo_bukv_glavi_str + slova1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    slova2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    slova3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    slova4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    slova5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    slova6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    slova7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec =999
    virajenie_12_decimal = Decimal (virajenie_12)
    divisor = Decimal ('19')
    fact_12 = Decimal (virajenie_12_decimal / divisor)
    fact_12_str = str (fact_12)
    
    
    return fact_12_str

def virajenie_12 ( stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """ Выражение 12 = количество букв в главе + количество слов в 1 стихе + количество букв в 1 стихе + цифровое значение 1 стиха +
    количество слов в 2 стихе + количество букв во 2 стихе + цифровое значение 2 стиха +
    количество слов в 3 стихе + количество букв в 3 стихе + цифровое значение 2 стиха +
    количество слов в 4 стихе + количество букв в 4 стихе + цифровое значение 4 стиха +
    количество слов в 5 стихе + количество букв в 5 стихе + цифровое значение 5 стиха +
    количество слов в 6 стихе + количество букв в 6 стихе + цифровое значение 6 стиха +
    количество слов в 7 стихе + количество букв в 7 стихе + цифровое значение 7 стиха """
    
    


    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)


    """Считаем количество букв главы"""
    kolvo_bukv_glavi_str = str(kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 +
                               kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7)
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)
    
    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))


    virajenie_12 = (kolvo_bukv_glavi_str + slova1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    slova2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    slova3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    slova4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    slova5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    slova6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    slova7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_12_decimal = Decimal (virajenie_12)
    
    
    return virajenie_12

def progressia_bukv_dlya_7_stiha (stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))


    

    """Создаем формулы для прогрессии букв 7 стиха"""

    progressia_dlya_7_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6 + kolvo_bukv_7
    return  progressia_dlya_7_bukv

def progressia_bukv_dlya_6_stiha (stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str  ) -> str :

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))

    progressia_dlya_6_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5 + kolvo_bukv_6
    return  progressia_dlya_6_bukv

def progressia_bukv_dlya_5_stiha (stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str ) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))

    progressia_dlya_5_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4 + kolvo_bukv_5
    return  progressia_dlya_5_bukv
    
def progressia_bukv_dlya_4_stiha (stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str ) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))

    progressia_dlya_4_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3 + kolvo_bukv_4
    return  progressia_dlya_4_bukv

def progressia_bukv_dlya_3_stiha (stih_1 : str, stih_2 : str ,
              stih_3 : str ) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))

    progressia_dlya_3_bukv = kolvo_bukv_1 + kolvo_bukv_2 + kolvo_bukv_3
    return  progressia_dlya_3_bukv

def progressia_bukv_dlya_2_stiha (stih_1 : str, stih_2 : str) -> str :
    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))

    progressia_dlya_2_bukv = kolvo_bukv_1 + kolvo_bukv_2
    return  progressia_dlya_2_bukv

def progressia_dlya_cifrovogo_znachenia_7 ( stih_1 : str, stih_2 : str ,
              stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str  ) -> str :
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)

    progressia_dlya_7_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6 +
                                             cifrovoe_znachenie_stiha_7)
    return progressia_dlya_7_cifrovogo_znachenia
    
def progressia_dlya_cifrovogo_znachenia_6 ( stih_1 : str, stih_2 : str ,stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str) -> str :
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    progressia_dlya_6_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5 + cifrovoe_znachenie_stiha_6)
    return progressia_dlya_6_cifrovogo_znachenia

def progressia_dlya_cifrovogo_znachenia_5 ( stih_1 : str, stih_2 : str ,stih_3 : str , stih_4 :str, stih_5 :str) -> str :

    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    progressia_dlya_5_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4 + cifrovoe_znachenie_stiha_5)
    return progressia_dlya_5_cifrovogo_znachenia
def progressia_dlya_cifrovogo_znachenia_4 ( stih_1 : str, stih_2 : str ,stih_3 : str , stih_4 :str) -> str :
    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)
    
    progressia_dlya_4_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3 +
                                             cifrovoe_znachenie_stiha_4)

    return progressia_dlya_4_cifrovogo_znachenia
def progressia_dlya_cifrovogo_znachenia_3 ( stih_1 : str, stih_2 : str ,stih_3 : str) -> str :

    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)


    progressia_dlya_3_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2 + cifrovoe_znachenie_stiha_3)
    return progressia_dlya_3_cifrovogo_znachenia
def progressia_dlya_cifrovogo_znachenia_2 ( stih_1 : str, stih_2 : str ) -> str :

    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    progressia_dlya_2_cifrovogo_znachenia = (cifrovoe_znachenie_stiha_1 + cifrovoe_znachenie_stiha_2)
    return progressia_dlya_2_cifrovogo_znachenia    


def fact_13 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
            stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> str :
    """Факт 13 = номер главы + номер 1 стиха + количество букв 1 стиха + цифровое значение 1 стиха + номер 2 стиха + количество букв 2 стиха
    + цифровое значение 2 стиха +  номер 3 стиха + количество букв 3 стиха + цифровое значение 3 стиха +  номер стиха 4 +
    количество букв 4 стиха + цифровое значение 4 стиха +  номер стиха 5 + количество букв 5 стиха + цифровое значение 5 стиха +
    номер стиха 6 + количество букв 6 стиха + цифровое значение 6 стиха + номер стиха 7 + количество букв 7 стиха + цифровое значение 7 стиха  
    после всех операций деления на / 19"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    virajenie_13 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_13_decimal = Decimal (virajenie_13)
    divisor = Decimal ('19')
    fact_13 = Decimal (virajenie_13_decimal / divisor)
    fact_13_str = str (fact_13)


    return fact_13_str

def virajenie_13 (nomer_glavi :int, nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
            nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 : str ,
            stih_3 : str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str) -> str :
    """Факт 13 = номер главы + номер 1 стиха + количество букв 1 стиха + цифровое значение 1 стиха + номер 2 стиха + количество букв 2 стиха
    + цифровое значение 2 стиха +  номер 3 стиха + количество букв 3 стиха + цифровое значение 3 стиха +  номер стиха 4 +
    количество букв 4 стиха + цифровое значение 4 стиха +  номер стиха 5 + количество букв 5 стиха + цифровое значение 5 стиха +
    номер стиха 6 + количество букв 6 стиха + цифровое значение 6 стиха + номер стиха 7 + количество букв 7 стиха + цифровое значение 7 стиха"""

    nomer_glavi_str = str (nomer_glavi)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    virajenie_13 = (nomer_glavi_str + nomer_stiha_1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_13_decimal = Decimal (virajenie_13)

    return virajenie_13



def fact_14 ( nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 :str ,
              stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ,
              nomer_glavi : int , kolvo_stihov : int ) -> str :
    """Факт 14 = номер главы + количество стихов в главе + цифровое значение всей главы +
    номер 1 стиха + количество слов 1 стиха  + количество букв 1 стиха + цифровое значение 1 стиха +
    номер 2 стиха + количество слов 2 стиха  + количество букв 2 стиха + цифровое значение 2 стиха +
    номер 3 стиха + количество слов 3 стиха  + количество букв 3 стиха + цифровое значение 3 стиха +
    номер 4 стиха + количество слов 4 стиха  + количество букв 4 стиха + цифровое значение 4 стиха +
    номер 5 стиха + количество слов 5 стиха  + количество букв 5 стиха + цифровое значение 5 стиха +
    номер 6 стиха + количество слов 6 стиха  + количество букв 6 стиха + цифровое значение 6 стиха +
    номер 7 стиха + количество слов 7 стиха  + количество букв 7 стиха + цифровое значение 7 стиха
    в конце поделить на 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)


    virajenie_14 = (nomer_glavi_str + kolichestvo_stihov_str + cifrovoe_znachenie_glavi_str + 
                    nomer_stiha_1_str + slova1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + slova2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + slova3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + slova4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + slova5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + slova6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + slova7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_14_decimal = Decimal (virajenie_14)
    divisor = Decimal ('19')
    fact_14 = Decimal (virajenie_14_decimal / divisor)
    fact_14_str = str (fact_14)


    return fact_14_str

def virajenie_14 ( nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 :str ,
              stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ,
              nomer_glavi : int , kolvo_stihov : int ) -> str :
    """Выражение 14 = номер главы + количество стихов в главе + цифровое значение всей главы +
    номер 1 стиха + количество слов 1 стиха  + количество букв 1 стиха + цифровое значение 1 стиха +
    номер 2 стиха + количество слов 2 стиха  + количество букв 2 стиха + цифровое значение 2 стиха +
    номер 3 стиха + количество слов 3 стиха  + количество букв 3 стиха + цифровое значение 3 стиха +
    номер 4 стиха + количество слов 4 стиха  + количество букв 4 стиха + цифровое значение 4 стиха +
    номер 5 стиха + количество слов 5 стиха  + количество букв 5 стиха + цифровое значение 5 стиха +
    номер 6 стиха + количество слов 6 стиха  + количество букв 6 стиха + цифровое значение 6 стиха +
    номер 7 стиха + количество слов 7 стиха  + количество букв 7 стиха + цифровое значение 7 стиха"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    
    """Узнаем цифровое значение стиха 1"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_int = [int  (x) for x  in spisok_cifr_stiha_1]
    cifrovoe_znachenie_stiha_1 = sum(spisok_cifr_stiha_1_int)

    """Узнаем цифровое значение стиха 2"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_int = [int  (x) for x  in spisok_cifr_stiha_2]
    cifrovoe_znachenie_stiha_2 = sum(spisok_cifr_stiha_2_int)

    """Узнаем цифровое значение стиха 3"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_int = [int  (x) for x  in spisok_cifr_stiha_3]
    cifrovoe_znachenie_stiha_3 = sum(spisok_cifr_stiha_3_int)

    """Узнаем цифровое значение стиха 4"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_int = [int  (x) for x  in spisok_cifr_stiha_4]
    cifrovoe_znachenie_stiha_4 = sum(spisok_cifr_stiha_4_int)

    """Узнаем цифровое значение стиха 5"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_int = [int  (x) for x  in spisok_cifr_stiha_5]
    cifrovoe_znachenie_stiha_5 = sum(spisok_cifr_stiha_5_int)

    """Узнаем цифровое значение стиха 6"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_int = [int  (x) for x  in spisok_cifr_stiha_6]
    cifrovoe_znachenie_stiha_6 = sum(spisok_cifr_stiha_6_int)

    """Узнаем цифровое значение стиха 7"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_int = [int  (x) for x  in spisok_cifr_stiha_7]
    cifrovoe_znachenie_stiha_7 = sum(spisok_cifr_stiha_7_int)


    cifrovoe_znachenie_stiha_1_str = str (cifrovoe_znachenie_stiha_1)
    cifrovoe_znachenie_stiha_2_str = str (cifrovoe_znachenie_stiha_2)
    cifrovoe_znachenie_stiha_3_str = str (cifrovoe_znachenie_stiha_3)
    cifrovoe_znachenie_stiha_4_str = str (cifrovoe_znachenie_stiha_4)
    cifrovoe_znachenie_stiha_5_str = str (cifrovoe_znachenie_stiha_5)
    cifrovoe_znachenie_stiha_6_str = str (cifrovoe_znachenie_stiha_6)
    cifrovoe_znachenie_stiha_7_str = str (cifrovoe_znachenie_stiha_7)

    

    """Считаем количество слов в каждом стихе"""
    a1list = stih_1.split ()
    a2list = stih_2.split ()
    a3list = stih_3.split () 
    a4list = stih_4.split ()
    a5list = stih_5.split ()
    a6list = stih_6.split ()
    a7list = stih_7.split ()

    slova1_str = str (len(a1list))
    slova2_str = str (len(a2list))
    slova3_str = str (len(a3list))
    slova4_str = str (len(a4list))
    slova5_str = str (len(a5list))
    slova6_str = str (len(a6list))
    slova7_str = str (len(a7list))
    """Считаем числовое значение всей главы"""
    a1a2a3a4a5a6a7 = [stih_1 , stih_2 , stih_3 , stih_4, stih_5, stih_6, stih_7]
    cifrovoe_znachenie_glavi = 0
    for stih in a1a2a3a4a5a6a7 :
        spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
        
        result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
        result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
        result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
        result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
        result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
        result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
        result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
        result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
        result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
        result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
        result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
        result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
        result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
        result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
        result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
        result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
        result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
        result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
        result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
        result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
        result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
        result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
        result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
        result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
        result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
        result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
        result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
        result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
        result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
        """Хамза не имеет цифрового значения"""
        result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
        """Та марбута не имеет цифрового значения"""
        result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
        result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
        result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
        spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
        
        spisok_cifr_stiha_float = [int  (x) for x  in spisok_cifr_stiha]
        cifrovoe_znachenie_stiha = sum(spisok_cifr_stiha_float)
        
        cifrovoe_znachenie_glavi += sum(spisok_cifr_stiha_float)
    
    cifrovoe_znachenie_glavi_str = str (cifrovoe_znachenie_glavi)


    virajenie_14 = (nomer_glavi_str + kolichestvo_stihov_str + cifrovoe_znachenie_glavi_str + 
                    nomer_stiha_1_str + slova1_str + kolvo_bukv_1_str + cifrovoe_znachenie_stiha_1_str +
                    nomer_stiha_2_str + slova2_str + kolvo_bukv_2_str + cifrovoe_znachenie_stiha_2_str +
                    nomer_stiha_3_str + slova3_str + kolvo_bukv_3_str + cifrovoe_znachenie_stiha_3_str +
                    nomer_stiha_4_str + slova4_str + kolvo_bukv_4_str + cifrovoe_znachenie_stiha_4_str +
                    nomer_stiha_5_str + slova5_str + kolvo_bukv_5_str + cifrovoe_znachenie_stiha_5_str +
                    nomer_stiha_6_str + slova6_str + kolvo_bukv_6_str + cifrovoe_znachenie_stiha_6_str +
                    nomer_stiha_7_str + slova7_str + kolvo_bukv_7_str + cifrovoe_znachenie_stiha_7_str)
    
    
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_14_decimal = Decimal (virajenie_14)

    return virajenie_14

def fact_15 ( nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 :str ,
              stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ,
              nomer_glavi : int , kolvo_stihov : int ) -> str :
    """Факт 15 = номер главы + количество стихов в главе + 
    номер 1 стиха + количество букв 1 стиха + каждое букво-число 1 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 2 стиха + количество букв 2 стиха + каждое букво-число 2 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) + 
    номер 3 стиха + количество букв 3 стиха + каждое букво-число 3 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 4 стиха + количество букв 4 стиха + каждое букво-число 4 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 5 стиха + количество букв 5 стиха + каждое букво-число 5 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 6 стиха + количество букв 6 стиха + каждое букво-число 6 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 7 стиха + количество букв 7 стиха + каждое букво-число 7 стиха (это сложение  в строку списка замененных на цифры букв в одну строку)
    затем после всех операций делится на 19"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    """Узнаем букво-число 1 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_str = [str  (x) for x  in spisok_cifr_stiha_1]
    bukvo_chislo_stiha_1 = ''.join(spisok_cifr_stiha_1_str)


    """Узнаем букво-число 2 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_str = [str  (x) for x  in spisok_cifr_stiha_2]
    bukvo_chislo_stiha_2 = ''.join(spisok_cifr_stiha_2_str)


    """Узнаем букво-число 3 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_str = [str  (x) for x  in spisok_cifr_stiha_3]
    bukvo_chislo_stiha_3 = ''.join(spisok_cifr_stiha_3_str)


    """Узнаем букво-число 4 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_str = [str  (x) for x  in spisok_cifr_stiha_4]
    bukvo_chislo_stiha_4 = ''.join(spisok_cifr_stiha_4_str)


    """Узнаем букво-число 5 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_str = [str  (x) for x  in spisok_cifr_stiha_5]
    bukvo_chislo_stiha_5 = ''.join(spisok_cifr_stiha_5_str)


    """Узнаем букво-число 6 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_str = [str  (x) for x  in spisok_cifr_stiha_6]
    bukvo_chislo_stiha_6 = ''.join(spisok_cifr_stiha_6_str)

    """Узнаем букво-число 7 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_str = [str  (x) for x  in spisok_cifr_stiha_7]
    bukvo_chislo_stiha_7 = ''.join(spisok_cifr_stiha_7_str)

    virajenie_15 = (nomer_glavi_str + kolichestvo_stihov_str +
                    nomer_stiha_1_str + kolvo_bukv_1_str + bukvo_chislo_stiha_1 +
                    nomer_stiha_2_str + kolvo_bukv_2_str + bukvo_chislo_stiha_2 +
                    nomer_stiha_3_str + kolvo_bukv_3_str + bukvo_chislo_stiha_3 +
                    nomer_stiha_4_str + kolvo_bukv_4_str + bukvo_chislo_stiha_4 +
                    nomer_stiha_5_str + kolvo_bukv_5_str + bukvo_chislo_stiha_5 +
                    nomer_stiha_6_str + kolvo_bukv_6_str + bukvo_chislo_stiha_6 +
                    nomer_stiha_7_str + kolvo_bukv_7_str + bukvo_chislo_stiha_7)

  
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_15_decimal = Decimal (virajenie_15)
    divisor = Decimal ('19')
    fact_15 = Decimal (virajenie_15_decimal / divisor)
    fact_15_str = str (fact_15)


    return fact_15_str


  
def bukvo_chislo_stiha (stih : str) -> str :
    """Узнаем букво-число стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha = re.findall (r'[^ ]' , stih)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_str = [str  (x) for x  in spisok_cifr_stiha]
    bukvo_chislo_stiha = ''.join(spisok_cifr_stiha_str)

    return bukvo_chislo_stiha

def virajenie_15 ( nomer_stiha1 :int , nomer_stiha2 :int ,nomer_stiha3 : int, nomer_stiha4 : int ,
              nomer_stiha5 : int, nomer_stiha6 :int, nomer_stiha7 :int, stih_1 : str, stih_2 :str ,
              stih_3 :str , stih_4 :str, stih_5 :str, stih_6 :str, stih_7 :str ,
              nomer_glavi : int , kolvo_stihov : int ) -> str :
    """Факт 15 = номер главы + количество стихов в главе + 
    номер 1 стиха + количество букв 1 стиха + каждое букво-число 1 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 2 стиха + количество букв 2 стиха + каждое букво-число 2 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) + 
    номер 3 стиха + количество букв 3 стиха + каждое букво-число 3 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 4 стиха + количество букв 4 стиха + каждое букво-число 4 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 5 стиха + количество букв 5 стиха + каждое букво-число 5 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 6 стиха + количество букв 6 стиха + каждое букво-число 6 стиха (это сложение  в строку списка замененных на цифры букв в одну строку) +
    номер 7 стиха + количество букв 7 стиха + каждое букво-число 7 стиха (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    nomer_glavi_str = str(nomer_glavi)
    kolichestvo_stihov_str = str(kolvo_stihov)
    nomer_stiha_1_str = str (nomer_stiha1)
    nomer_stiha_2_str = str (nomer_stiha2)
    nomer_stiha_3_str = str (nomer_stiha3)
    nomer_stiha_4_str = str (nomer_stiha4)
    nomer_stiha_5_str = str (nomer_stiha5)
    nomer_stiha_6_str = str (nomer_stiha6)
    nomer_stiha_7_str = str (nomer_stiha7)

    """Считаем количество букв в каждом стихе"""
    kolvo_bukv_1 = len (re.sub (' ' ,'', stih_1))
    kolvo_bukv_2 = len (re.sub (' ' ,'', stih_2))
    kolvo_bukv_3 = len (re.sub (' ' ,'', stih_3))
    kolvo_bukv_4 = len (re.sub (' ' ,'', stih_4))
    kolvo_bukv_5 = len (re.sub (' ' ,'', stih_5))
    kolvo_bukv_6 = len (re.sub (' ' ,'', stih_6))
    kolvo_bukv_7 = len (re.sub (' ' ,'', stih_7))
    kolvo_bukv_1_str = str (kolvo_bukv_1)
    kolvo_bukv_2_str = str (kolvo_bukv_2)
    kolvo_bukv_3_str = str (kolvo_bukv_3)
    kolvo_bukv_4_str = str (kolvo_bukv_4)
    kolvo_bukv_5_str = str (kolvo_bukv_5)
    kolvo_bukv_6_str = str (kolvo_bukv_6)
    kolvo_bukv_7_str = str (kolvo_bukv_7)

    """Узнаем букво-число 1 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_1 = re.findall (r'[^ ]' , stih_1)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_1]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_1 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_1_str = [str  (x) for x  in spisok_cifr_stiha_1]
    bukvo_chislo_stiha_1 = ''.join(spisok_cifr_stiha_1_str)


    """Узнаем букво-число 2 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_2 = re.findall (r'[^ ]' , stih_2)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_2]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_2 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_2_str = [str  (x) for x  in spisok_cifr_stiha_2]
    bukvo_chislo_stiha_2 = ''.join(spisok_cifr_stiha_2_str)


    """Узнаем букво-число 3 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_3 = re.findall (r'[^ ]' , stih_3)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_3]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_3 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_3_str = [str  (x) for x  in spisok_cifr_stiha_3]
    bukvo_chislo_stiha_3 = ''.join(spisok_cifr_stiha_3_str)


    """Узнаем букво-число 4 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_4 = re.findall (r'[^ ]' , stih_4)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_4]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_4 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_4_str = [str  (x) for x  in spisok_cifr_stiha_4]
    bukvo_chislo_stiha_4 = ''.join(spisok_cifr_stiha_4_str)


    """Узнаем букво-число 5 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_5 = re.findall (r'[^ ]' , stih_5)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_5]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_5 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_5_str = [str  (x) for x  in spisok_cifr_stiha_5]
    bukvo_chislo_stiha_5 = ''.join(spisok_cifr_stiha_5_str)


    """Узнаем букво-число 6 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_6 = re.findall (r'[^ ]' , stih_6)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_6]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_6 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_6_str = [str  (x) for x  in spisok_cifr_stiha_6]
    bukvo_chislo_stiha_6 = ''.join(spisok_cifr_stiha_6_str)

    """Узнаем букво-число 7 стиха
    (это сложение  в строку списка замененных на цифры букв в одну строку)"""
    
    spisok_bukv_stiha_7 = re.findall (r'[^ ]' , stih_7)
    
    result_g1 = [elem.replace ('ا' , '1') for elem in spisok_bukv_stiha_7]
    result_g1 = [elem.replace ('ب' , '2') for elem in result_g1]
    result_g1 = [elem.replace ('ت' , '400') for elem in result_g1]
    result_g1 = [elem.replace ('ث' , '500') for elem in result_g1]
    result_g1 = [elem.replace ('ج' , '3') for elem in result_g1]
    result_g1 = [elem.replace ('ح' , '8') for elem in result_g1]
    result_g1 = [elem.replace ('د' , '4') for elem in result_g1]
    result_g1 = [elem.replace ('ه' , '5') for elem in result_g1]
    result_g1 = [elem.replace ('و' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ز' , '7') for elem in result_g1]
    result_g1 = [elem.replace ('ط' , '9') for elem in result_g1]
    result_g1 = [elem.replace ('ي' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ك' , '20') for elem in result_g1]
    result_g1 = [elem.replace ('ل' , '30') for elem in result_g1]
    result_g1 = [elem.replace ('م' , '40') for elem in result_g1]
    result_g1 = [elem.replace ('ن' , '50') for elem in result_g1]
    result_g1 = [elem.replace ('س' , '60') for elem in result_g1]
    result_g1 = [elem.replace ('ع' , '70') for elem in result_g1]
    result_g1 = [elem.replace ('ف' , '80') for elem in result_g1]
    result_g1 = [elem.replace ('ص' , '90') for elem in result_g1]
    result_g1 = [elem.replace ('ق' , '100') for elem in result_g1]
    result_g1 = [elem.replace ('ر' , '200') for elem in result_g1]
    result_g1 = [elem.replace ('ش' , '300') for elem in result_g1]
    result_g1 = [elem.replace ('خ' , '600') for elem in result_g1]
    result_g1 = [elem.replace ('ذ' , '700') for elem in result_g1]
    result_g1 = [elem.replace ('ض' , '800') for elem in result_g1]
    result_g1 = [elem.replace ('ظ' , '900') for elem in result_g1]
    result_g1 = [elem.replace ('غ' , '1000') for elem in result_g1]
    result_g1 = [elem.replace ('ؤ' , '6') for elem in result_g1]
    result_g1 = [elem.replace ('ئ' , '10') for elem in result_g1]
    result_g1 = [elem.replace ('ى' , '10') for elem in result_g1]
    """Хамза не имеет цифрового значения"""
    result_g1 = [elem.replace ('ء' , '0') for elem in result_g1]
    """Та марбута не имеет цифрового значения"""
    result_g1 = [elem.replace ('ة' , '0') for elem in result_g1]
    result_g1 = [elem.replace ('أ' , '1') for elem in result_g1]
    result_g1 = [elem.replace ('إ' , '1') for elem in result_g1]
    spisok_cifr_stiha_7 = [elem.replace ('آ' , '1') for elem in result_g1]
    
    spisok_cifr_stiha_7_str = [str  (x) for x  in spisok_cifr_stiha_7]
    bukvo_chislo_stiha_7 = ''.join(spisok_cifr_stiha_7_str)

    virajenie_15 = (nomer_glavi_str + kolichestvo_stihov_str +
                    nomer_stiha_1_str + kolvo_bukv_1_str + bukvo_chislo_stiha_1 +
                    nomer_stiha_2_str + kolvo_bukv_2_str + bukvo_chislo_stiha_2 +
                    nomer_stiha_3_str + kolvo_bukv_3_str + bukvo_chislo_stiha_3 +
                    nomer_stiha_4_str + kolvo_bukv_4_str + bukvo_chislo_stiha_4 +
                    nomer_stiha_5_str + kolvo_bukv_5_str + bukvo_chislo_stiha_5 +
                    nomer_stiha_6_str + kolvo_bukv_6_str + bukvo_chislo_stiha_6 +
                    nomer_stiha_7_str + kolvo_bukv_7_str + bukvo_chislo_stiha_7)

  
    """устанавливаем округление и точность, чтобы нормально результаты выдывал и точные"""
    getcontext().prec = 999
    virajenie_15_decimal = Decimal (virajenie_15)
   
    return virajenie_15

def proverka_kratnosti_19 (virajenie : int) -> str :
    virajenie_decimal = Decimal (virajenie % 19)
    if virajenie_decimal == 0 :
        return 'Да'
    else: return 'Нет'

def  shetchiki_resultatov (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Да' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_da

def  shetchiki_resultatov_net (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    otvet_da = 0
    otvet_net = 0

    for results in  spisok_shetchika :
        if results == 'Да' :
            otvet_da += 1
        else:
            otvet_net += 1
    return otvet_net

def kolichestvo_proverok_kratnosti (proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                           proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                           proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                           proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                           proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15) -> str :

    spisok_shetchika = [proverka_kratnosti_19_stih_1, proverka_kratnosti_19_stih_2, proverka_kratnosti_19_stih_3,
                        proverka_kratnosti_19_stih_4, proverka_kratnosti_19_stih_5, proverka_kratnosti_19_stih_6,
                        proverka_kratnosti_19_stih_7, proverka_kratnosti_19_stih_8, proverka_kratnosti_19_stih_9,
                        proverka_kratnosti_19_stih_10, proverka_kratnosti_19_stih_11, proverka_kratnosti_19_stih_12,
                        proverka_kratnosti_19_stih_13, proverka_kratnosti_19_stih_14, proverka_kratnosti_19_stih_15]
    kolichestvo_proverok_kratnosti = len (spisok_shetchika)
    return kolichestvo_proverok_kratnosti


def proverka_kratnosti_19_arabic (virajenie : int) -> str :
    virajenie_decimal = Decimal (virajenie % 19)
    if virajenie_decimal == 0 :
        return 'نعم'
    else: return 'لا'
    
