from setuptools import setup

setup (
    name = 'miracles' ,
    version = '6.0',
    description = 'Mathematical miracles of Quran, Al-Fatiha, facts 1-15',
    author = 'Alikhan Akhmetov',
    author_email = 'ahmetov_alihan@mail.ru',
    url = 'ahmetovalihan.pythonanywhere.com',
    py_modules = ['miracles'],
)
